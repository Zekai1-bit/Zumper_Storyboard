# Zumper Design System

A design system for **Zumper** — a verified student-housing booking platform, presented
here as a UTM (University of Toronto Mississauga) concept. The product helps students
**browse verified rentals, manage a reservation, cancel with a clear refund path, and
reach support/mediation** — "manage bookings without confusion."

> **Provenance.** This system was reverse-built from a Figma file (`A4.fig`, page "Page-1",
> 23 desktop frames) provided by the project author, plus two uploaded brand assets
> (`Zumper logo.webp`, the University of Toronto crest). The Figma frames are the source of
> truth for layout and values; screenshots were used only for orientation. If you have the
> originals, the design intent lives in those frames. The recreated product surfaces are the
> author's own academic mockups.

---

## Product context

The experience spans two modes that share one nav and one visual language:

- **Marketing home** — a split hero (blue gradient panel + a featured "UTM Verified"
  property card) and a stats bar. Signed-out and signed-in variants.
- **Authenticated booking app** — Sign In → **My Bookings** dashboard → **Booking detail /
  Order details** → a 4-step **Cancellation** flow (Reason → Confirm modal → Complete) →
  **Contact Support / mediation** form → request submitted.

Everything is desktop-first at a 1440px layout with an 80px side gutter; content maxes around
1280px.

---

## CONTENT FUNDAMENTALS

**Voice:** calm, reassuring, plain-spoken. The product's whole promise is *removing
confusion*, so copy is explicit about money, dates, and what happens next.

- **Person:** second person ("**your** bookings", "**your** full refund"). The platform
  refers to itself as "we"/"our support team" ("**We're** here for you every step of the way").
- **Casing:** Sentence case for body and most buttons ("View Booking", "Browse My Bookings").
  Short ALL-CAPS eyebrows label sections ("DASHBOARD", "SUPPORT & MEDIATION", "WHAT TO EXPECT
  NEXT", "BOOKING SUMMARY"). The wordmark **zumper** is always lowercase.
- **Numbers are concrete and reassuring:** "$500.00 full deposit", "47 days until your full
  refund window expires", "Support response within 24 hours", "5–7 business days". Money is
  shown to the cent at decision points.
- **Tone of safety:** verification and protection language recurs — "UTM Verified", "Verified
  landlord since 2022", "Student renter protections apply", "Refund clarity guaranteed".
- **Destructive honesty:** cancellation copy is blunt and uses danger color — "This action is
  permanent and cannot be undone", "Once cancelled, this booking cannot be reinstated."
- **Punctuation:** en-dashes for ranges ("Sept 1 – Aug 31"), em-dash/"·" as inline separators
  ("4.9 (128 reviews) · Utilities included · Free parking").
- **No emoji in chrome.** A couple of playful emoji appear as hero feature-tile glyphs
  (⚡ "Clear actions", 🛡 "Support path") but emoji are **not** used in the working app UI.

Example microcopy: *"Browse verified listings, manage your reservation, and get clear refund
and support information — all in one place."*

---

## VISUAL FOUNDATIONS

**Color.** A single confident **Action Blue `#2F5BD3`** carries brand + primary action
(hover `#2449AD`). Semantics: **Success `#15803D`** (refunds, verified, "upcoming"),
**Danger `#DC2626`** (cancel, permanent actions). Everything else is the **slate** neutral
ramp; text is exactly three greys — `#0F172A` / `#475569` / `#64748B` (all pass contrast).
Tinted surfaces (`#EFF6FF` blue, `#DCFCE7` green, `#FEE2E2` red) back every status moment.

**Type.** Two sans families, never a serif in the interface.
- **Fjalla One** — display only: the `zumper` wordmark, big hero headlines, and large stat
  numbers. Condensed, all-caps energy, +0.5px tracking on the wordmark.
- **Roboto** — everything else (300–900). Headings use Roboto **black (900)**; body sits dense
  at 13–15px; eyebrows are 11–12px bold uppercase with ~0.08em tracking.

**Spacing & layout.** 8px grid. Roomy section padding (24–48px). Fixed 72px top nav with a
hairline bottom border; two-column app screens pair a wide content card with a ~360px sticky
action/summary rail.

**Backgrounds.** Mostly clean white / `#F8FAFC`. The hero uses the signature
**135° blue gradient** (`#2449AD → #4D7CF5`) with faint translucent white circles for depth.
No textures, no photographic full-bleed except inside property cards. Property photography is
**warm, lived-in, naturally lit interiors**.

**Corner radii.** Generous and consistent: controls 12px, large buttons / feature tiles 16px,
cards 24px, hero & marketing cards **32px**, pills/avatars/badges fully round.

**Cards.** The signature surface = white, **hairline ring + whisper drop shadow**
(`inset 0 0 0 1px #E2E8F0, 0 1px 4px rgba(15,23,42,.04)`). Sub-panels inside a card switch to a
flat `#F1F5F9` inset. Status cards drop the shadow and take a tinted fill. One card may take a
soft blue hairline (`outline`) to highlight the cancellation window.

**Shadows.** Whisper-soft and tinted with slate-900 at ~4–8% — never heavy or dark. Modals get
a larger soft lift (`0 18px 40px -12px rgba(15,23,42,.18)`).

**Borders.** 1px slate-200 hairlines; controls use a **2px inset ring** (slate-300 idle →
blue-600 focused) rather than a drawn border, so focus never shifts layout.

**Animation & states.** Restrained. ~120–200ms ease-out transitions; buttons lift 1px and
darken on hover (primary → `#2449AD`); inputs glow with a `0 0 0 3px rgba(47,91,211,.18)`
focus ring; selected option cards swap to a 2px blue ring. No bounces, no looping decoration.

**Transparency & blur.** Used sparingly: ghost buttons on the blue hero
(`rgba(255,255,255,.18)` + a 40%-white inner ring) and a `rgba(255,255,255,.92)` caption/rating
chip floated over property photos.

---

## ICONOGRAPHY

The Figma uses a **thin line ("stroke") icon set** in the Lucide/Feather family — single-weight
~2px strokes, rounded caps, no fills. They appear as small inline glyphs (location pin, Wi-Fi,
parking, calendar, shield, check-circle, chevrons) and as **dark slate-900 chips** in marketing
feature tiles. Decorative status icons are simple: green-circle ticks for checklists, gold
**★** for ratings.

- The original vector icons are not extractable from the `.fig` as a named set, so this system
  **substitutes [Lucide](https://lucide.dev)** (loaded from CDN in the UI kit) — the closest
  match for stroke weight and rounding. **Flag:** swap to the exact source icons if you have
  them.
- **Chevrons / ticks inside components** (Select, Checkbox, Stepper, Alert dismiss) are inline
  SVG so primitives carry no icon dependency.
- **Emoji** are used only as the three hero feature-tile glyphs (⚡, 🛡); never in app chrome.
- The **`zumper` wordmark** is type, not a logo file. The house-with-heart lockup
  (`assets/zumper-logo-banner.webp`) is the only raster brand mark.

---

## VISUAL FOUNDATIONS — token quick reference

| Role | Token | Value |
|---|---|---|
| Action / brand | `--blue-600` | `#2F5BD3` |
| Action hover | `--blue-700` | `#2449AD` |
| Success | `--green-600` | `#15803D` |
| Danger | `--red-600` | `#DC2626` |
| Text strong / default / muted | `--slate-900/600/500` | `#0F172A` / `#475569` / `#64748B` |
| Page / card / inset | `--slate-50` / `#fff` / `--slate-100` | bg surfaces |
| Display font | `--font-display` | Fjalla One |
| UI font | `--font-sans` | Roboto |
| Card shadow | `--shadow-card` | hairline ring + 4% drop |
| Hero gradient | `--gradient-hero` | 135° `#2449AD → #4D7CF5` |

See the **Design System tab** for live specimen cards.

---

## INDEX / manifest

**Root**
- `styles.css` — global entry point (import this). `@import`s only.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skill front matter for use in Claude Code.

**`tokens/`** — `fonts.css` (Fjalla One + Roboto), `colors.css`, `typography.css`,
`spacing.css` (radii/shadows/motion), `base.css` (light reset + wordmark).

**`guidelines/`** — foundation specimen cards (Colors, Type, Spacing, Brand).

**`components/`** — reusable primitives, loaded from `window.ZumperDesignSystem_74a932`:
- `core/` — **Button**, **Badge** (status pills), **Tag** (amenity chips), **Avatar**
- `forms/` — **Input**, **Textarea**, **Select**, **Checkbox**, **RadioCard**
- `feedback/` — **Alert** (notice banners), **Stepper** (cancellation progress)
- `layout/` — **Card** (surfaces)
- `data/` — **StatTile** (big numbers)

**`ui_kits/booking-app/`** — interactive recreation of the Zumper booking experience
(Home → Sign In → My Bookings → Booking detail → Cancellation → Contact Support). Open
`index.html`.

**`assets/`** — `apartment-utm.png` (featured listing photo), `zumper-logo-banner.webp`
(house-heart lockup), `utoronto-crest.jpg`.
