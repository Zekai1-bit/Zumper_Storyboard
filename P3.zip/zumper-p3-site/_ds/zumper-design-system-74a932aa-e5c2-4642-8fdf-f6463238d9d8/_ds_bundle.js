/* @ds-bundle: {"format":3,"namespace":"ZumperDesignSystem_74a932","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"StatTile","sourcePath":"components/data/StatTile.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Stepper","sourcePath":"components/feedback/Stepper.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"RadioCard","sourcePath":"components/forms/RadioCard.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"Card","sourcePath":"components/layout/Card.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"e5474a3ca544","components/core/Badge.jsx":"6e84e9e16a42","components/core/Button.jsx":"e9a32282acea","components/core/Tag.jsx":"79a1d4113ef4","components/data/StatTile.jsx":"93c00ada9552","components/feedback/Alert.jsx":"59cacbb90b6c","components/feedback/Stepper.jsx":"32f50a524053","components/forms/Checkbox.jsx":"b9e9a10b61da","components/forms/Input.jsx":"a92904f63614","components/forms/RadioCard.jsx":"123f9609a77c","components/forms/Select.jsx":"54e796c48f45","components/forms/Textarea.jsx":"b0b012cce2d2","components/layout/Card.jsx":"62fcc22fc6a8","ui_kits/booking-app/app.jsx":"abf610817c31","ui_kits/booking-app/icons.jsx":"d6edcaecd408","ui_kits/booking-app/screens-bookings.jsx":"6962d656cdd8","ui_kits/booking-app/screens-cancel.jsx":"9fc0b8db4960","ui_kits/booking-app/screens-marketing.jsx":"2989e157dfb2","ui_kits/booking-app/screens-support.jsx":"370c093366a8","ui_kits/booking-app/shared.jsx":"37c7c38f6825"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ZumperDesignSystem_74a932 = window.ZumperDesignSystem_74a932 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Avatar({
  initials = "",
  src = null,
  size = 40,
  alt = "",
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: size,
      height: size,
      borderRadius: "50%",
      background: src ? "var(--slate-200)" : "var(--blue-600)",
      color: "var(--white)",
      fontFamily: "var(--font-sans)",
      fontWeight: 700,
      fontSize: Math.round(size * 0.36),
      letterSpacing: "0.02em",
      overflow: "hidden",
      flex: "none",
      userSelect: "none",
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Badge({
  children,
  variant = "neutral",
  dot = false,
  size = "md",
  style = {},
  ...rest
}) {
  const variants = {
    success: {
      bg: "var(--green-100)",
      fg: "var(--green-700)",
      dotc: "var(--green-600)"
    },
    danger: {
      bg: "var(--red-100)",
      fg: "var(--red-700)",
      dotc: "var(--red-600)"
    },
    info: {
      bg: "var(--blue-100)",
      fg: "var(--blue-700)",
      dotc: "var(--blue-600)"
    },
    warning: {
      bg: "#FEF3C7",
      fg: "#92400E",
      dotc: "var(--amber-500)"
    },
    neutral: {
      bg: "var(--slate-100)",
      fg: "var(--slate-600)",
      dotc: "var(--slate-400)"
    }
  };
  const v = variants[variant] || variants.neutral;
  const sizes = {
    sm: {
      font: 11,
      pad: "3px 9px",
      gap: 5,
      dot: 6
    },
    md: {
      font: 12,
      pad: "5px 12px",
      gap: 6,
      dot: 7
    }
  };
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: s.gap,
      padding: s.pad,
      background: v.bg,
      color: v.fg,
      fontFamily: "var(--font-sans)",
      fontSize: s.font,
      fontWeight: 700,
      lineHeight: 1,
      borderRadius: "var(--radius-full)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: s.dot,
      height: s.dot,
      borderRadius: "50%",
      background: v.dotc,
      flex: "none"
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  leftIcon = null,
  rightIcon = null,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      height: 36,
      padding: "0 14px",
      font: 13,
      radius: "var(--radius-md)",
      gap: 7
    },
    md: {
      height: 44,
      padding: "0 20px",
      font: 14,
      radius: "var(--radius-md)",
      gap: 8
    },
    lg: {
      height: 56,
      padding: "0 32px",
      font: 17,
      radius: "var(--radius-lg)",
      gap: 10
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: "var(--action)",
      color: "var(--action-text)",
      fontWeight: 700,
      boxShadow: "var(--shadow-xs)",
      hover: "var(--action-hover)"
    },
    secondary: {
      background: "var(--white)",
      color: "var(--slate-700)",
      fontWeight: 500,
      boxShadow: "inset 0 0 0 1px var(--slate-300)",
      hover: "var(--slate-50)"
    },
    danger: {
      background: "var(--danger)",
      color: "var(--white)",
      fontWeight: 700,
      boxShadow: "var(--shadow-xs)",
      hover: "var(--danger-hover)"
    },
    "danger-outline": {
      background: "var(--white)",
      color: "var(--danger)",
      fontWeight: 700,
      boxShadow: "inset 0 0 0 1px var(--red-200)",
      hover: "var(--red-100)"
    },
    white: {
      background: "var(--white)",
      color: "var(--blue-600)",
      fontWeight: 700,
      boxShadow: "var(--shadow-sm)",
      hover: "var(--slate-50)"
    },
    ghost: {
      background: "rgba(255,255,255,0.18)",
      color: "var(--white)",
      fontWeight: 500,
      boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.4)",
      hover: "rgba(255,255,255,0.28)"
    },
    link: {
      background: "transparent",
      color: "var(--text-link)",
      fontWeight: 700,
      boxShadow: "none",
      hover: "transparent"
    }
  };
  const v = variants[variant] || variants.primary;
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      width: fullWidth ? "100%" : "auto",
      height: s.height,
      padding: variant === "link" ? 0 : s.padding,
      height: variant === "link" ? "auto" : s.height,
      fontFamily: "var(--font-sans)",
      fontSize: s.font,
      fontWeight: v.fontWeight,
      lineHeight: 1,
      color: v.color,
      background: disabled ? "var(--slate-200)" : hover && !disabled ? v.hover : v.background,
      boxShadow: disabled ? "none" : v.boxShadow,
      border: "none",
      borderRadius: variant === "link" ? 0 : s.radius,
      cursor: disabled ? "not-allowed" : "pointer",
      textDecoration: variant === "link" && hover ? "underline" : "none",
      transition: "background var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)",
      transform: hover && !disabled && variant !== "link" ? "translateY(-1px)" : "none",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), leftIcon, children, rightIcon);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  icon = null,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: icon ? "7px 12px 7px 9px" : "7px 12px",
      background: "var(--slate-100)",
      color: "var(--slate-700)",
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      fontWeight: 500,
      lineHeight: 1,
      borderRadius: "var(--radius-md)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--slate-500)",
      flex: "none"
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatTile({
  value,
  label,
  tone = "blue",
  align = "center",
  style = {},
  ...rest
}) {
  const tones = {
    blue: "var(--blue-600)",
    green: "var(--green-600)",
    dark: "var(--slate-900)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      alignItems: align === "center" ? "center" : "flex-start",
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 40,
      lineHeight: 1,
      color: tones[tone] || tones.blue,
      letterSpacing: "-0.01em"
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, label));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Alert({
  title = null,
  children,
  variant = "info",
  icon = null,
  onDismiss = null,
  style = {},
  ...rest
}) {
  const variants = {
    info: {
      bg: "var(--blue-100)",
      titleC: "var(--blue-700)",
      bodyC: "var(--slate-600)"
    },
    success: {
      bg: "var(--green-100)",
      titleC: "var(--green-700)",
      bodyC: "var(--green-700)"
    },
    danger: {
      bg: "var(--red-100)",
      titleC: "var(--red-700)",
      bodyC: "var(--red-700)"
    },
    neutral: {
      bg: "var(--slate-100)",
      titleC: "var(--slate-900)",
      bodyC: "var(--slate-600)"
    }
  };
  const v = variants[variant] || variants.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      position: "relative",
      display: "flex",
      gap: 12,
      padding: "16px 18px",
      background: v.bg,
      borderRadius: "var(--radius-lg)",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      flex: "none",
      marginTop: 1,
      color: v.titleC
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      flex: 1,
      paddingRight: onDismiss ? 20 : 0
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: v.titleC
    }
  }, title), children && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.5,
      color: v.bodyC
    }
  }, children)), onDismiss && /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    "aria-label": "Dismiss",
    style: {
      position: "absolute",
      top: 14,
      right: 14,
      background: "none",
      border: "none",
      cursor: "pointer",
      color: v.bodyC,
      opacity: 0.6,
      display: "inline-flex",
      padding: 2
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }))));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Stepper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Stepper({
  steps = [],
  current = 0,
  allComplete = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "flex-start",
      width: "100%",
      ...style
    }
  }, rest), steps.map((label, i) => {
    const done = allComplete || i < current;
    const active = !allComplete && i === current;
    const circleBg = done ? "var(--green-600)" : active ? "var(--blue-600)" : "var(--white)";
    const circleRing = done || active ? "none" : "inset 0 0 0 2px var(--slate-300)";
    const numColor = done || active ? "var(--white)" : "var(--slate-400)";
    const labelColor = done ? "var(--green-700)" : active ? "var(--blue-600)" : "var(--slate-400)";
    const labelWeight = active || done ? 700 : 500;
    const lineDone = allComplete || i < current;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: i
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 8,
        flex: "none",
        width: 96
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 34,
        height: 34,
        borderRadius: "50%",
        background: circleBg,
        boxShadow: circleRing,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        fontWeight: 700,
        color: numColor,
        transition: "all var(--dur-base) var(--ease-out)"
      }
    }, done ? /*#__PURE__*/React.createElement("svg", {
      width: "16",
      height: "16",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "#fff",
      strokeWidth: "3.5",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "20 6 9 17 4 12"
    })) : i + 1), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-sans)",
        fontSize: 13,
        fontWeight: labelWeight,
        color: labelColor,
        textAlign: "center",
        whiteSpace: "nowrap"
      }
    }, label)), i < steps.length - 1 && /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 2,
        marginTop: 16,
        borderRadius: 2,
        background: lineDone ? "var(--green-600)" : active ? "var(--blue-600)" : "var(--slate-200)",
        transition: "background var(--dur-base) var(--ease-out)"
      }
    }));
  }));
}
Object.assign(__ds_scope, { Stepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Stepper.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label = null,
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  id,
  style = {},
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const inputId = id || React.useId();
  const toggle = e => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on, e);
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      userSelect: "none",
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: "checkbox",
    checked: on,
    onChange: toggle,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 22,
      height: 22,
      flex: "none",
      borderRadius: 6,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: on ? "var(--blue-600)" : "var(--white)",
      boxShadow: on ? "none" : "inset 0 0 0 2px var(--slate-300)",
      transition: "background var(--dur-fast) var(--ease-out)"
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 500,
      color: "var(--slate-700)",
      whiteSpace: "nowrap"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label = null,
  hint = null,
  type = "text",
  value,
  defaultValue,
  placeholder = "",
  disabled = false,
  rightIcon = null,
  id,
  onChange,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      height: 52,
      padding: rightIcon ? "0 46px 0 16px" : "0 16px",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--slate-900)",
      background: disabled ? "var(--slate-100)" : "var(--white)",
      border: "none",
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "inset 0 0 0 1px var(--blue-600), var(--focus-ring)" : "inset 0 0 0 1px var(--slate-200)",
      outline: "none",
      transition: "box-shadow var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, rest)), rightIcon && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 16,
      display: "inline-flex",
      color: "var(--slate-400)",
      pointerEvents: "none"
    }
  }, rightIcon)), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function RadioCard({
  title,
  description = null,
  selected = false,
  onSelect,
  name,
  value,
  disabled = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      width: "100%",
      padding: "18px 20px",
      background: "var(--white)",
      borderRadius: "var(--radius-lg)",
      boxShadow: selected ? "inset 0 0 0 2px var(--blue-600)" : hover ? "inset 0 0 0 1px var(--slate-300)" : "inset 0 0 0 1px var(--slate-200)",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "box-shadow var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    value: value,
    checked: selected,
    disabled: disabled,
    onChange: () => onSelect && onSelect(value),
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: 22,
      height: 22,
      flex: "none",
      marginTop: 1,
      borderRadius: "50%",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--white)",
      boxShadow: selected ? "inset 0 0 0 2px var(--blue-600)" : "inset 0 0 0 2px var(--slate-300)"
    }
  }, selected && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 11,
      height: 11,
      borderRadius: "50%",
      background: "var(--blue-600)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, title), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)",
      lineHeight: 1.4
    }
  }, description)));
}
Object.assign(__ds_scope, { RadioCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label = null,
  hint = null,
  value,
  defaultValue,
  onChange,
  disabled = false,
  placeholder = "Select an option",
  options = [],
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: inputId,
    value: value,
    defaultValue: defaultValue,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      height: 52,
      padding: "0 44px 0 16px",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: value || defaultValue ? "var(--slate-900)" : "var(--slate-400)",
      background: disabled ? "var(--slate-100)" : "var(--white)",
      border: "none",
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "inset 0 0 0 1px var(--blue-600), var(--focus-ring)" : "inset 0 0 0 1px var(--slate-200)",
      outline: "none",
      appearance: "none",
      WebkitAppearance: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "box-shadow var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true,
    hidden: true
  }, placeholder), options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lab = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lab);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 16,
      pointerEvents: "none",
      color: "var(--slate-500)",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Textarea({
  label = null,
  hint = null,
  placeholder = "",
  rows = 4,
  value,
  defaultValue,
  disabled = false,
  id,
  onChange,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      padding: "14px 16px",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--slate-900)",
      background: disabled ? "var(--slate-100)" : "var(--white)",
      border: "none",
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "inset 0 0 0 1px var(--blue-600), var(--focus-ring)" : "inset 0 0 0 1px var(--slate-200)",
      outline: "none",
      resize: "vertical",
      transition: "box-shadow var(--dur-fast) var(--ease-out)",
      ...style
    }
  }, rest)), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)"
    }
  }, hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/layout/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  children,
  variant = "default",
  padding = 24,
  radius = "var(--radius-xl)",
  style = {},
  ...rest
}) {
  const variants = {
    default: {
      background: "var(--white)",
      boxShadow: "var(--shadow-card)"
    },
    elevated: {
      background: "var(--white)",
      boxShadow: "var(--shadow-md)"
    },
    inset: {
      background: "var(--slate-100)",
      boxShadow: "none"
    },
    info: {
      background: "var(--blue-100)",
      boxShadow: "none"
    },
    success: {
      background: "var(--green-100)",
      boxShadow: "none"
    },
    danger: {
      background: "var(--red-100)",
      boxShadow: "none"
    },
    outline: {
      background: "var(--white)",
      boxShadow: "inset 0 0 0 1px var(--blue-200)"
    }
  };
  const v = variants[variant] || variants.default;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: v.background,
      boxShadow: v.boxShadow,
      borderRadius: radius,
      padding: typeof padding === "number" ? padding : padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Card.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/app.jsx
try { (() => {
// Booking-app router / interactive state machine.
const A_DS = window.ZumperDesignSystem_74a932;
function PlaceholderScreen({
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "80px 80px",
      maxWidth: 1280,
      margin: "0 auto",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(A_DS.Card, {
    padding: 56
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 28,
      color: "var(--slate-900)"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--slate-500)",
      marginTop: 10
    }
  }, sub)));
}
function App() {
  const [screen, setScreen] = React.useState("home");
  const [signedIn, setSignedIn] = React.useState(false);
  const [modal, setModal] = React.useState(null);
  const [reason, setReason] = React.useState("Change in plans");
  const go = s => {
    window.scrollTo(0, 0);
    setScreen(s);
  };
  const signIn = () => {
    setSignedIn(true);
    go("bookings");
  };
  const navActive = {
    home: "home",
    bookings: "bookings",
    detail: "bookings",
    "cancel-reason": "bookings",
    "cancel-complete": "bookings",
    support: "bookings",
    "support-submitted": "bookings"
  }[screen] || screen;
  let body;
  switch (screen) {
    case "home":
      body = /*#__PURE__*/React.createElement(window.ZHomeScreen, {
        onSignIn: () => go("signin"),
        onView: () => signedIn ? go("detail") : go("signin")
      });
      break;
    case "signin":
      body = /*#__PURE__*/React.createElement(window.ZSignInScreen, {
        onSignIn: signIn,
        onBack: () => go("home")
      });
      break;
    case "bookings":
      body = /*#__PURE__*/React.createElement(window.ZBookingsScreen, {
        onOrderDetails: () => go("detail"),
        onSupport: () => go("support"),
        onBrowse: () => go("browse")
      });
      break;
    case "detail":
      body = /*#__PURE__*/React.createElement(window.ZBookingDetailScreen, {
        onBack: () => go("bookings"),
        onCancel: () => go("cancel-reason"),
        onSupport: () => go("support")
      });
      break;
    case "cancel-reason":
      body = /*#__PURE__*/React.createElement(window.ZCancelReasonScreen, {
        onBack: () => go("detail"),
        onConfirm: r => {
          setReason(r);
          setModal("confirm");
        }
      });
      break;
    case "cancel-complete":
      body = /*#__PURE__*/React.createElement(window.ZCancelCompleteScreen, {
        reason: reason,
        onBookings: () => go("bookings"),
        onHome: () => go("home"),
        onSupport: () => go("support")
      });
      break;
    case "support":
      body = /*#__PURE__*/React.createElement(window.ZSupportScreen, {
        onBack: () => go(signedIn ? "detail" : "home"),
        onSubmit: () => go("support-submitted")
      });
      break;
    case "support-submitted":
      body = /*#__PURE__*/React.createElement(window.ZSupportSubmittedScreen, {
        onBookings: () => go("bookings"),
        onHome: () => go("home")
      });
      break;
    case "browse":
      body = /*#__PURE__*/React.createElement(PlaceholderScreen, {
        title: "Browse listings",
        sub: "1,200+ verified rentals near UTM \u2014 listing search lives outside this prototype's scope."
      });
      break;
    case "listings":
      body = /*#__PURE__*/React.createElement(PlaceholderScreen, {
        title: "Listings",
        sub: "Manage and publish listings \u2014 outside this prototype's scope."
      });
      break;
    default:
      body = /*#__PURE__*/React.createElement(PlaceholderScreen, {
        title: "Coming soon",
        sub: ""
      });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement(window.ZNav, {
    active: navActive,
    signedIn: signedIn,
    onNav: k => go(k === "home" ? "home" : k),
    onSignIn: () => go("signin"),
    right: screen === "signin" ? /*#__PURE__*/React.createElement(window.ZBackLink, {
      onClick: () => go("home")
    }, "Back to Home") : undefined
  }), body, modal === "confirm" && /*#__PURE__*/React.createElement(window.ZCancelConfirmModal, {
    reason: reason,
    onClose: () => setModal(null),
    onConfirm: () => {
      setModal(null);
      go("cancel-complete");
    }
  }));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/icons.jsx
try { (() => {
// Lucide-derived icon set (MIT). Stroke icons unless listed in FILLED.
// <Icon name="map-pin" size={18} /> — colour inherits via currentColor.
const ICON_PATHS = {
  "map-pin": '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
  wifi: '<path d="M12 20h.01"/><path d="M2 8.82a15 15 0 0 1 20 0"/><path d="M5 12.859a10 10 0 0 1 14 0"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/>',
  car: '<path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.5 2.8A3 3 0 0 0 2 13v3c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/>',
  calendar: '<rect width="18" height="18" x="3" y="4" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  "shield-check": '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  "check-circle": '<path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/>',
  "chevron-down": '<path d="m6 9 6 6 6-6"/>',
  "chevron-left": '<path d="m15 18-6-6 6-6"/>',
  "chevron-right": '<path d="m9 18 6-6-6-6"/>',
  "arrow-left": '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  building: '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M12 6h.01M12 10h.01M12 14h.01M16 10h.01M16 14h.01M8 10h.01M8 14h.01"/>',
  "message-square": '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  mail: '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
  "life-buoy": '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="4"/><path d="m4.93 4.93 4.24 4.24M14.83 9.17l4.24-4.24M14.83 14.83l4.24 4.24M9.17 14.83l-4.24 4.24"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  "credit-card": '<rect width="20" height="14" x="2" y="5" rx="2"/><path d="M2 10h20"/>',
  user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  "file-text": '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v5h5M16 13H8M16 17H8M10 9H8"/>',
  "rotate-cw": '<path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v5h-5"/>',
  "google-g": '<path d="M21.35 11.1H12v3.2h5.35c-.25 1.4-1.6 4.1-5.35 4.1A6.4 6.4 0 1 1 12 5.6a5.7 5.7 0 0 1 4 1.55l2.2-2.1A9.5 9.5 0 1 0 12 21.6c5.5 0 9.1-3.85 9.1-9.3 0-.6-.05-1.1-.15-1.6z"/>',
  eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  "eye-off": '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>'
};
const FILLED = {
  star: '<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.12 2.12 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.12 2.12 0 0 0 1.597-1.16z"/>',
  zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
  sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
  "shield-solid": '<path d="M12 2c-.3 0-.5.1-.76.27C9.5 3.81 7 5 5 5a1 1 0 0 0-1 1v7c0 5 3.5 7.5 7.66 8.95.22.07.46.07.67 0C16.5 20.5 20 18 20 13V6a1 1 0 0 0-1-1c-2 0-4.5-1.2-6.24-2.73A1.2 1.2 0 0 0 12 2z"/>'
};
function Icon({
  name,
  size = 18,
  strokeWidth = 2,
  color = "currentColor",
  style = {}
}) {
  const filled = FILLED[name];
  const inner = filled || ICON_PATHS[name] || "";
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: filled ? color : "none",
    stroke: filled ? "none" : color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: "block",
      flex: "none",
      ...style
    },
    dangerouslySetInnerHTML: {
      __html: inner
    }
  });
}
window.ZIcon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/screens-bookings.jsx
try { (() => {
// My Bookings dashboard + Booking detail (Order Details).
const B_DS = window.ZumperDesignSystem_74a932;
const BIcon = window.ZIcon;
function SegTabs({
  tabs,
  active,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      background: "var(--slate-100)",
      borderRadius: "var(--radius-md)",
      padding: 4,
      gap: 2
    }
  }, tabs.map(t => {
    const on = active === t;
    return /*#__PURE__*/React.createElement("button", {
      key: t,
      onClick: () => onChange(t),
      style: {
        border: "none",
        cursor: "pointer",
        background: on ? "var(--white)" : "transparent",
        boxShadow: on ? "var(--shadow-xs)" : "none",
        color: on ? "var(--slate-900)" : "var(--slate-500)",
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        fontWeight: on ? 700 : 500,
        padding: "8px 18px",
        borderRadius: "var(--radius-sm)"
      }
    }, t);
  }));
}
function InsetStat({
  label,
  value,
  sub
}) {
  return /*#__PURE__*/React.createElement(B_DS.Card, {
    variant: "inset",
    padding: 16,
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, {
    style: {
      fontSize: 11
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      fontWeight: 700,
      color: "var(--slate-900)",
      marginTop: 8
    }
  }, value), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 2
    }
  }, sub));
}
function BookingsScreen({
  onOrderDetails,
  onSupport,
  onBrowse
}) {
  const [tab, setTab] = React.useState("Active (1)");
  const [showAlert, setShowAlert] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 80px 64px",
      maxWidth: 1280,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(B_DS.Card, {
    padding: 40
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Dashboard"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 40,
      color: "var(--slate-900)",
      margin: "10px 0 0"
    }
  }, "My Bookings"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      color: "var(--slate-500)",
      margin: "10px 0 0"
    }
  }, "Manage your active reservations, view refund status, and contact support.")), /*#__PURE__*/React.createElement(SegTabs, {
    tabs: ["Active (1)", "Cancelled", "Past"],
    active: tab,
    onChange: setTab
  }))), showAlert && tab === "Active (1)" && /*#__PURE__*/React.createElement(B_DS.Alert, {
    variant: "info",
    title: "Booking period approaching",
    icon: /*#__PURE__*/React.createElement(BIcon, {
      name: "clock",
      size: 18
    }),
    onDismiss: () => setShowAlert(false)
  }, "Your lease for Apartment 1-Bedroom Near UTM begins in 47 days. Complete any changes before Aug 15, 2025."), tab === "Active (1)" ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      fontWeight: 500,
      color: "var(--slate-500)"
    }
  }, "1 active booking"), /*#__PURE__*/React.createElement(B_DS.Card, {
    padding: 0,
    style: {
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "300px 1fr 248px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: "var(--blue-200)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/apartment-utm.png",
    alt: "Apartment",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 14,
      bottom: 14,
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      background: "var(--blue-600)",
      color: "#fff",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 700,
      padding: "5px 11px",
      borderRadius: "var(--radius-full)"
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    name: "map-pin",
    size: 13,
    color: "#fff"
  }), "Mississauga, ON")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(B_DS.Badge, {
    variant: "success",
    dot: true
  }, "Upcoming"), /*#__PURE__*/React.createElement(window.ZMeta, null, "Booking ID: ZMP-2025-04821"), /*#__PURE__*/React.createElement(window.ZMeta, null, "Booked June 12, 2025")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Hosted by Northfield Property Group"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 22,
      fontWeight: 700,
      color: "var(--slate-900)",
      marginTop: 8
    }
  }, "Apartment 1-Bedroom Near UTM"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "map-pin"
  }, "2090 Hurontario St, Unit 5B, Mississauga, ON L5B 1M3")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      marginTop: 8,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "star"
  }, "4.9 (128 reviews)"), /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "wifi"
  }, "Utilities included"), /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "car"
  }, "Free parking"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(InsetStat, {
    label: "Lease dates",
    value: "Sept 1, 2025 \u2013 Aug 31, 2026"
  }), /*#__PURE__*/React.createElement(InsetStat, {
    label: "Monthly rent",
    value: "$1,850 / month"
  }), /*#__PURE__*/React.createElement(InsetStat, {
    label: "Total amount",
    value: "$22,200 + $500 deposit"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      borderLeft: "1px solid var(--slate-200)",
      display: "flex",
      flexDirection: "column",
      gap: 12,
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "primary",
    fullWidth: true,
    onClick: onOrderDetails
  }, "Order Details"), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(BIcon, {
      name: "download",
      size: 16
    })
  }, "Download Lease"), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(BIcon, {
      name: "message-square",
      size: 16
    })
  }, "Message Host"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      textAlign: "center",
      margin: "4px 0 0",
      lineHeight: 1.4
    }
  }, "Open the booking to manage your reservation")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(B_DS.Card, {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 11,
      background: "var(--blue-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    name: "life-buoy",
    size: 20,
    color: "var(--blue-600)"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "Need help with a booking?"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 2
    }
  }, "Our support team responds within 24 hours"))), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    onClick: onSupport
  }, "Contact Support")), /*#__PURE__*/React.createElement(B_DS.Card, {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 11,
      background: "var(--blue-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    name: "building",
    size: 20,
    color: "var(--blue-600)"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "Looking for a new place?"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 2
    }
  }, "Browse 1,200+ verified listings near UTM"))), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "primary",
    onClick: onBrowse
  }, "Browse Listings")))) : /*#__PURE__*/React.createElement(B_DS.Card, {
    padding: 48,
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "var(--slate-100)",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    name: tab === "Cancelled" ? "x" : "clock",
    size: 24,
    color: "var(--slate-400)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 18,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "No ", tab.toLowerCase(), " bookings"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)",
      marginTop: 6
    }
  }, "When you have ", tab.toLowerCase(), " bookings, they'll appear here.")));
}
function MiniPanel({
  icon,
  label,
  title,
  sub,
  tone
}) {
  const titleColor = tone === "green" ? "var(--green-700)" : "var(--slate-900)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--white)",
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    name: icon,
    size: 15,
    color: "var(--slate-500)"
  }), /*#__PURE__*/React.createElement(window.ZEyebrow, {
    style: {
      fontSize: 11
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      fontWeight: 700,
      color: titleColor,
      marginTop: 10
    }
  }, title), sub && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: tone === "green" ? "var(--green-600)" : "var(--slate-500)",
      marginTop: 4
    }
  }, sub));
}
function BookingDetailScreen({
  onBack,
  onCancel,
  onSupport
}) {
  const highlights = ["High-speed Wi-Fi", "Heat included", "Hydro included", "Pool access", "Free parking", "Pet friendly", "Gym access", "In-unit laundry"];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "28px 80px 64px",
      maxWidth: 1280,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--blue-600)",
      fontWeight: 500
    }
  }, "My Bookings"), /*#__PURE__*/React.createElement(BIcon, {
    name: "chevron-right",
    size: 14,
    color: "var(--slate-400)"
  }), "Apartment 1-Bedroom Near UTM"), /*#__PURE__*/React.createElement(window.ZBackLink, {
    onClick: onBack
  }, "Back to My Bookings"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 360px",
      gap: 24,
      marginTop: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(B_DS.Card, {
    padding: 0,
    style: {
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 250,
      background: "var(--blue-200)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/apartment-utm.png",
    alt: "Apartment",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: "50%",
      top: "50%",
      transform: "translate(-50%,-50%)",
      background: "rgba(255,255,255,0.94)",
      color: "var(--blue-600)",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      padding: "8px 16px",
      borderRadius: "var(--radius-full)",
      boxShadow: "var(--shadow-sm)"
    }
  }, "Apartment 1-Bedroom Near UTM")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(B_DS.Badge, {
    variant: "success",
    dot: true
  }, "Upcoming"), /*#__PURE__*/React.createElement(window.ZMeta, null, "Booking ID: ZMP-2025-04821"), /*#__PURE__*/React.createElement(window.ZMeta, null, "\xB7"), /*#__PURE__*/React.createElement(window.ZMeta, null, "Booked June 12, 2025")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 30,
      color: "var(--slate-900)",
      margin: 0
    }
  }, "Apartment 1-Bedroom Near UTM"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "map-pin"
  }, "2090 Hurontario St, Unit 5B, Mississauga, ON L5B 1M3")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      marginTop: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "star"
  }, "4.9 (128 reviews)"), /*#__PURE__*/React.createElement(window.ZMeta, {
    icon: "shield-check",
    color: "var(--green-600)"
  }, "UTM Verified"), /*#__PURE__*/React.createElement(window.ZMeta, null, "5 min walk to campus"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 1,
      background: "var(--slate-200)",
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      boxShadow: "inset 0 0 0 1px var(--slate-200)"
    }
  }, /*#__PURE__*/React.createElement(MiniPanel, {
    icon: "calendar",
    label: "Booking dates",
    title: "Sept 1, 2025 \u2013 Aug 31, 2026",
    sub: "12-month lease \xB7 47 days until start"
  }), /*#__PURE__*/React.createElement(MiniPanel, {
    icon: "credit-card",
    label: "Payment summary",
    title: "$1,850/month \xB7 $500 deposit",
    sub: "Total $22,700 \xB7 Deposit paid June 12"
  }), /*#__PURE__*/React.createElement(MiniPanel, {
    icon: "user",
    label: "Host",
    title: "RentCorp",
    sub: "4.9 \xB7 Verified landlord since 2022"
  }), /*#__PURE__*/React.createElement(MiniPanel, {
    icon: "rotate-cw",
    label: "Refund policy",
    title: "Full deposit if cancelled 30+ days before",
    sub: "\u2713 Currently eligible \xB7 47 days left",
    tone: "green"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: "var(--slate-200)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Property highlights"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 10,
      marginTop: 14
    }
  }, highlights.map(h => /*#__PURE__*/React.createElement(B_DS.Tag, {
    key: h
  }, h)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(B_DS.Avatar, {
    initials: "RC",
    size: 44
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "RentCorp"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 2
    }
  }, "4.9 \xB7 847 reviews \xB7 Verified since 2019"))), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    onClick: onSupport
  }, "Message Host")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      position: "sticky",
      top: 24
    }
  }, /*#__PURE__*/React.createElement(B_DS.Card, null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Booking actions"), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 22,
      color: "var(--slate-900)",
      margin: "8px 0 10px"
    }
  }, "Order Details"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "0 0 16px"
    }
  }, "You can modify or cancel this booking before your lease start date. You are currently within the eligible cancellation window."), /*#__PURE__*/React.createElement(B_DS.Alert, {
    variant: "success",
    title: "Eligible Cancellation",
    icon: /*#__PURE__*/React.createElement(BIcon, {
      name: "check-circle",
      size: 18
    }),
    style: {
      marginBottom: 16
    }
  }, "Full $500 deposit refund available now"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "danger-outline",
    fullWidth: true,
    onClick: onCancel
  }, "Cancel Booking"), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    onClick: onSupport
  }, "Contact Support"), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(BIcon, {
      name: "download",
      size: 16
    })
  }, "Download Confirmation"), /*#__PURE__*/React.createElement(B_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(BIcon, {
      name: "file-text",
      size: 16
    })
  }, "View Lease Agreement"))), /*#__PURE__*/React.createElement(B_DS.Card, {
    variant: "inset"
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Need help?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "10px 0 14px"
    }
  }, "Our support team handles disputes, refund issues, and lease questions. We're here for you every step of the way."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      paddingTop: 12,
      borderTop: "1px solid var(--slate-200)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "Refund disputes"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      color: "var(--green-600)"
    }
  }, "Covered"))), /*#__PURE__*/React.createElement(B_DS.Card, {
    variant: "outline"
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, {
    color: "var(--blue-600)"
  }, "Cancellation window"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 40,
      color: "var(--blue-600)",
      margin: "10px 0 4px"
    }
  }, "47 days"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "until your full refund window expires"), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      borderRadius: 3,
      background: "var(--slate-200)",
      margin: "14px 0",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "62%",
      height: "100%",
      background: "var(--blue-600)",
      borderRadius: 3
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)"
    }
  }, "Cancel before ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--slate-700)"
    }
  }, "Aug 15, 2025"), " to keep your full deposit refund.")))));
}
Object.assign(window, {
  ZBookingsScreen: BookingsScreen,
  ZBookingDetailScreen: BookingDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/screens-bookings.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/screens-cancel.jsx
try { (() => {
// Cancellation flow: Reason → Confirm modal → Complete.
const C_DS = window.ZumperDesignSystem_74a932;
const CIcon = window.ZIcon;
const REASONS = [{
  v: "found",
  t: "Found another place",
  d: "I found a better-suited rental elsewhere"
}, {
  v: "plans",
  t: "Change in plans",
  d: "My living situation has changed significantly"
}, {
  v: "price",
  t: "Price concerns",
  d: "The rental cost is outside my current budget"
}, {
  v: "problem",
  t: "Problem with property",
  d: "I have concerns about the listing or host"
}, {
  v: "other",
  t: "Other reason",
  d: "Please describe in the field below"
}];
function CancelReasonScreen({
  onBack,
  onConfirm
}) {
  const [reason, setReason] = React.useState("problem");
  const reasonLabel = REASONS.find(r => r.v === reason)?.t;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "28px 80px 64px",
      maxWidth: 1280,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement(window.ZBackLink, {
    onClick: onBack
  }, "Back to Booking Details"), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 620,
      margin: "18px 0 26px"
    }
  }, /*#__PURE__*/React.createElement(C_DS.Stepper, {
    steps: ["Details", "Reason", "Confirm", "Complete"],
    current: 1
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 360px",
      gap: 24,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(C_DS.Card, {
    padding: 36
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Cancellation"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)",
      margin: "8px 0 0"
    }
  }, "Your response helps us improve the platform experience."), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 28,
      color: "var(--slate-900)",
      margin: "16px 0 12px"
    }
  }, "Why are you cancelling this booking?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "0 0 24px"
    }
  }, "Your feedback helps us improve the platform and support future students. Selecting a reason is required to proceed."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, REASONS.map(r => /*#__PURE__*/React.createElement(C_DS.RadioCard, {
    key: r.v,
    name: "cancel-reason",
    value: r.v,
    selected: reason === r.v,
    onSelect: setReason,
    title: r.t,
    description: r.d
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(C_DS.Textarea, {
    label: "Additional details (optional)",
    rows: 4,
    placeholder: "Provide any additional context that would help us understand your decision or improve the platform for future students\u2026"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      position: "sticky",
      top: 24
    }
  }, /*#__PURE__*/React.createElement(C_DS.Card, {
    variant: "success",
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, {
    color: "var(--green-700)"
  }, "Refund summary"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 44,
      color: "var(--green-600)",
      margin: "10px 0 6px"
    }
  }, "$500.00"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--green-700)"
    }
  }, "Full deposit refund"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      lineHeight: 1.5,
      color: "var(--green-700)",
      margin: "10px 0 0",
      opacity: 0.9
    }
  }, "Refund will be processed to your original payment method within 5\u20137 business days of cancellation confirmation.")), /*#__PURE__*/React.createElement(C_DS.Card, null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Booking summary"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Property",
    value: "Apartment 1BR Near UTM"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Booking ID",
    value: "ZMP-2025-04821",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Lease dates",
    value: "Sept 1 \u2013 Aug 31, 2026"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Cancellation reason",
    value: reasonLabel,
    valueColor: "var(--slate-900)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Refund eligible",
    value: "Yes \u2014 full deposit",
    valueColor: "var(--green-600)"
  }))), /*#__PURE__*/React.createElement(C_DS.Alert, {
    variant: "danger",
    title: "Important reminder",
    icon: /*#__PURE__*/React.createElement(CIcon, {
      name: "x",
      size: 18
    })
  }, "Once cancelled, this booking cannot be reinstated. You will need to start a new booking if you change your mind."), /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "danger",
    size: "lg",
    fullWidth: true,
    onClick: () => onConfirm(reasonLabel)
  }, "Confirm Cancel Booking"))));
}
function CancelConfirmModal({
  reason,
  onConfirm,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(15,23,42,0.55)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      zIndex: 50,
      padding: 24
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: 460,
      background: "var(--white)",
      borderRadius: "var(--radius-2xl)",
      boxShadow: "var(--shadow-lg)",
      padding: 40,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: "50%",
      background: "var(--red-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "0 auto 18px"
    }
  }, /*#__PURE__*/React.createElement(CIcon, {
    name: "x",
    size: 28,
    color: "var(--red-600)",
    strokeWidth: 2.5
  })), /*#__PURE__*/React.createElement(window.ZEyebrow, {
    color: "var(--red-600)"
  }, "Confirm cancellation"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 26,
      color: "var(--slate-900)",
      margin: "8px 0 10px"
    }
  }, "Are you sure you want to cancel?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "0 0 22px"
    }
  }, "This action is permanent and cannot be undone. Your booking will be cancelled immediately and your full refund will be initiated."), /*#__PURE__*/React.createElement(C_DS.Card, {
    variant: "inset",
    padding: 20,
    style: {
      textAlign: "left",
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Booking",
    value: "Apartment 1BR Near UTM"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Cancellation reason",
    value: reason
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Refund amount",
    value: "$500.00 (full deposit)",
    valueColor: "var(--green-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Refund timeline",
    value: "5\u20137 business days"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Payment method",
    value: "Visa ending in \xB7\xB7 4821"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "danger",
    size: "lg",
    fullWidth: true,
    onClick: onConfirm
  }, "Yes, Cancel Booking"), /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "secondary",
    size: "lg",
    fullWidth: true,
    onClick: onClose
  }, "Return to Booking"))));
}
function ResultTile({
  tone,
  label,
  value,
  sub
}) {
  const bg = tone === "green" ? "var(--green-100)" : "var(--slate-100)";
  const valC = tone === "green" ? "var(--green-600)" : tone === "blue" ? "var(--blue-600)" : "var(--slate-900)";
  const labC = tone === "green" ? "var(--green-700)" : "var(--slate-500)";
  const icon = tone === "green" ? "credit-card" : label === "Expected timeline" ? "clock" : "mail";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: bg,
      borderRadius: "var(--radius-xl)",
      padding: 24,
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 44,
      height: 44,
      borderRadius: 12,
      background: tone === "green" ? "var(--green-200)" : "var(--white)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 14,
      boxShadow: tone === "green" ? "none" : "var(--shadow-xs)"
    }
  }, /*#__PURE__*/React.createElement(CIcon, {
    name: icon,
    size: 20,
    color: valC
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color: labC
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: tone === "green" ? 28 : 20,
      color: valC,
      margin: "8px 0 4px"
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: labC
    }
  }, sub));
}
function CancelCompleteScreen({
  reason,
  onBookings,
  onHome,
  onSupport
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 80px 64px",
      maxWidth: 1080,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 620,
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "var(--green-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(CIcon, {
    name: "check",
    size: 26,
    color: "var(--green-600)",
    strokeWidth: 3
  })), /*#__PURE__*/React.createElement(C_DS.Stepper, {
    steps: ["Details", "Reason", "Confirmed", "Complete"],
    allComplete: true
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 38,
      color: "var(--slate-900)",
      margin: "28px 0 0"
    }
  }, "Your booking has been cancelled"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 17,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "16px auto 0",
      maxWidth: 660
    }
  }, "Your reservation for ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--slate-700)"
    }
  }, "Apartment 1-Bedroom Near UTM"), " has been successfully cancelled. Your full deposit refund of ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--slate-700)"
    }
  }, "$500.00"), " is now being processed."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr 1fr",
      gap: 16,
      margin: "32px 0"
    }
  }, /*#__PURE__*/React.createElement(ResultTile, {
    tone: "green",
    label: "Refund amount",
    value: "$500.00",
    sub: "Full deposit returned"
  }), /*#__PURE__*/React.createElement(ResultTile, {
    tone: "dark",
    label: "Expected timeline",
    value: "5\u20137 Business Days",
    sub: "To your Visa \xB7\xB7 4821"
  }), /*#__PURE__*/React.createElement(ResultTile, {
    tone: "blue",
    label: "Confirmation",
    value: "ZMP-CANC-04821",
    sub: "Sent to your email"
  })), /*#__PURE__*/React.createElement(C_DS.Card, {
    variant: "inset",
    padding: 28,
    style: {
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Cancellation record"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "0 48px",
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Booking ID",
    value: "ZMP-2025-04821",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Cancelled on",
    value: "July 15, 2025 at 2:34 PM"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Cancellation ref",
    value: "ZMP-CANC-04821",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Reason",
    value: reason
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Property",
    value: "Apartment 1BR Near UTM"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Refund status",
    value: "Processing \u2713",
    valueColor: "var(--green-600)"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      justifyContent: "center",
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "primary",
    size: "lg",
    onClick: onBookings
  }, "Back to My Bookings"), /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "secondary",
    size: "lg",
    onClick: onSupport
  }, "Contact Support"), /*#__PURE__*/React.createElement(C_DS.Button, {
    variant: "secondary",
    size: "lg",
    leftIcon: /*#__PURE__*/React.createElement(CIcon, {
      name: "download",
      size: 16
    }),
    onClick: onHome
  }, "Download Confirmation")));
}
Object.assign(window, {
  ZCancelReasonScreen: CancelReasonScreen,
  ZCancelConfirmModal: CancelConfirmModal,
  ZCancelCompleteScreen: CancelCompleteScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/screens-cancel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/screens-marketing.jsx
try { (() => {
// Home (signed-out & signed-in) and Sign In screens.
const M_DS = window.ZumperDesignSystem_74a932;
const MIcon = window.ZIcon;
function FeatureTile({
  icon,
  title,
  body,
  divider
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      paddingLeft: divider ? 22 : 0,
      borderLeft: divider ? "1px solid rgba(255,255,255,0.22)" : "none",
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9
    }
  }, /*#__PURE__*/React.createElement(MIcon, {
    name: icon,
    size: 17,
    color: "#fff"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      fontWeight: 700,
      color: "#fff"
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      lineHeight: 1.5,
      color: "rgba(255,255,255,0.82)"
    }
  }, body));
}
function PropertyCard({
  onView
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--white)",
      borderRadius: "var(--radius-2xl)",
      boxShadow: "var(--shadow-card)",
      overflow: "hidden",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: 260,
      background: "var(--blue-200)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/apartment-utm.png",
    alt: "Apartment interior near UTM",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: "50%",
      top: "50%",
      transform: "translate(-50%,-50%)",
      background: "rgba(255,255,255,0.94)",
      color: "var(--blue-600)",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      padding: "8px 16px",
      borderRadius: "var(--radius-full)",
      boxShadow: "var(--shadow-sm)",
      whiteSpace: "nowrap"
    }
  }, "Apartment 1-Bedroom Near UTM")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(M_DS.Badge, {
    variant: "info",
    dot: true
  }, "UTM Verified"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(window.ZStars, {
    value: 5
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "4.9 (128)"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 22,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "Student housing"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)",
      marginTop: 8
    }
  }, "2090 Hurontario St, Mississauga \xB7 5 min walk to UTM")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(window.ZCheckItem, null, "Lease starts Sept 1, 2025 \u2014 12 months"), /*#__PURE__*/React.createElement(window.ZCheckItem, null, "Utilities included \u2014 Wi-Fi, heat, hydro"), /*#__PURE__*/React.createElement(window.ZCheckItem, null, "Refundable $500 deposit with clear timeline"), /*#__PURE__*/React.createElement(window.ZCheckItem, null, "Support response within 24 hours")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: "var(--slate-200)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 26,
      fontWeight: 900,
      color: "var(--slate-900)"
    }
  }, "$1,850"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "/mo")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 2
    }
  }, "+ $500 refundable deposit")), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "primary",
    onClick: onView
  }, "View Booking"))));
}
function HomeScreen({
  onSignIn,
  onView
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "48px 80px 64px",
      maxWidth: 1440,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.32fr 1fr",
      gap: 24,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      overflow: "hidden",
      borderRadius: "var(--radius-2xl)",
      background: "var(--gradient-hero)",
      padding: 48,
      minHeight: 642,
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 200,
      height: 200,
      borderRadius: "50%",
      background: "rgba(255,255,255,0.05)",
      bottom: 30,
      left: 30
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      width: 260,
      height: 260,
      borderRadius: "50%",
      background: "rgba(255,255,255,0.04)",
      top: -60,
      right: -40
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      alignSelf: "flex-start",
      background: "rgba(255,255,255,0.16)",
      color: "#fff",
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      padding: "8px 14px",
      borderRadius: "var(--radius-full)"
    }
  }, /*#__PURE__*/React.createElement(MIcon, {
    name: "sparkles",
    size: 14,
    color: "#fff"
  }), "Verified Student Housing Near UTM"), /*#__PURE__*/React.createElement("h1", {
    style: {
      position: "relative",
      fontFamily: "var(--font-display)",
      fontWeight: 400,
      fontSize: 56,
      lineHeight: 1.04,
      color: "#fff",
      margin: "28px 0 0"
    }
  }, "Find reliable rentals. Manage bookings without confusion."), /*#__PURE__*/React.createElement("p", {
    style: {
      position: "relative",
      fontFamily: "var(--font-sans)",
      fontSize: 17,
      lineHeight: 1.5,
      color: "rgba(255,255,255,0.86)",
      margin: "20px 0 0",
      maxWidth: 520
    }
  }, "Browse verified listings, manage your reservation, and get clear refund and support information \u2014 all in one place."), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      gap: 14,
      marginTop: 32
    }
  }, /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "white",
    size: "lg",
    onClick: onSignIn
  }, "Sign In"), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "ghost",
    size: "lg",
    onClick: onView
  }, "Browse My Bookings")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      gap: 22,
      marginTop: 30,
      paddingTop: 24,
      borderTop: "1px solid rgba(255,255,255,0.22)"
    }
  }, /*#__PURE__*/React.createElement(FeatureTile, {
    icon: "check-circle",
    title: "Visible status",
    body: "Always know exactly where your booking stands"
  }), /*#__PURE__*/React.createElement(FeatureTile, {
    icon: "zap",
    title: "Clear actions",
    body: "Manage, cancel, or modify with zero confusion",
    divider: true
  }), /*#__PURE__*/React.createElement(FeatureTile, {
    icon: "life-buoy",
    title: "Support path",
    body: "Mediation and refund support at every step",
    divider: true
  }))), /*#__PURE__*/React.createElement(PropertyCard, {
    onView: onView
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      background: "var(--blue-100)",
      borderRadius: "var(--radius-xl)",
      padding: "40px 48px",
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)"
    }
  }, /*#__PURE__*/React.createElement(M_DS.StatTile, {
    value: "1,200+",
    label: "Verified listings"
  }), /*#__PURE__*/React.createElement(M_DS.StatTile, {
    value: "24hr",
    label: "Support response time"
  }), /*#__PURE__*/React.createElement(M_DS.StatTile, {
    value: "100%",
    label: "Refund clarity guaranteed"
  }), /*#__PURE__*/React.createElement(M_DS.StatTile, {
    value: "4.9\u2605",
    label: "Average platform rating"
  })));
}
function SignInScreen({
  onSignIn,
  onBack
}) {
  const [show, setShow] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "56px 80px 80px",
      display: "flex",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 460,
      background: "var(--white)",
      borderRadius: "var(--radius-2xl)",
      boxShadow: "var(--shadow-lg)",
      padding: 44
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(window.ZWordmark, {
    size: 30
  }), /*#__PURE__*/React.createElement(window.ZEyebrow, {
    style: {
      marginTop: 12
    }
  }, "Welcome back"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 28,
      color: "var(--slate-900)",
      margin: 0
    }
  }, "Sign in to your account"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--slate-500)",
      margin: 0
    }
  }, "Access your bookings and manage your reservations")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(M_DS.Input, {
    label: "Email address",
    defaultValue: "michael.stanley@mail.utoronto.ca"
  }), /*#__PURE__*/React.createElement(M_DS.Input, {
    label: "Password",
    type: show ? "text" : "password",
    defaultValue: "password123",
    rightIcon: /*#__PURE__*/React.createElement("button", {
      onClick: () => setShow(!show),
      style: {
        background: "none",
        border: "none",
        cursor: "pointer",
        pointerEvents: "auto",
        color: "var(--slate-400)",
        display: "inline-flex",
        padding: 0
      }
    }, /*#__PURE__*/React.createElement(MIcon, {
      name: show ? "eye-off" : "eye",
      size: 18
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(M_DS.Checkbox, {
    label: "Remember me",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "link",
    onClick: () => {}
  }, "Forgot password?")), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onSignIn
  }, "Sign In"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--slate-200)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)"
    }
  }, "or continue with"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: "var(--slate-200)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(MIcon, {
      name: "google-g",
      size: 18,
      color: "var(--blue-600)"
    }),
    onClick: onSignIn
  }, "Google"), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    leftIcon: /*#__PURE__*/React.createElement(MIcon, {
      name: "building",
      size: 17,
      color: "var(--blue-700)"
    }),
    onClick: onSignIn
  }, "U of T Portal")), /*#__PURE__*/React.createElement(M_DS.Button, {
    variant: "secondary",
    fullWidth: true,
    onClick: onBack
  }, "Back to Home"), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "14px 0 0",
      borderTop: "1px solid var(--slate-200)",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "Don't have an account? ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 700,
      color: "var(--slate-700)"
    }
  }, "Sign up free")))));
}
Object.assign(window, {
  ZHomeScreen: HomeScreen,
  ZSignInScreen: SignInScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/screens-marketing.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/screens-support.jsx
try { (() => {
// Contact Support / mediation form + request submitted.
const S_DS = window.ZumperDesignSystem_74a932;
const SIcon = window.ZIcon;
function ReachRow({
  icon,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "7px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 8,
      background: "var(--slate-900)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(SIcon, {
    name: icon,
    size: 14,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-700)"
    }
  }, children));
}
function SupportScreen({
  onBack,
  onSubmit
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "28px 80px 64px",
      maxWidth: 1280,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement(window.ZBackLink, {
    onClick: onBack
  }, "Back to Cancellation Confirmation"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 380px",
      gap: 24,
      marginTop: 16,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(S_DS.Card, {
    padding: 36
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Support & mediation"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 28,
      color: "var(--slate-900)",
      margin: "8px 0 10px"
    }
  }, "Contact Support"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "0 0 26px"
    }
  }, "Our support team handles refund disputes, lease questions, and landlord concerns. We're here to make sure your experience is fair and resolved quickly."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(S_DS.Input, {
    label: "Your name",
    defaultValue: "Michael Stanley",
    disabled: true
  }), /*#__PURE__*/React.createElement(S_DS.Input, {
    label: "Email address",
    defaultValue: "michael.stanley@mail.utoronto.ca",
    disabled: true
  })), /*#__PURE__*/React.createElement(S_DS.Input, {
    label: "Related booking",
    defaultValue: "ZMP-2025-04821 \u2014 Apartment 1-Bedroom Near UTM",
    disabled: true
  }), /*#__PURE__*/React.createElement(S_DS.Select, {
    label: "Issue type",
    placeholder: "Select an issue",
    options: ["Refund delay or dispute", "Refund amount incorrect", "Poor property condition or misrepresentation", "Lease agreement question", "Landlord communication issue"]
  }), /*#__PURE__*/React.createElement(S_DS.Textarea, {
    label: "Describe your issue",
    rows: 5,
    placeholder: "Please provide as much detail as possible about your concern. Include any dates, amounts, reference numbers, or communications you've had with the landlord\u2026",
    hint: "The more detail you provide, the faster we can resolve your case."
  }), /*#__PURE__*/React.createElement(S_DS.Alert, {
    variant: "info",
    title: "Expedited review available",
    icon: /*#__PURE__*/React.createElement(SIcon, {
      name: "zap",
      size: 18
    })
  }, "Refund disputes are given priority and reviewed within 4 business hours."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(S_DS.Button, {
    variant: "primary",
    size: "lg",
    style: {
      flex: 1
    },
    onClick: onSubmit
  }, "Submit Request"), /*#__PURE__*/React.createElement(S_DS.Button, {
    variant: "secondary",
    size: "lg",
    onClick: onBack
  }, "Back")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 20,
      position: "sticky",
      top: 24
    }
  }, /*#__PURE__*/React.createElement(S_DS.Card, null, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Your order details"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Property",
    value: "Apartment 1BR Near UTM"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "Booking status"), /*#__PURE__*/React.createElement(S_DS.Badge, {
    variant: "danger",
    dot: true
  }, "Cancelled")), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Cancellation ref",
    value: "ZMP-CANC-04821",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Refund amount",
    value: "$500.00",
    valueColor: "var(--green-600)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, "Refund status"), /*#__PURE__*/React.createElement(S_DS.Badge, {
    variant: "info",
    dot: true
  }, "Processing")))), /*#__PURE__*/React.createElement(S_DS.Card, {
    variant: "info"
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, {
    color: "var(--blue-700)"
  }, "Response time"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 34,
      color: "var(--blue-600)",
      margin: "10px 0 8px"
    }
  }, "Within 24 hrs"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.5,
      color: "var(--slate-600)",
      margin: "0 0 14px"
    }
  }, "A dedicated support agent will be assigned to your case and will reach out via email at alex.chen@mail.utoronto.ca."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, ["Direct agent assigned to your case", "Landlord mediation support available", "Refund escalation if delayed", "Student renter protections apply"].map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(SIcon, {
    name: "check",
    size: 15,
    color: "var(--green-600)",
    strokeWidth: 2.5
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-700)"
    }
  }, t))))), /*#__PURE__*/React.createElement(S_DS.Card, {
    variant: "inset"
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Other ways to reach us"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(ReachRow, {
    icon: "mail"
  }, "support@zumper.com"), /*#__PURE__*/React.createElement(ReachRow, {
    icon: "phone"
  }, "1-844-ZUMPER-1 (1-844-986-7371)"), /*#__PURE__*/React.createElement(ReachRow, {
    icon: "message-square"
  }, "Live chat available on this page")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 10
    }
  }, "Mon\u2013Fri 9:00am \u2013 6:00pm EST \xB7 Emergency support 24/7")))));
}
function SupportSubmittedScreen({
  onBookings,
  onHome
}) {
  const steps = [{
    n: 1,
    t: "Email confirmation sent now",
    d: "A confirmation with your case number SUP-42108 has been sent to alex.chen@mail.utoronto.ca. Keep it for your records."
  }, {
    n: 2,
    t: "Agent assigned within 4 hours",
    d: "A dedicated support specialist will review your refund case. Refund disputes are given priority processing."
  }, {
    n: 3,
    t: "Resolution within 24–48 hours",
    d: "We'll work directly with Northfield Property Group on your behalf and keep you updated at every step via email."
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "40px 80px 64px",
      maxWidth: 1080,
      margin: "0 auto",
      width: "100%",
      boxSizing: "border-box"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: "50%",
      background: "var(--green-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(SIcon, {
    name: "check",
    size: 26,
    color: "var(--green-600)",
    strokeWidth: 3
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: 900,
      fontSize: 38,
      color: "var(--slate-900)",
      margin: 0
    }
  }, "Your request has been submitted"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 16,
      lineHeight: 1.5,
      color: "var(--slate-500)",
      margin: "14px auto 0",
      maxWidth: 580
    }
  }, "Our support team has received your request and a dedicated agent will be assigned to your case right away."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      marginTop: 22,
      background: "var(--blue-100)",
      color: "var(--blue-700)",
      fontFamily: "var(--font-sans)",
      fontSize: 18,
      fontWeight: 700,
      padding: "12px 24px",
      borderRadius: "var(--radius-md)",
      boxShadow: "inset 0 0 0 1px var(--blue-200)"
    }
  }, "Case #SUP-42108"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-400)",
      marginTop: 8
    }
  }, "Save this number for your records"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--slate-500)",
      margin: "16px auto 0",
      maxWidth: 640
    }
  }, "A support agent will contact you at ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: "var(--slate-700)"
    }
  }, "michael.stanley@mail.utoronto.ca"), " within 24 hours. Check your inbox and spam folder.")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      margin: "32px 0 16px"
    }
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "What to expect next")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 20,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(S_DS.Card, {
    padding: 0
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: s.n,
    style: {
      display: "flex",
      gap: 14,
      padding: "18px 24px",
      borderTop: i ? "1px solid var(--slate-200)" : "none"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "50%",
      background: "var(--blue-100)",
      color: "var(--blue-600)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-sans)",
      fontWeight: 700,
      fontSize: 14,
      flex: "none"
    }
  }, s.n), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, s.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      lineHeight: 1.55,
      color: "var(--slate-600)",
      marginTop: 4
    }
  }, s.d))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(S_DS.Card, {
    variant: "inset",
    padding: 28
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(window.ZEyebrow, null, "Case summary")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "0 40px",
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Case number",
    value: "SUP-42108",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Related booking",
    value: "ZMP-2025-04821",
    valueColor: "var(--blue-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Issue type",
    value: "Refund delay or dispute"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Submitted",
    value: "July 15, 2025 \xB7 2:34 PM"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Attachment",
    value: "\u2713 1 file attached",
    valueColor: "var(--green-600)"
  }), /*#__PURE__*/React.createElement(window.ZDataRow, {
    label: "Expected response",
    value: "Within 24 hours",
    valueColor: "var(--green-600)"
  }))), /*#__PURE__*/React.createElement(S_DS.Card, {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 700,
      color: "var(--slate-900)"
    }
  }, "How was your experience submitting this request?"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 13,
      color: "var(--slate-500)",
      marginTop: 4
    }
  }, "Your feedback helps us improve support for all students")), /*#__PURE__*/React.createElement(Rating, null)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      justifyContent: "center",
      marginTop: 28
    }
  }, /*#__PURE__*/React.createElement(S_DS.Button, {
    variant: "primary",
    size: "lg",
    onClick: onBookings
  }, "Back to My Bookings"), /*#__PURE__*/React.createElement(S_DS.Button, {
    variant: "secondary",
    size: "lg",
    onClick: onHome
  }, "Return Home")));
}
function Rating() {
  const [val, setVal] = React.useState(0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flex: "none"
    }
  }, [1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => setVal(i),
    style: {
      width: 44,
      height: 44,
      borderRadius: 10,
      border: "none",
      cursor: "pointer",
      background: i <= val ? "var(--amber-500)" : "var(--white)",
      boxShadow: i <= val ? "none" : "inset 0 0 0 1px var(--slate-200)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "all var(--dur-fast)"
    }
  }, /*#__PURE__*/React.createElement(SIcon, {
    name: "star",
    size: 20,
    color: i <= val ? "#fff" : "var(--slate-300)"
  }))));
}
Object.assign(window, {
  ZSupportScreen: SupportScreen,
  ZSupportSubmittedScreen: SupportSubmittedScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/screens-support.jsx", error: String((e && e.message) || e) }); }

// ui_kits/booking-app/shared.jsx
try { (() => {
// Shared chrome: top nav, eyebrow label, meta row, money rail helpers.
const DS = window.ZumperDesignSystem_74a932;
const Icon = window.ZIcon;
function Wordmark({
  size = 22
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: size,
      letterSpacing: "0.5px",
      color: "var(--blue-600)",
      lineHeight: 1
    }
  }, "zumper");
}
function Nav({
  active,
  signedIn,
  onNav,
  onSignIn,
  right
}) {
  const links = signedIn ? ["Home", "My Bookings"] : ["Home", "My Bookings", "Browse", "Listings"];
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      height: "var(--nav-height)",
      flex: "none",
      background: "var(--white)",
      borderBottom: "1px solid var(--slate-200)",
      display: "flex",
      alignItems: "center",
      gap: 40,
      padding: "0 80px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => onNav("home"),
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(Wordmark, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 32,
      flex: 1
    }
  }, links.map(l => {
    const key = l === "My Bookings" ? "bookings" : l.toLowerCase();
    const isActive = active === key;
    return /*#__PURE__*/React.createElement("button", {
      key: l,
      onClick: () => onNav(key),
      style: {
        background: "none",
        border: "none",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 15,
        fontWeight: isActive ? 500 : 400,
        color: isActive ? "var(--blue-600)" : "var(--slate-700)",
        padding: "4px 0"
      }
    }, l);
  })), right !== undefined ? right : signedIn ? /*#__PURE__*/React.createElement(DS.Avatar, {
    initials: "MS",
    size: 40
  }) : /*#__PURE__*/React.createElement(DS.Button, {
    variant: "secondary",
    size: "sm",
    onClick: onSignIn
  }, "Sign In"));
}
function Eyebrow({
  children,
  color = "var(--slate-500)",
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: "0.08em",
      textTransform: "uppercase",
      color,
      ...style
    }
  }, children);
}

// A back link used at the top of sub-pages
function BackLink({
  children,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      background: "none",
      border: "none",
      cursor: "pointer",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      fontWeight: 500,
      color: "var(--slate-600)",
      padding: "4px 0"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  }), children);
}

// label/value row for summary rails
function DataRow({
  label,
  value,
  valueColor = "var(--slate-900)",
  bold = true
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: 16,
      padding: "10px 0"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--slate-500)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      fontWeight: bold ? 700 : 400,
      color: valueColor,
      textAlign: "right"
    }
  }, value));
}

// a meta inline with icon (e.g. "· 4.9 (128 reviews)")
function Meta({
  icon,
  children,
  color = "var(--slate-500)"
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color
    }
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 15,
    color: color
  }), children);
}

// green checklist item
function CheckItem({
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: "50%",
      background: "var(--green-100)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 15,
    color: "var(--green-600)",
    strokeWidth: 2.5
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: "var(--slate-700)"
    }
  }, children));
}
function Stars({
  value = 5
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      gap: 1
    }
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement(Icon, {
    key: i,
    name: "star",
    size: 15,
    color: i < value ? "var(--amber-500)" : "var(--slate-200)"
  })));
}
Object.assign(window, {
  ZNav: Nav,
  ZWordmark: Wordmark,
  ZEyebrow: Eyebrow,
  ZBackLink: BackLink,
  ZDataRow: DataRow,
  ZMeta: Meta,
  ZCheckItem: CheckItem,
  ZStars: Stars
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/booking-app/shared.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Stepper = __ds_scope.Stepper;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.RadioCard = __ds_scope.RadioCard;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.Card = __ds_scope.Card;

})();
