// Hard-coded placeholder data. No database — every value is inline.
// Each listing carries its OWN cover image, blurb, description, amenities and meta —
// nothing is shared from a generic template.
// Resource resolver: when bundled to standalone HTML, window.__resources[id] is a blob URL;
// otherwise fall back to the on-disk asset path so the live prototype keeps working.
const ZRES = (id, path) => (typeof window !== "undefined" && window.__resources && window.__resources[id]) || path;
window.ZRES = ZRES;
const LISTINGS = [
  {
    id: "bay502", title: "123 Bay St · Apartment 502", type: "Apartments for rent",
    beds: "2 BR", bath: "1 BA", price: 2400, area: "Bay & Wellesley, Toronto",
    lifestyle: ["pet"], featured: true,
    img: ZRES("imgBay", "assets/apartment-utm.png"),
    imgAlt: "Sunlit corner living room with a grey sofa, round wood coffee table and framed prints — 123 Bay St, Apartment 502",
    blurb: "Bright corner unit with a rooftop terrace, steps from transit.",
    description: "A bright two-bedroom on the 5th floor at Bay & Wellesley, a 6-minute transit hop to the UTM shuttle connection. The open-concept living room runs to floor-to-ceiling windows, with a renovated kitchen and in-suite laundry. The building adds a shared rooftop terrace and welcomes pets. Utilities and high-speed Wi-Fi are included in the monthly rent.",
    amenities: [
      { icon: "bed", label: "2 bed · 1 bath" },
      { icon: "washing-machine", label: "In-suite laundry" },
      { icon: "maximize", label: "Floor-to-ceiling windows" },
      { icon: "building-2", label: "Rooftop terrace" },
      { icon: "heart", label: "Pet-friendly" },
      { icon: "wifi", label: "Utilities + Wi-Fi incl." },
    ],
    rating: "4.9", reviews: 128, verifiedSince: 2022, available: "Jun 1, 2026",
  },
  {
    id: "liberty1", title: "55 Liberty Village Rd · Unit 1108", type: "Apartments for rent",
    beds: "1 BR", bath: "1 BA", price: 1850, area: "Liberty Village, Toronto",
    lifestyle: ["luxury"],
    img: ZRES("imgLiberty", "assets/listing-liberty1.png"),
    imgAlt: "Sunlit glass condo towers rising above a landscaped courtyard pool fringed with palm trees in Liberty Village",
    blurb: "Sleek glass mid-rise with gym + concierge by the GO.",
    description: "A sleek one-bedroom in a modern Liberty Village mid-rise, a short walk to the GO station for a quick run into campus. Inside are premium quartz finishes and a private balcony over the courtyard; downstairs, a fitness studio and a concierge in the lobby. Best suited to a single graduate student or young professional who wants a quiet, finished space.",
    amenities: [
      { icon: "bed", label: "1 bed · 1 bath" },
      { icon: "sparkles", label: "Quartz finishes" },
      { icon: "dumbbell", label: "On-site gym" },
      { icon: "bell", label: "Lobby concierge" },
      { icon: "car", label: "EV parking" },
      { icon: "maximize", label: "Private balcony" },
    ],
    rating: "4.8", reviews: 94, verifiedSince: 2021, available: "May 15, 2026",
  },
  {
    id: "annex-studio", title: "8 Spadina Rd · Studio", type: "Apartments for rent",
    beds: "Studio", bath: "1 BA", price: 1650, area: "The Annex, Toronto",
    lifestyle: ["cheap", "short"],
    img: ZRES("imgAnnex", "assets/listing-annex-studio.png"),
    imgAlt: "Bright compact galley kitchen and a small glass dining table by tall windows overlooking the city, in a studio in The Annex",
    blurb: "Cozy furnished studio on the subway line — great sublet.",
    description: "A compact, budget-friendly studio carved out of a converted Victorian on Spadina Rd, right on the subway line to St. George. It comes fully furnished with a Murphy bed and a kitchenette, with a shared laundry room one floor down. Ideal for a short-term lease or a summer sublet — utilities are included, so there are no surprises on the monthly bill.",
    amenities: [
      { icon: "bed", label: "Studio · 1 bath" },
      { icon: "sofa", label: "Fully furnished" },
      { icon: "train", label: "On the subway line" },
      { icon: "washing-machine", label: "Shared laundry" },
      { icon: "calendar", label: "Month-to-month" },
      { icon: "wifi", label: "Utilities included" },
    ],
    rating: "4.6", reviews: 51, verifiedSince: 2023, available: "now",
  },
  {
    id: "leslie3", title: "240 Leslieville Ave · Apartment 3", type: "Apartments for rent",
    beds: "3 BR", bath: "2 BA", price: 3200, area: "Leslieville, Toronto",
    lifestyle: ["pet", "luxury"],
    img: ZRES("imgLeslie", "assets/listing-leslie3.png"),
    imgAlt: "Private back patio with cushioned seating and a gas BBQ behind a two-storey Leslieville home with a green lawn",
    blurb: "Roomy duplex upper with a private backyard for sharers.",
    description: "The spacious upper unit of a renovated Leslieville duplex — three real bedrooms that suit a group of students sharing. There's a private backyard with a gas BBQ hookup, a finished nook off the landing for studying, two full baths and parking for two cars. Dogs and cats are welcome on this quiet, tree-lined street.",
    amenities: [
      { icon: "bed", label: "3 bed · 2 bath" },
      { icon: "trees", label: "Private backyard" },
      { icon: "car", label: "2 parking spots" },
      { icon: "utensils", label: "Gas BBQ hookup" },
      { icon: "heart", label: "Pet-friendly" },
      { icon: "file-text", label: "Finished study nook" },
    ],
    rating: "4.9", reviews: 76, verifiedSince: 2020, available: "Aug 1, 2026",
  },
  {
    id: "junction-rm", title: "19 Pacific Ave · Room B", type: "Rooms for rent",
    beds: "1 Room", bath: "Shared", price: 980, area: "The Junction, Toronto",
    lifestyle: ["cheap", "short"],
    img: ZRES("imgJunction", "assets/listing-junction-rm.png"),
    imgAlt: "Spacious furnished room with a double bed, wardrobe and a desk by curtained windows, on dark hardwood floors in The Junction",
    blurb: "Affordable furnished room in a friendly house share.",
    description: "A private, furnished room in a friendly four-bedroom house share in The Junction, with a shared kitchen and two bathrooms between housemates. It's the most affordable option in this list and sits on a direct bus route to campus. The room includes a desk and double bed, and the rent covers all utilities plus Wi-Fi. Flexible month-to-month terms make it a fit for visiting or exchange students.",
    amenities: [
      { icon: "door-open", label: "Private room · shared bath" },
      { icon: "sofa", label: "Furnished room" },
      { icon: "utensils", label: "Shared kitchen" },
      { icon: "bus", label: "Bus to campus" },
      { icon: "calendar", label: "Month-to-month" },
      { icon: "wifi", label: "All utilities incl." },
    ],
    rating: "4.7", reviews: 38, verifiedSince: 2022, available: "now",
  },
  {
    id: "dvp-house", title: "412 Riverdale Cres · Whole house", type: "Houses for rent",
    beds: "4 BR", bath: "2.5 BA", price: 4100, area: "Riverdale, Toronto",
    lifestyle: ["pet"],
    img: ZRES("imgDvp", "assets/listing-dvp-house.png"),
    imgAlt: "Detached two-storey house with gabled roofs, a brick-and-clapboard facade and a large manicured front lawn in Riverdale",
    blurb: "Detached family home with fenced yard near Withrow Park.",
    description: "A detached four-bedroom house on a quiet Riverdale crescent — the whole-home option for an established group or a family. It has a fenced yard, two-and-a-half baths, a finished basement and a driveway for two cars. Withrow Park is around the corner and the DVP is close for an easy drive to campus. Pets are welcome.",
    amenities: [
      { icon: "bed", label: "4 bed · 2.5 bath" },
      { icon: "home", label: "Detached house" },
      { icon: "trees", label: "Fenced yard" },
      { icon: "car", label: "Driveway parking" },
      { icon: "key", label: "Finished basement" },
      { icon: "heart", label: "Pets welcome" },
    ],
    rating: "5.0", reviews: 112, verifiedSince: 2019, available: "Sep 1, 2026",
  },
];

// Signed-in renter — deliberately fictional placeholder identity (no real names).
const USER = { name: "Alex Doe", first: "Alex", email: "alex.doe@mail.utoronto.ca", initials: "AD" };

const FEATURED = LISTINGS[0];

// Property-type entry cards for Find a Place (L3)
const PROPERTY_TYPES = [
  { key: "apartments", label: "Apartments for rent", icon: "building-2", sub: "Most popular · self-contained units", count: 842, img: ZRES("imgBay", "assets/apartment-utm.png") },
  { key: "houses", label: "Houses for rent", icon: "home", sub: "Whole-home rentals with yards", count: 318, img: ZRES("imgDvp", "assets/listing-dvp-house.png") },
  { key: "rooms", label: "Rooms for rent", icon: "door-open", sub: "Shared accommodation by the room", count: 506, img: ZRES("imgJunction", "assets/listing-junction-rm.png") },
];

// Lifestyle filters (Browse by Lifestyle L3) — also re-enter as Filters on results
const LIFESTYLE = [
  { key: "short", label: "Short Term Rentals", icon: "calendar", sub: "Month-to-month & sublets" },
  { key: "luxury", label: "Luxury Apartments", icon: "sparkles", sub: "Premium finishes & amenities" },
  { key: "pet", label: "Pet-friendly Apartments", icon: "heart", sub: "Cats & dogs welcome" },
  { key: "cheap", label: "Cheap Apartments", icon: "dollar-sign", sub: "Most budget-friendly options" },
];

// My Renter Account — the active booking (Flow 1)
const BOOKING = {
  id: "ZMP-2026-04821",
  listing: "123 Bay St · Apartment 502",
  area: "Bay & Wellesley, Toronto",
  moveIn: "Jun 1, 2026",
  leaseEnd: "May 31, 2027",
  term: "12-month lease",
  rent: 2400,
  deposit: 1200,
  status: "Confirmed",
  card: "Visa ·· 4821",
};

// Account object tiles + counts
const ACCOUNT_OBJECTS = [
  { key: "bookings", label: "My Bookings", icon: "calendar", count: "1 upcoming · 3 past", scope: "Confirmed bookings & cancellation", badge: "NEW" },
  { key: "messaged", label: "Messaged", icon: "message-square", count: "2 new replies", scope: "Landlord communication hub" },
  { key: "favorites", label: "Favorites", icon: "heart", count: "14 saved", scope: "Saved & shortlisted listings" },
  { key: "applications", label: "Applications", icon: "file-text", count: "1 pending · 2 submitted", scope: "In-progress & submitted applications" },
];

const THREADS = [
  { id: "t-bay502", landlord: "M. Ferraro", listing: "123 Bay St · Apartment 502", last: "You: Hi! I'd like to schedule a tour…", time: "Just now", unread: false, you: true },
  { id: "t-liberty", landlord: "S. Okonkwo", listing: "55 Liberty Village Rd · Unit 1108", last: "Sure — the unit is available from Jun 1. Want to book a viewing?", time: "2h ago", unread: true },
  { id: "t-annex", landlord: "D. Tran", listing: "8 Spadina Rd · Studio", last: "Utilities are included in the rent. Let me know if you have questions.", time: "Yesterday", unread: true },
];

const FAVORITES = [LISTINGS[1], LISTINGS[3], LISTINGS[2]];

const APPLICATIONS = [
  { id: "a1", listing: "123 Bay St · Apartment 502", status: "Pending", stage: "Submitted · awaiting landlord review", date: "Jun 3, 2026", tone: "warning" },
  { id: "a2", listing: "55 Liberty Village Rd · Unit 1108", status: "Submitted", stage: "Documents under review", date: "May 28, 2026", tone: "info" },
  { id: "a3", listing: "8 Spadina Rd · Studio", status: "In progress", stage: "Draft — references needed", date: "May 25, 2026", tone: "neutral" },
];

window.ZDATA = { LISTINGS, FEATURED, USER, PROPERTY_TYPES, LIFESTYLE, BOOKING, ACCOUNT_OBJECTS, THREADS, FAVORITES, APPLICATIONS };
