// FLOW 2 — Find a Place ▸ property type ▸ results ▸ listing ▸ contact ▸ sent.
// Plus the Browse by Lifestyle landing (the other half of the Nearby Rentals split).
const F_DS = window.ZumperDesignSystem_74a932;
const FIcon = window.ZIcon;
const PAGE_F = { maxWidth: 1280, margin: "0 auto", width: "100%", boxSizing: "border-box", padding: "32px clamp(16px,4vw,40px) 64px" };

function PrimaryLabel({ children }) {
  return <window.ZEyebrow style={{ marginBottom: 6 }}>{children}</window.ZEyebrow>;
}
function H1({ children, sub }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: "clamp(24px,3.4vw,30px)", color: "var(--slate-900)", margin: 0, lineHeight: 1.15 }}>{children}</h1>
      {sub && <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "8px 0 0", maxWidth: 640, lineHeight: 1.5 }}>{sub}</p>}
    </div>
  );
}

// ---------- 1. Find a Place — choose a property type --------------------
function FindScreen({ onType, onNav }) {
  const D = window.ZDATA;
  return (
    <div style={PAGE_F}>
      <PrimaryLabel>Find a Place</PrimaryLabel>
      <H1 sub="Browse verified rentals by the kind of home you need. Lifestyle filters like pet-friendly or short-term live under Browse by Lifestyle.">Choose a property type</H1>
      <div className="z-cards z-cards-3">
        {D.PROPERTY_TYPES.map((t) => (
          <button key={t.key} onClick={() => onType(t.key)} className="zhover-card" style={{ textAlign: "left", cursor: "pointer", border: "none", background: "var(--white)", borderRadius: "var(--radius-xl)", overflow: "hidden", boxShadow: "var(--shadow-card)", display: "flex", flexDirection: "column" }}>
            <div style={{ position: "relative" }}>
              <img src={t.img} alt="" style={{ width: "100%", height: 150, objectFit: "cover", display: "block" }} />
              <span style={{ position: "absolute", top: 14, left: 14, width: 44, height: 44, borderRadius: 12, background: "var(--white)", display: "inline-flex", alignItems: "center", justifyContent: "center", boxShadow: "var(--shadow-sm)" }}><FIcon name={t.icon} size={22} color="var(--blue-600)" /></span>
            </div>
            <div style={{ padding: 22, display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 18, fontWeight: 700, color: "var(--slate-900)" }}>{t.label}</div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)" }}>{t.sub}</div>
              <div style={{ marginTop: 6, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--slate-400)" }}>{t.count} in Toronto</span>
                <span style={{ fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, color: "var(--blue-600)", display: "inline-flex", alignItems: "center", gap: 5 }}>Browse <FIcon name="arrow-right" size={14} color="var(--blue-600)" /></span>
              </div>
            </div>
          </button>
        ))}
      </div>
      <div style={{ marginTop: 22 }}>
        <F_DS.Alert variant="info" icon={<FIcon name="info" size={18} />} title="Looking for a vibe, not a type?">
          Short-term, luxury, pet-friendly and budget options live under <button onClick={() => onNav("lifestyle")} style={{ background: "none", border: "none", padding: 0, cursor: "pointer", font: "inherit", color: "var(--blue-600)", fontWeight: 700 }}>Browse by Lifestyle</button>.
        </F_DS.Alert>
      </div>
    </div>
  );
}

// ---------- Browse by Lifestyle landing ---------------------------------
function LifestyleScreen({ onLifestyle }) {
  const D = window.ZDATA;
  return (
    <div style={PAGE_F}>
      <PrimaryLabel>Browse by Lifestyle</PrimaryLabel>
      <H1 sub="Filter listings by what your housing should provide. These attributes cut across every property type and re-enter as filters on the results page.">What should your housing provide?</H1>
      <div className="z-cards z-cards-2">
        {D.LIFESTYLE.map((l) => (
          <button key={l.key} onClick={() => onLifestyle(l.key)} className="zhover-card" style={{ textAlign: "left", cursor: "pointer", border: "none", background: "var(--white)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-card)", padding: 24, display: "flex", alignItems: "center", gap: 18 }}>
            <span style={{ width: 56, height: 56, borderRadius: 14, background: "#EDE9FE", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}><FIcon name={l.icon} size={26} color="#7C3AED" /></span>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 18, fontWeight: 700, color: "var(--slate-900)" }}>{l.label}</div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", marginTop: 3 }}>{l.sub}</div>
              {l.note && <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--slate-400)", marginTop: 8 }}>{l.note}</div>}
            </div>
            <FIcon name="arrow-right" size={18} color="var(--blue-600)" />
          </button>
        ))}
      </div>
    </div>
  );
}

// ---------- Listing card (shared by results + favorites) ----------------
function ListingCard({ L, onOpen, saved, onToggleSave, idx = 0 }) {
  return (
    <div className="zhover-card" role="button" tabIndex={0} aria-label={"View listing: " + L.title + ", " + L.beds + ", $" + L.price.toLocaleString() + " per month, " + L.area} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onOpen(); } }} style={{ "--i": idx, background: "var(--white)", borderRadius: "var(--radius-xl)", overflow: "hidden", boxShadow: "var(--shadow-card)", display: "flex", flexDirection: "column", cursor: "pointer" }} onClick={onOpen}>
      <div style={{ position: "relative" }}>
        <img src={L.img} alt={L.imgAlt} style={{ width: "100%", height: 150, objectFit: "cover", display: "block" }} />
        {onToggleSave && (
          <button onClick={(e) => { e.stopPropagation(); onToggleSave(); }} aria-label={saved ? "Remove from favorites" : "Save to favorites"} aria-pressed={!!saved} style={{ position: "absolute", top: 12, right: 12, width: 36, height: 36, borderRadius: "50%", background: "rgba(255,255,255,0.94)", border: "none", cursor: "pointer", display: "inline-flex", alignItems: "center", justifyContent: "center", boxShadow: "var(--shadow-sm)" }}>
            <span key={saved ? "on" : "off"} className={saved ? "z-heart-burst" : undefined} style={{ display: "inline-flex" }}><FIcon name={saved ? "heart-filled" : "heart"} size={18} color={saved ? "var(--red-600)" : "var(--slate-500)"} /></span>
          </button>
        )}
      </div>
      <div style={{ padding: 16, display: "flex", flexDirection: "column", gap: 6 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8 }}>
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>{L.beds} · ${L.price.toLocaleString()}/mo</span>
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-500)", display: "inline-flex", alignItems: "center", gap: 3, flex: "none" }}><FIcon name="star" size={13} color="#E8A33C" filled />{L.rating}</span>
        </div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--slate-500)", display: "inline-flex", alignItems: "center", gap: 5 }}><FIcon name="map-pin" size={13} color="var(--slate-400)" />{L.area}</div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, lineHeight: 1.45, color: "var(--slate-400)", textWrap: "pretty" }}>{L.blurb}</div>
      </div>
    </div>
  );
}

// ---------- 2. Results list (with lifestyle filters as collateral) ------
const FILTER_DEFS = [{ k: "pet", l: "Pet-friendly" }, { k: "luxury", l: "Luxury" }, { k: "cheap", l: "Cheap" }, { k: "short", l: "Short-term" }];
function ResultsScreen({ typeKey, lifestyleKey, onOpen, savedSet, onToggleSave }) {
  const D = window.ZDATA;
  const [filters, setFilters] = React.useState(() => (lifestyleKey ? [lifestyleKey] : []));
  const TYPE_LABEL = { apartments: "Apartments for rent", houses: "Houses for rent", rooms: "Rooms for rent" };
  const typeLabel = typeKey ? TYPE_LABEL[typeKey] : null;
  let list = D.LISTINGS;
  if (typeLabel) list = list.filter((x) => x.type === typeLabel);
  if (filters.length) list = list.filter((x) => filters.every((f) => x.lifestyle.includes(f)));
  const heading = lifestyleKey ? FILTER_DEFS.find((f) => f.k === lifestyleKey)?.l + " rentals" : (typeLabel || "All rentals");
  const toggle = (k) => setFilters((p) => p.includes(k) ? p.filter((x) => x !== k) : [...p, k]);
  return (
    <div style={PAGE_F}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 18, flexWrap: "wrap", gap: 12 }}>
        <div>
          <PrimaryLabel>{lifestyleKey ? "Browse by Lifestyle" : "Find a Place"}</PrimaryLabel>
          <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "4px 0 0" }}>{heading} · Toronto</h1>
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-500)", margin: "6px 0 0" }}>{list.length} verified {list.length === 1 ? "listing" : "listings"}</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <F_DS.Button variant="secondary" leftIcon={<FIcon name="sliders-horizontal" size={16} />}>Sort</F_DS.Button>
          <F_DS.Button variant="secondary" leftIcon={<FIcon name="map-pin" size={16} />}>Map</F_DS.Button>
        </div>
      </div>
      <div className="z-split">
        <div className="z-cards z-cards-2 z-stagger">
          {list.map((L, i) => <ListingCard key={L.id} L={L} idx={i} onOpen={() => onOpen(L.id)} saved={savedSet.has(L.id)} onToggleSave={() => onToggleSave(L.id)} />)}
          {list.length === 0 && <div style={{ gridColumn: "1 / -1", fontFamily: "var(--font-sans)", color: "var(--slate-500)", padding: 40, textAlign: "center" }}>No listings match these filters.</div>}
        </div>
        {/* Filters rail = lifestyle dimensions */}
        <div style={{ position: "sticky", top: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          <F_DS.Card padding={20}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
              <FIcon name="sliders-horizontal" size={17} color="var(--slate-700)" />
              <span style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>Filters</span>
            </div>
            <window.ZEyebrow style={{ marginBottom: 10 }}>Lifestyle</window.ZEyebrow>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {FILTER_DEFS.map((f) => <F_DS.Checkbox key={f.k} label={f.l} defaultChecked={filters.includes(f.k)} onChange={() => toggle(f.k)} />)}
            </div>
          </F_DS.Card>
        </div>
      </div>
    </div>
  );
}

// ---------- 3. Listing detail -------------------------------------------
function ListingScreen({ listingId, onContact, saved, onToggleSave, onOpen }) {
  const D = window.ZDATA;
  const L = D.LISTINGS.find((x) => x.id === listingId) || D.FEATURED;
  const similar = D.LISTINGS.filter((x) => x.id !== L.id).slice(0, 3);
  return (
    <div style={PAGE_F}>
      <div className="z-split">
        <div>
          <div style={{ position: "relative", borderRadius: "var(--radius-xl)", overflow: "hidden", boxShadow: "var(--shadow-card)" }}>
            <img src={L.img} alt={L.imgAlt} style={{ width: "100%", height: 320, objectFit: "cover", display: "block" }} />
            <span style={{ position: "absolute", top: 16, left: 16 }}><F_DS.Badge variant="info" dot>UTM Verified</F_DS.Badge></span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10, marginTop: 10 }}>
            {[["left top", 1], ["center", 1.08], ["right bottom", 1], ["center", 0.92]].map(([pos, b], i) => (
              <div key={i} style={{ height: 68, borderRadius: "var(--radius-md)", overflow: "hidden", boxShadow: "inset 0 0 0 1px var(--slate-200)" }}>
                <img src={L.img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: pos, filter: `brightness(${b}) saturate(1.05)`, display: "block" }} />
              </div>
            ))}
          </div>
          <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16 }}>
            <div>
              <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 26, color: "var(--slate-900)", margin: 0 }}>{L.title}</h1>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, color: "var(--slate-500)", marginTop: 6, display: "inline-flex", alignItems: "center", gap: 7 }}><FIcon name="map-pin" size={15} color="var(--slate-400)" />{L.area}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div><span style={{ fontFamily: "var(--font-sans)", fontSize: 26, fontWeight: 900, color: "var(--slate-900)" }}>${L.price.toLocaleString()}</span><span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-500)" }}>/mo</span></div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)", marginTop: 2 }}>{L.beds} · {L.bath}</div>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 16 }}>
            {L.amenities.map((a) => <F_DS.Tag key={a.label} icon={<FIcon name={a.icon} size={14} />}>{a.label}</F_DS.Tag>)}
          </div>
          <div style={{ marginTop: 24 }}>
            <window.ZEyebrow>Description</window.ZEyebrow>
            <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, lineHeight: 1.6, color: "var(--slate-600)", margin: "10px 0 0", textWrap: "pretty" }}>{L.description}</p>
          </div>
          <div style={{ display: "flex", gap: 26, marginTop: 22, flexWrap: "wrap" }}>
            <window.ZMeta icon="shield-check">Verified landlord since {L.verifiedSince}</window.ZMeta>
            <window.ZMeta icon="star">{L.rating} ({L.reviews} reviews)</window.ZMeta>
            <window.ZMeta icon="calendar">{L.available === "now" ? "Available now" : "Available " + L.available}</window.ZMeta>
          </div>
        </div>

        {/* Action rail */}
        <div style={{ position: "sticky", top: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          <F_DS.Card padding={22}>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-500)" }}>Monthly rent</div>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 30, fontWeight: 900, color: "var(--slate-900)", margin: "2px 0 14px" }}>${L.price.toLocaleString()}</div>
            <F_DS.Button variant="primary" size="lg" fullWidth onClick={onContact} leftIcon={<FIcon name="message-square" size={17} />}>Contact Landlord</F_DS.Button>
            <div style={{ height: 10 }} />
            <F_DS.Button variant={saved ? "danger-outline" : "secondary"} size="lg" fullWidth onClick={onToggleSave} leftIcon={<FIcon name={saved ? "heart-filled" : "heart"} size={17} color={saved ? "var(--red-600)" : undefined} />}>{saved ? "Saved to Favorites" : "Save to Favorites"}</F_DS.Button>
          </F_DS.Card>
          <F_DS.Card padding={20}>
            <window.ZEyebrow style={{ marginBottom: 12 }}>Similar listings</window.ZEyebrow>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {similar.map((s) => (
                <button key={s.id} onClick={() => onOpen(s.id)} style={{ display: "flex", gap: 12, alignItems: "center", background: "none", border: "none", padding: 0, cursor: "pointer", textAlign: "left" }}>
                  <img src={s.img} alt="" style={{ width: 64, height: 52, flex: "none", objectFit: "cover", borderRadius: "var(--radius-md)", boxShadow: "inset 0 0 0 1px var(--slate-200)" }} />
                  <div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, fontWeight: 700, color: "var(--slate-900)" }}>${s.price.toLocaleString()}/mo</div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--slate-500)" }}>{s.area}</div>
                  </div>
                </button>
              ))}
            </div>
          </F_DS.Card>
        </div>
      </div>
    </div>
  );
}

// ---------- 4. Contact form ---------------------------------------------
function ContactScreen({ listingId, onSend }) {
  const D = window.ZDATA;
  const L = D.LISTINGS.find((x) => x.id === listingId) || D.FEATURED;
  return (
    <div style={PAGE_F}>
      <div className="z-split">
        <F_DS.Card padding={32}>
          <PrimaryLabel>Message landlord</PrimaryLabel>
          <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 24, color: "var(--slate-900)", margin: "4px 0 4px" }}>Send a message about {L.title}</h1>
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, color: "var(--slate-500)", margin: "0 0 24px", lineHeight: 1.5 }}>Your message starts a thread that's saved under Messaged in your account, so you never lose context.</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            <div className="z-pair">
              <F_DS.Input label="Preferred move-in date" defaultValue="June 1, 2026" />
              <F_DS.Select label="Tour preference" defaultValue="In person" options={["In person", "Virtual / video call", "Either works"]} />
            </div>
            <F_DS.Input label="Your name" defaultValue="Alex Doe" />
            <F_DS.Input label="Email address" defaultValue="alex.doe@mail.utoronto.ca" />
            <F_DS.Textarea label="Your message" rows={6} defaultValue={"Hi! I'd like to schedule a tour of this unit. Is it still available for a June 1 move-in? Thanks!"} />
            <F_DS.Checkbox label="Email me a copy of this message" defaultChecked />
            <F_DS.Button variant="primary" size="lg" fullWidth onClick={onSend} leftIcon={<FIcon name="send" size={17} />}>Send message</F_DS.Button>
          </div>
        </F_DS.Card>
        <div style={{ position: "sticky", top: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          <F_DS.Card padding={20}>
            <window.ZEyebrow style={{ marginBottom: 12 }}>Listing summary</window.ZEyebrow>
            <img src={L.img} alt={L.imgAlt} style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: "var(--radius-lg)", display: "block", boxShadow: "inset 0 0 0 1px var(--slate-200)" }} />
            <div style={{ marginTop: 14 }}>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>{L.title}</div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--slate-500)", marginTop: 4 }}>{L.area}</div>
            </div>
            <div style={{ height: 1, background: "var(--slate-200)", margin: "14px 0" }} />
            <window.ZDataRow label="Rent" value={"$" + L.price.toLocaleString() + " / mo"} />
            <window.ZDataRow label="Available" value={L.available === "now" ? "Now" : L.available} valueColor="var(--green-600)" />
            <window.ZDataRow label="Type" value={L.type.replace(" for rent", "")} />
          </F_DS.Card>
          <F_DS.Alert variant="info" icon={<FIcon name="shield-check" size={18} />} title="Tip">Keep messages on-platform so Zumper can help if anything goes wrong.</F_DS.Alert>
        </div>
      </div>
    </div>
  );
}

// ---------- 5. Confirmation ---------------------------------------------
function ContactSentScreen({ listingId, onBackToListing, onSimilar, onMessaged }) {
  const D = window.ZDATA;
  const L = D.LISTINGS.find((x) => x.id === listingId) || D.FEATURED;
  return (
    <div style={{ ...PAGE_F, maxWidth: 760, textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: "50%", background: "var(--green-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", margin: "8px auto 0" }}>
        <FIcon name="check" size={30} color="var(--green-600)" strokeWidth={3} />
      </div>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 30, color: "var(--slate-900)", margin: "22px 0 0" }}>Message sent</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 16, color: "var(--slate-500)", margin: "12px auto 0", maxWidth: 520, lineHeight: 1.55 }}>The landlord usually replies within 24 hours. Your conversation about <strong style={{ color: "var(--slate-700)" }}>{L.title}</strong> now lives under <strong style={{ color: "var(--slate-700)" }}>My Renter Account › Messaged</strong>.</p>
      <F_DS.Card variant="inset" padding={20} style={{ maxWidth: 460, margin: "26px auto 0", textAlign: "left" }}>
        <window.ZDataRow label="Sent to" value="M. Ferraro (landlord)" />
        <window.ZDataRow label="About" value={L.title} />
        <window.ZDataRow label="Filed under" value="Messaged" valueColor="var(--blue-600)" />
      </F_DS.Card>
      <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 28, flexWrap: "wrap" }}>
        <F_DS.Button variant="primary" size="lg" onClick={onMessaged} leftIcon={<FIcon name="message-square" size={17} />}>View in Messaged</F_DS.Button>
        <F_DS.Button variant="secondary" size="lg" onClick={onBackToListing}>Back to listing</F_DS.Button>
        <F_DS.Button variant="secondary" size="lg" onClick={onSimilar}>Browse similar places</F_DS.Button>
      </div>
    </div>
  );
}

Object.assign(window, { ZFindScreen: FindScreen, ZLifestyleScreen: LifestyleScreen, ZResultsScreen: ResultsScreen, ZListingScreen: ListingScreen, ZContactScreen: ContactScreen, ZContactSentScreen: ContactSentScreen, ZListingCard: ListingCard });
