// Annotated storyboard — scaled live renders of every screen, arranged as
// sequential storyboards that mirror the user workflow. Each frame deep-links
// into the live prototype. Reuses the exact chrome + screen components.
const { useState: useStateSB } = React;
const SB_DS = window.ZumperDesignSystem_74a932;
const SBIcon = window.ZIcon;

const NOOP = () => {};
const savedSet = new Set(["liberty1", "leslie3", "annex-studio"]);

// Static breadcrumb trails (display only)
const TRAILS = {
  home: null,
  signin: ["Home", "Sign in"],
  account: ["Home", "My Renter Account"],
  bookings: ["Home", "My Renter Account", "My Bookings"],
  "booking-detail": ["Home", "My Renter Account", "My Bookings", "123 Bay St · Apt 502"],
  "cancel-success": ["Home", "My Renter Account", "My Bookings", "Cancelled"],
  messaged: ["Home", "My Renter Account", "Messaged"],
  favorites: ["Home", "My Renter Account", "Favorites"],
  applications: ["Home", "My Renter Account", "Applications"],
  find: ["Home", "Find a Place"],
  lifestyle: ["Home", "Browse by Lifestyle"],
  "find-results": ["Home", "Find a Place", "Apartments for rent · Toronto"],
  listing: ["Home", "Find a Place", "Apartments for rent", "123 Bay St · Apt 502"],
  contact: ["Home", "Find a Place", "123 Bay St · Apt 502", "Message landlord"],
  "contact-sent": ["Home", "Find a Place", "123 Bay St · Apt 502", "Message sent"],
  resources: ["Home", "Renting Resources"],
  landlords: ["Home", "For Landlords"],
  about: ["Home", "About Zumper"],
};
const TOPACTIVE = { home: null, signin: "account", account: "account", bookings: "account", "booking-detail": "account", "cancel-success": "account", messaged: "account", favorites: "account", applications: "account", find: "find", lifestyle: "lifestyle", "find-results": "find", listing: "find", contact: "find", "contact-sent": "account", resources: "resources", landlords: "landlords", about: "about" };
const SUBNAV = { account: "account", bookings: "bookings", "booking-detail": "bookings", "cancel-success": "bookings", messaged: "messaged", favorites: "favorites", applications: "applications" };

function renderScreen(route) {
  switch (route) {
    case "home": return <window.ZHomeScreen onNav={NOOP} onSearch={NOOP} onView={NOOP} onLifestyle={NOOP} />;
    case "signin": return <window.ZSignInScreen onSignIn={NOOP} onNav={NOOP} />;
    case "account": return <window.ZAccountDashboard onObject={NOOP} onNav={NOOP} />;
    case "bookings": return <window.ZMyBookings onView={NOOP} onNav={NOOP} />;
    case "booking-detail": return <window.ZBookingDetail onCancel={NOOP} onMessaged={NOOP} onNav={NOOP} />;
    case "cancel-success": return <window.ZCancelSuccess onBookings={NOOP} onFind={NOOP} onMessaged={NOOP} />;
    case "messaged": return <window.ZMessagedScreen />;
    case "favorites": return <window.ZFavoritesScreen onOpen={NOOP} savedSet={savedSet} onToggleSave={NOOP} />;
    case "applications": return <window.ZApplicationsScreen />;
    case "find": return <window.ZFindScreen onType={NOOP} onNav={NOOP} />;
    case "lifestyle": return <window.ZLifestyleScreen onLifestyle={NOOP} />;
    case "find-results": return <window.ZResultsScreen typeKey="apartments" lifestyleKey={null} onOpen={NOOP} savedSet={savedSet} onToggleSave={NOOP} />;
    case "listing": return <window.ZListingScreen listingId="bay502" onContact={NOOP} saved={false} onToggleSave={NOOP} onOpen={NOOP} />;
    case "contact": return <window.ZContactScreen listingId="bay502" onSend={NOOP} />;
    case "contact-sent": return <window.ZContactSentScreen listingId="bay502" onBackToListing={NOOP} onSimilar={NOOP} onMessaged={NOOP} />;
    case "resources": return <window.ZResourcesScreen />;
    case "landlords": return <window.ZLandlordsScreen />;
    case "about": return <window.ZAboutScreen />;
    default: return null;
  }
}

const FRAME_W = 1180, FRAME_H = 860, THUMB_W = 452;
const SCALE = THUMB_W / FRAME_W;

function ScreenFrame({ route, modal }) {
  const trail = TRAILS[route];
  const isAccount = ["account", "bookings", "booking-detail", "cancel-success", "messaged", "favorites", "applications"].includes(route);
  return (
    <a href={"Zumper Prototype.html?screen=" + (modal ? "cancel-modal" : route)} target="_blank" rel="noopener" className="sb-frame" style={{ display: "block", width: THUMB_W, height: FRAME_H * SCALE, borderRadius: 12, overflow: "hidden", border: "1px solid var(--slate-200)", boxShadow: "var(--shadow-card)", position: "relative", background: "var(--white)", flex: "none", textDecoration: "none" }}>
      <div style={{ width: FRAME_W, height: FRAME_H, transform: `scale(${SCALE})`, transformOrigin: "top left", pointerEvents: "none", background: "var(--surface-page)", position: "relative", display: "flex", flexDirection: "column" }}>
        <window.ZGlobalNav active={TOPACTIVE[route]} signedIn={isAccount || route === "contact-sent"} onNav={NOOP} onSignIn={NOOP} onSignOut={NOOP} />
        {trail && <window.ZBreadcrumb trail={trail.map((label, i) => i === trail.length - 1 ? { label } : { label, to: NOOP })} />}
        {isAccount && <window.ZAccountSubnav active={SUBNAV[route]} onNav={NOOP} />}
        <div style={{ flex: 1, overflow: "hidden" }}>{renderScreen(route)}</div>
        {modal && <window.ZCancelModal onConfirm={NOOP} onClose={NOOP} />}
      </div>
      <span className="sb-open" style={{ position: "absolute", bottom: 8, right: 8, background: "var(--slate-900)", color: "#fff", fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, padding: "5px 10px", borderRadius: 999, display: "inline-flex", alignItems: "center", gap: 5, opacity: 0, transition: "opacity 160ms" }}>
        <SBIcon name="external-link" size={12} color="#fff" />Open live
      </span>
    </a>
  );
}

function StepCaption({ n, title, desc, transition }) {
  return (
    <div style={{ width: THUMB_W, marginTop: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        {n != null && <span style={{ width: 22, height: 22, borderRadius: "50%", background: "var(--slate-900)", color: "#fff", fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 800, display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>{n}</span>}
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 800, color: "var(--slate-900)" }}>{title}</span>
      </div>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, lineHeight: 1.5, color: "var(--slate-600)", margin: "0 0 8px" }}>{desc}</p>
      {transition && (
        <div style={{ display: "flex", gap: 7, alignItems: "flex-start", background: "var(--blue-50, #EFF6FF)", borderRadius: 8, padding: "8px 10px" }}>
          <SBIcon name="arrow-right" size={13} color="var(--blue-600)" style={{ marginTop: 2, flex: "none" }} />
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 11.5, lineHeight: 1.45, color: "var(--blue-700)" }}><strong>On click:</strong> {transition}</span>
        </div>
      )}
    </div>
  );
}

function Arrow({ label }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-start", paddingTop: FRAME_H * SCALE / 2 - 30, flex: "none", width: 64 }}>
      <SBIcon name="arrow-right" size={26} color="var(--slate-400)" />
      {label && <span style={{ fontFamily: "var(--font-sans)", fontSize: 10.5, fontWeight: 600, color: "var(--slate-400)", textAlign: "center", marginTop: 6, lineHeight: 1.3 }}>{label}</span>}
    </div>
  );
}

// A storyboard row = alternating frames + arrows, horizontally scrollable
function StoryRow({ steps }) {
  return (
    <div style={{ overflowX: "auto", paddingBottom: 12 }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 0, width: "max-content", paddingBottom: 6 }}>
        {steps.map((s, i) => (
          <React.Fragment key={i}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <ScreenFrame route={s.route} modal={s.modal} />
              <StepCaption n={s.n} title={s.title} desc={s.desc} transition={s.transition} />
            </div>
            {i < steps.length - 1 && <Arrow label={steps[i].arrow} />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

function SectionHeader({ tag, tagColor, title, sub }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 11.5, fontWeight: 800, letterSpacing: "0.08em", textTransform: "uppercase", color: "#fff", background: tagColor, padding: "5px 11px", borderRadius: 999 }}>{tag}</span>
      <h2 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 26, color: "var(--slate-900)", margin: "12px 0 4px" }}>{title}</h2>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, color: "var(--slate-500)", margin: 0, maxWidth: 760, lineHeight: 1.5 }}>{sub}</p>
    </div>
  );
}

// ===== Storyboard content ===============================================
const GLOBAL_STEP = [{ route: "home", title: "Home — search entry", desc: "Global search, all six top-level destinations, the Browse by Lifestyle row, and a featured verified listing. Every nav item is live; this is the hub for both redesigned flows.", transition: "Search → Find a Place · lifestyle tile → filtered Results · destination card / nav → that section." }];

const FLOW1 = [
  { route: "signin", n: 1, title: "Sign in", desc: "Entry point for the account context. My Renter Account routes here when signed out.", transition: "Sign in → My Renter Account dashboard.", arrow: "signs in" },
  { route: "account", n: 2, title: "My Renter Account — dashboard", desc: "Four account objects with My Bookings placed first. Secondary nav exposes all four.", transition: "My Bookings tile → bookings list.", arrow: "open My Bookings" },
  { route: "bookings", n: 3, title: "My Bookings — list", desc: "Active booking surfaced first via an Upcoming / Past split. No buried sub-pages.", transition: "Active booking card → booking detail.", arrow: "view details" },
  { route: "booking-detail", n: 4, title: "Booking detail", desc: "Cancel is now a first-class button on the record itself — the core P3 fix for the failed P1 task.", transition: "Cancel booking → confirmation modal.", arrow: "cancel" },
  { route: "booking-detail", modal: true, n: 5, title: "Confirm cancellation (modal)", desc: "Previews the exact refund before commit. Two clearly differentiated outcomes prevent mis-taps.", transition: "Yes, cancel → success · Keep booking → detail.", arrow: "confirm" },
  { route: "cancel-success", n: 6, title: "Cancellation success", desc: "Refund timeline shown on-page; a re-entry to Find a Place closes the loop back to browsing.", transition: "Browse → Find a Place · Back to My Bookings." },
];

const FLOW2 = [
  { route: "find", n: 1, title: "Find a Place — property type", desc: "The three housing-format children: Apartments / Houses / Rooms. Lifestyle attributes deliberately excluded.", transition: "A property type → Results list.", arrow: "pick type" },
  { route: "find-results", n: 2, title: "Results list", desc: "Lifestyle dimensions re-enter as Filters in the rail, not separate pages — the cross-listing fix.", transition: "A listing card → listing detail · ♥ → Favorites.", arrow: "open listing" },
  { route: "listing", n: 3, title: "Listing detail", desc: "Save writes to Favorites; the primary CTA opens the contact form. Both file under My Renter Account.", transition: "Contact Landlord → contact form.", arrow: "contact" },
  { route: "contact", n: 4, title: "Contact form", desc: "Listing context pinned in the rail. Sending writes a thread into Messaged.", transition: "Send message → confirmation.", arrow: "send" },
  { route: "contact-sent", n: 5, title: "Confirmation — message sent", desc: "Active nav shifts to My Renter Account ▸ Messaged. Two escape hatches keep the user unstuck.", transition: "View in Messaged · Back to listing · Browse similar." },
];

const ALT = [
  { route: "lifestyle", title: "Browse by Lifestyle — landing", desc: "The other half of the old Nearby Rentals node. Each lifestyle leads to a pre-filtered Results list.", transition: "A lifestyle tile → filtered Results." },
];
const ACCOUNT_SUB = [
  { route: "messaged", title: "Messaged", desc: "Landlord communication hub — conversations only. Scope clarified away from bookings & applications." },
  { route: "favorites", title: "Favorites", desc: "Saved & shortlisted listings. Save-for-later lives here, not under Messaged." },
  { route: "applications", title: "Applications", desc: "All in-progress & submitted applications — moved out of My Bookings (P3 scope correction)." },
];
const STATIC = [
  { route: "resources", title: "Renting Resources", desc: "Topic-grouped renter tools. Rent research vs. Blog disambiguated with scope sublabels." },
  { route: "landlords", title: "For Landlords", desc: "Renamed from Property Management; footer items promoted in. Validated by T13/T14." },
  { route: "about", title: "About Zumper", desc: "The sixth top-level node — strongest card-sort validation (T15/T16 = 100%)." },
];

function GridRow({ items }) {
  return (
    <div style={{ display: "flex", gap: 28, flexWrap: "wrap" }}>
      {items.map((s, i) => (
        <div key={i} style={{ display: "flex", flexDirection: "column" }}>
          <ScreenFrame route={s.route} />
          <StepCaption title={s.title} desc={s.desc} transition={s.transition} />
        </div>
      ))}
    </div>
  );
}

// Anatomy diagram — the basic design structure every screen shares
function StructureBand({ tag, tagColor, name, body, h, dashed }) {
  return (
    <div style={{ border: dashed ? "2px dashed var(--slate-300)" : "1px solid var(--slate-200)", borderRadius: 10, background: dashed ? "var(--slate-50, #F8FAFC)" : "var(--white)", padding: "12px 14px", minHeight: h, display: "flex", flexDirection: "column", justifyContent: "center", boxShadow: dashed ? "none" : "var(--shadow-xs)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 10, fontWeight: 800, letterSpacing: "0.06em", textTransform: "uppercase", color: "#fff", background: tagColor, padding: "3px 8px", borderRadius: 999 }}>{tag}</span>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, fontWeight: 800, color: "var(--slate-900)" }}>{name}</span>
      </div>
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, lineHeight: 1.45, color: "var(--slate-500)" }}>{body}</div>
    </div>
  );
}
function StructureDiagram() {
  return (
    <div style={{ width: 452, flex: "none" }}>
      <div style={{ background: "var(--white)", borderRadius: 12, border: "1px solid var(--slate-200)", boxShadow: "var(--shadow-card)", padding: 14, display: "flex", flexDirection: "column", gap: 8 }}>
        <StructureBand tag="Header" tagColor="var(--blue-600)" name="Global navigation" body="Wordmark · all six top-level destinations · log in / account — identical on every screen." h={56} />
        <StructureBand tag="Header" tagColor="var(--blue-500, #4D7CF5)" name="Breadcrumb trail" body="Shows the user's depth in the hierarchy; every level is a back-link. (Hidden on Home.)" h={44} />
        <StructureBand tag="Body" tagColor="var(--slate-700)" name="Main content area" body="The screen's primary task — search, listing grid, booking record, forms. Often a wide content column + a sticky summary / action rail." h={132} dashed />
        <StructureBand tag="Footer" tagColor="var(--slate-500)" name="Footer" body="Support · Privacy · Explore · Rental Apps, cross-linked from every page; Company links promoted to About Zumper." h={56} />
      </div>
      <div style={{ marginTop: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
          <SBIcon name="info" size={16} color="var(--slate-700)" />
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 800, color: "var(--slate-900)" }}>Anatomy of every screen</span>
        </div>
        <p style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, lineHeight: 1.5, color: "var(--slate-600)", margin: 0 }}>Every frame in this storyboard stacks the same four regions. The frame on the right shows them filled in with the real Home page.</p>
      </div>
    </div>
  );
}

// How-to-read banner
function ReadingGuide() {
  const items = [
    ["layout-template", "Frame = one screen", "Each card is a live render showing the header, main content and footer."],
    ["file-text", "Caption = what it is", "A brief description sits under every frame."],
    ["arrow-right", "Arrow = navigation", "Arrows and “On click” notes document the transition to the next screen."],
    ["external-link", "Click = go live", "Opening any frame launches that exact screen in the prototype."],
  ];
  return (
    <div className="z-cards z-cards-4" style={{ marginBottom: 32 }}>
      {items.map(([icon, t, d]) => (
        <div key={t} style={{ background: "var(--white)", borderRadius: 12, boxShadow: "var(--shadow-card)", padding: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <span style={{ width: 30, height: 30, borderRadius: 8, background: "var(--blue-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}><SBIcon name={icon === "layout-template" ? "building-2" : icon} size={16} color="var(--blue-600)" /></span>
            <span style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, fontWeight: 800, color: "var(--slate-900)" }}>{t}</span>
          </div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, lineHeight: 1.45, color: "var(--slate-500)" }}>{d}</div>
        </div>
      ))}
    </div>
  );
}

function Storyboard() {
  return (
    <div style={{ minHeight: "100vh", background: "var(--surface-page)" }}>
      {/* Masthead */}
      <header style={{ background: "var(--gradient-hero)", padding: "40px 48px 38px" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "flex-end", gap: 24, flexWrap: "wrap" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
              <span style={{ width: 34, height: 34, borderRadius: 10, background: "rgba(255,255,255,0.18)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}><SBIcon name="home" size={18} color="#fff" strokeWidth={2.4} /></span>
              <span style={{ fontFamily: "var(--font-display)", fontSize: 26, letterSpacing: "0.5px", color: "#fff" }}>zumper</span>
            </div>
            <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 400, fontSize: 40, color: "#fff", margin: 0, lineHeight: 1.05 }}>Redesign Storyboard</h1>
            <p style={{ fontFamily: "var(--font-sans)", fontSize: 16, color: "rgba(255,255,255,0.9)", margin: "12px 0 0", maxWidth: 720, lineHeight: 1.5 }}>Project 3 — annotated screen-by-screen walkthrough of the redesigned information architecture, arranged as sequential storyboards that mirror the logical user workflow. Every frame is a live render and links into the clickable prototype.</p>
          </div>
          <a href="Zumper Prototype.html" style={{ textDecoration: "none", background: "#fff", color: "var(--blue-700)", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 700, padding: "12px 20px", borderRadius: 999, display: "inline-flex", alignItems: "center", gap: 8, boxShadow: "var(--shadow-md)" }}>
            <SBIcon name="external-link" size={16} color="var(--blue-700)" />Launch interactive prototype
          </a>
        </div>
      </header>

      <div style={{ maxWidth: 1400, margin: "0 auto", padding: "36px 48px 80px" }}>
        {/* Legend */}
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginBottom: 36, padding: "16px 20px", background: "var(--white)", borderRadius: 12, boxShadow: "var(--shadow-card)" }}>
          {[["Global", "var(--slate-600)"], ["Flow 1 · Cancel booking", "var(--red-600)"], ["Flow 2 · Find & message", "var(--blue-600)"], ["Static / supporting", "var(--slate-400)"]].map(([l, c]) => (
            <span key={l} style={{ display: "inline-flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, color: "var(--slate-700)" }}>
              <span style={{ width: 12, height: 12, borderRadius: 3, background: c }} />{l}
            </span>
          ))}
          <span style={{ marginLeft: "auto", fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)", display: "inline-flex", alignItems: "center", gap: 6 }}><SBIcon name="external-link" size={13} color="var(--slate-400)" />Click any frame to open it live</span>
        </div>

        <ReadingGuide />

        <section style={{ marginBottom: 48 }}>
          <SectionHeader tag="Global" tagColor="var(--slate-600)" title="Home & global navigation" sub="The shared entry point. Six top-level destinations, global search, breadcrumb, and footer appear on every screen below. Every frame in this storyboard follows the structure shown at left." />
          <div style={{ display: "flex", gap: 36, alignItems: "flex-start", flexWrap: "wrap" }}>
            <StructureDiagram />
            <div style={{ display: "flex", flexDirection: "column" }}>
              <ScreenFrame route="home" />
              <StepCaption title={GLOBAL_STEP[0].title} desc={GLOBAL_STEP[0].desc} transition={GLOBAL_STEP[0].transition} />
            </div>
          </div>
        </section>

        <section style={{ marginBottom: 48 }}>
          <SectionHeader tag="Flow 1 · Redesigned" tagColor="var(--red-600)" title="Cancel a booking & get a refund" sub="The headline P3 fix: the cancel affordance moves out of a buried help article and onto the booking record itself. Fully clickable from Home → sign in → bottom-level success screen." />
          <StoryRow steps={FLOW1} />
        </section>

        <section style={{ marginBottom: 48 }}>
          <SectionHeader tag="Flow 2 · Redesigned" tagColor="var(--blue-600)" title="Find a place & message the landlord" sub="The old Nearby Rentals node is split into Find a Place (property type) and Browse by Lifestyle (filters). Fully clickable from Home through to the message-sent confirmation." />
          <StoryRow steps={FLOW2} />
          <div style={{ marginTop: 28 }}>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 700, color: "var(--slate-500)", marginBottom: 14, display: "flex", alignItems: "center", gap: 8 }}><span style={{ width: 26, height: 1, background: "var(--slate-300)" }} />Alternate entry — Browse by Lifestyle</div>
            <GridRow items={ALT} />
          </div>
        </section>

        <section style={{ marginBottom: 48 }}>
          <SectionHeader tag="Flow 1 · Account objects" tagColor="var(--red-600)" title="My Renter Account sub-pages" sub="The renamed account bucket holds four clearly-scoped objects. P3 corrected the scope confusions the tree test exposed (T1–T4)." />
          <GridRow items={ACCOUNT_SUB} />
        </section>

        <section>
          <SectionHeader tag="Static" tagColor="var(--slate-400)" title="Non-redesigned top-level sections" sub="Reachable from global navigation everywhere. Real-looking landing pages; sub-nodes are static placeholders out of the redesign scope." />
          <GridRow items={STATIC} />
        </section>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Storyboard />);
