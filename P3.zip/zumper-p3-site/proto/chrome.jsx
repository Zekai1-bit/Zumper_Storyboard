// Global chrome: Wordmark, GlobalNav (6 nodes + utility), Breadcrumb,
// AccountSubnav, Footer, plus small shared helpers. Faithful to the
// "After" IA schematic: 6 top-level nodes, breadcrumb at every level,
// Company section removed from footer (promoted to About Zumper).
const CH_DS = window.ZumperDesignSystem_74a932;
const CHIcon = window.ZIcon;

// ---- The six top-level nodes (audience- then task-oriented) -------------
const NAV_NODES = [
  { key: "find", label: "Find a Place" },
  { key: "lifestyle", label: "Browse by Lifestyle" },
  { key: "account", label: "My Renter Account" },
  { key: "resources", label: "Renting Resources" },
  { key: "landlords", label: "For Landlords" },
  { key: "about", label: "About Zumper" },
];

function Wordmark({ size = 24, onClick }) {
  return (
    <button onClick={onClick} aria-label="Zumper home" style={{ background: "none", border: "none", cursor: onClick ? "pointer" : "default", padding: 0, display: "inline-flex", alignItems: "center", gap: 9 }}>
      <span style={{ width: 30, height: 30, borderRadius: 9, background: "var(--gradient-hero)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
        <CHIcon name="home" size={16} color="#fff" strokeWidth={2.4} />
      </span>
      <span style={{ fontFamily: "var(--font-display)", fontSize: size, letterSpacing: "0.5px", color: "var(--blue-600)", lineHeight: 1 }}>zumper</span>
    </button>
  );
}

function GlobalNav({ active, signedIn, onNav, onSignIn, onSignOut }) {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const pick = (fn) => { setMenuOpen(false); fn(); };
  return (
    <nav aria-label="Primary" style={{ minHeight: "var(--nav-height)", flex: "none", background: "var(--white)", borderBottom: "1px solid var(--slate-200)", display: "flex", alignItems: "center", gap: 20, padding: "0 clamp(14px,3vw,28px)", position: "relative" }}>
      <Wordmark onClick={() => pick(() => onNav("home"))} />
      <div className="z-nav-links" style={{ display: "flex", gap: 2, flex: 1, justifyContent: "center", flexWrap: "nowrap" }}>
        {NAV_NODES.map((n) => {
          const isActive = active === n.key;
          return (
            <button key={n.key} onClick={() => onNav(n.key)} aria-current={isActive ? "page" : undefined} style={{
              background: isActive ? "var(--blue-100)" : "none", border: "none", cursor: "pointer",
              fontFamily: "var(--font-sans)", fontSize: 13.5, fontWeight: isActive ? 700 : 500,
              color: isActive ? "var(--blue-700)" : "var(--slate-700)", padding: "9px 11px", borderRadius: "var(--radius-full)",
              transition: "background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)", whiteSpace: "nowrap",
            }}>{n.label}</button>
          );
        })}
      </div>
      <div className="z-nav-actions" style={{ display: "flex", alignItems: "center", gap: 14, flex: "none" }}>
        {signedIn ? (
          <React.Fragment>
            <span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-600)" }}>Hi, <strong style={{ color: "var(--slate-900)" }}>Alex</strong></span>
            <button onClick={onSignOut} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 500, color: "var(--slate-500)", padding: 0 }}>
              <CHIcon name="log-out" size={15} />Sign out
            </button>
            <CH_DS.Avatar initials="AD" size={38} />
          </React.Fragment>
        ) : (
          <React.Fragment>
            <button onClick={onSignIn} style={{ background: "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 500, color: "var(--slate-700)", padding: "8px 6px" }}>Log in</button>
            <CH_DS.Button variant="primary" size="sm" onClick={onSignIn}>Sign up</CH_DS.Button>
          </React.Fragment>
        )}
      </div>
      <button className="z-nav-burger" onClick={() => setMenuOpen((o) => !o)} aria-label="Menu" aria-expanded={menuOpen} aria-controls="z-mobile-menu" style={{ marginLeft: "auto", background: "none", border: "none", cursor: "pointer", color: "var(--slate-800)", alignItems: "center", justifyContent: "center", width: 42, height: 42, borderRadius: 10, flex: "none" }}>
        <CHIcon name={menuOpen ? "x" : "menu"} size={24} />
      </button>
      {menuOpen && (
        <div id="z-mobile-menu" className="z-menu" style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "var(--white)", borderBottom: "1px solid var(--slate-200)", boxShadow: "var(--shadow-lg)", padding: "10px 16px 16px", display: "flex", flexDirection: "column", gap: 4, zIndex: 45 }}>
          {NAV_NODES.map((n) => {
            const isActive = active === n.key;
            return (
              <button key={n.key} onClick={() => pick(() => onNav(n.key))} aria-current={isActive ? "page" : undefined} style={{ textAlign: "left", background: isActive ? "var(--blue-100)" : "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: isActive ? 700 : 500, color: isActive ? "var(--blue-700)" : "var(--slate-800)", padding: "12px 12px", borderRadius: 10 }}>{n.label}</button>
            );
          })}
          <div style={{ height: 1, background: "var(--slate-200)", margin: "8px 0" }} />
          {signedIn ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}><CH_DS.Avatar initials="AD" size={34} /><span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-700)" }}>Alex</span></span>
              <button onClick={() => pick(onSignOut)} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 600, color: "var(--slate-500)", padding: "8px" }}><CHIcon name="log-out" size={15} />Sign out</button>
            </div>
          ) : (
            <div style={{ display: "flex", gap: 10 }}>
              <CH_DS.Button variant="secondary" fullWidth onClick={() => pick(onSignIn)}>Log in</CH_DS.Button>
              <CH_DS.Button variant="primary" fullWidth onClick={() => pick(onSignIn)}>Sign up</CH_DS.Button>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}

// ---- Breadcrumb — added at all hierarchy levels (P3 change) -------------
function Breadcrumb({ trail }) {
  // trail: [{label, to}] — last item is current (no link)
  return (
    <nav aria-label="Breadcrumb" style={{ background: "var(--white)", borderBottom: "1px solid var(--slate-200)", padding: "11px clamp(16px,4vw,40px)", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
      {trail.map((item, i) => {
        const last = i === trail.length - 1;
        return (
          <React.Fragment key={i}>
            {last ? (
              <span aria-current="page" style={{ fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 700, color: "var(--slate-900)" }}>{item.label}</span>
            ) : (
              <button onClick={item.to} style={{ background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 500, color: "var(--blue-600)" }}>{item.label}</button>
            )}
            {!last && <CHIcon name="chevron-right" size={13} color="var(--slate-400)" />}
          </React.Fragment>
        );
      })}
    </nav>
  );
}

// ---- Account secondary nav (My Renter Account sub-objects) --------------
const ACCOUNT_TABS = [
  { key: "account", label: "Dashboard" },
  { key: "bookings", label: "My Bookings" },
  { key: "messaged", label: "Messaged" },
  { key: "favorites", label: "Favorites" },
  { key: "applications", label: "Applications" },
];
function AccountSubnav({ active, onNav }) {
  return (
    <nav aria-label="My Renter Account sections" style={{ background: "#EEF2FB", borderBottom: "1px solid var(--slate-200)", padding: "0 clamp(16px,4vw,40px)", display: "flex", alignItems: "center", gap: 4, overflowX: "auto" }}>
      {ACCOUNT_TABS.map((t) => {
        const on = active === t.key;
        return (
          <button key={t.key} onClick={() => onNav(t.key)} aria-current={on ? "page" : undefined} style={{
            background: "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14,
            fontWeight: on ? 700 : 500, color: on ? "var(--blue-700)" : "var(--slate-600)", padding: "13px 14px",
            borderBottom: on ? "2px solid var(--blue-600)" : "2px solid transparent", marginBottom: -1, whiteSpace: "nowrap",
          }}>{t.label}</button>
        );
      })}
    </nav>
  );
}

// ---- Footer — cross-linked from every page -----------------------------
function FooterCol({ title, links, onNav }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "var(--slate-400)" }}>{title}</div>
      {links.map((l) => (
        <button key={l.label} onClick={l.to ? l.to : undefined} style={{ textAlign: "left", background: "none", border: "none", cursor: l.to ? "pointer" : "default", padding: 0, fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", lineHeight: 1.3 }}>{l.label}</button>
      ))}
    </div>
  );
}

function Footer({ onNav }) {
  return (
    <footer style={{ flex: "none", background: "var(--white)", borderTop: "1px solid var(--slate-200)", padding: "40px clamp(16px,4vw,40px) 24px" }}>
      <div className="z-footer-grid" style={{ maxWidth: 1280, margin: "0 auto" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <Wordmark size={22} onClick={() => onNav("home")} />
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 13, lineHeight: 1.5, color: "var(--slate-500)", margin: 0, maxWidth: 220 }}>Verified student housing — browse, book, and manage rentals without confusion.</p>
        </div>
        <FooterCol title="Support" onNav={onNav} links={[{ label: "Contact Us" }, { label: "Terms & Conditions" }, { label: "Sitemap" }, { label: "Feedback" }, { label: "Fair Housing Rights" }]} />
        <FooterCol title="Privacy" onNav={onNav} links={[{ label: "Privacy Policy" }, { label: "Notice of Collection" }, { label: "Do Not Sell My Info" }, { label: "Your Privacy Choices" }]} />
        <FooterCol title="Explore" onNav={onNav} links={[{ label: "Advertise with Zumper", to: () => onNav("landlords") }, { label: "Tenant Screening", to: () => onNav("landlords") }, { label: "Landlord Resources", to: () => onNav("landlords") }]} />
        <FooterCol title="Rental Apps" onNav={onNav} links={[{ label: "Download for iOS" }, { label: "Get it on Google Play" }]} />
      </div>
      <div style={{ maxWidth: 1280, margin: "0 auto", marginTop: 28, paddingTop: 18, borderTop: "1px solid var(--slate-200)", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)" }}>© 2026 Zumper Inc. · A UTM concept</span>
        <span style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)" }}>Company links (About Us · Careers · Newsroom) now live under <button onClick={() => onNav("about")} style={{ background: "none", border: "none", cursor: "pointer", padding: 0, font: "inherit", color: "var(--blue-600)", fontWeight: 600 }}>About Zumper</button></span>
      </div>
    </footer>
  );
}

// ===== Small shared helpers =============================================
function Eyebrow({ children, color = "var(--slate-500)", style = {} }) {
  return <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color, ...style }}>{children}</div>;
}
function BackLink({ children, onClick }) {
  return (
    <button onClick={onClick} style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "none", border: "none", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 500, color: "var(--slate-600)", padding: "4px 0" }}>
      <CHIcon name="chevron-left" size={18} />{children}
    </button>
  );
}
function DataRow({ label, value, valueColor = "var(--slate-900)", bold = true }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, padding: "9px 0" }}>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-500)" }}>{label}</span>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: bold ? 700 : 400, color: valueColor, textAlign: "right" }}>{value}</span>
    </div>
  );
}
function Meta({ icon, children, color = "var(--slate-500)" }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontFamily: "var(--font-sans)", fontSize: 14, color }}>
      {icon && <CHIcon name={icon} size={15} color={color} />}{children}
    </span>
  );
}
function CheckItem({ children }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 11 }}>
      <span style={{ width: 24, height: 24, borderRadius: "50%", background: "var(--green-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
        <CHIcon name="check" size={14} color="var(--green-600)" strokeWidth={2.6} />
      </span>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-700)" }}>{children}</span>
    </div>
  );
}
function Stars({ value = 5 }) {
  return (
    <span style={{ display: "inline-flex", gap: 1 }}>
      {[0, 1, 2, 3, 4].map((i) => <CHIcon key={i} name="star" size={14} color={i < value ? "var(--amber-500)" : "var(--slate-200)"} />)}
    </span>
  );
}
// Image placeholder (medium-fi X-box) when no photo
function PhotoBox({ height = 180, radius = "var(--radius-lg)", label, style = {} }) {
  return (
    <div aria-hidden="true" style={{ position: "relative", height, background: "var(--slate-100)", borderRadius: radius, overflow: "hidden", boxShadow: "inset 0 0 0 1px var(--slate-200)", ...style }}>
      <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: "absolute", inset: 0, opacity: 0.5 }}>
        <line x1="0" y1="0" x2="100" y2="100" stroke="var(--slate-300)" strokeWidth="0.6" vectorEffect="non-scaling-stroke" />
        <line x1="100" y1="0" x2="0" y2="100" stroke="var(--slate-300)" strokeWidth="0.6" vectorEffect="non-scaling-stroke" />
      </svg>
      {label && <span style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 600, color: "var(--slate-400)" }}>{label}</span>}
    </div>
  );
}

Object.assign(window, {
  ZGlobalNav: GlobalNav, ZWordmark: Wordmark, ZBreadcrumb: Breadcrumb, ZAccountSubnav: AccountSubnav, ZFooter: Footer,
  ZEyebrow: Eyebrow, ZBackLink: BackLink, ZDataRow: DataRow, ZMeta: Meta, ZCheckItem: CheckItem, ZStars: Stars, ZPhotoBox: PhotoBox,
  ZNAV_NODES: NAV_NODES,
});
