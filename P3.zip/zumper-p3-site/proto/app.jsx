// App: router + state + breadcrumb logic + live annotation panel.
const { useState, useEffect, useRef } = React;
const APP_DS = window.ZumperDesignSystem_74a932;
const AppIcon = window.ZIcon;

// ===== Screen metadata + annotations ====================================
// flow: "Global" | "Flow 1" | "Flow 2" | "Static"
const META = {
  home: { top: null, flow: "Global", title: "Home — search entry", clickable: "global",
    desc: "The landing page presents the new top-level Find a Place and Browse by Lifestyle entries, a global search, all six IA destinations, and a featured verified listing. Every nav item is live.",
    events: [["Search / “Find a Place”", "Find a Place ▸ property type"], ["A lifestyle tile", "Results filtered by that lifestyle"], ["Featured “View listing”", "Listing detail"], ["Any of the 6 destination cards / nav", "That section"]] },

  // ---- Flow 1 ----
  signin: { top: "account", flow: "Flow 1", step: 1, title: "Sign in", clickable: "flow1",
    desc: "Signing in sets the renter context and lands the user on their account dashboard — the precondition for the P1 cancel-booking task. Clicking My Renter Account while signed out routes here first.",
    events: [["Sign in", "My Renter Account dashboard"], ["Zumper wordmark", "Home"]] },
  account: { top: "account", sub: "account", flow: "Flow 1", step: 2, title: "My Renter Account — dashboard", clickable: "flow1",
    desc: "Four account-scoped objects with My Bookings placed first — a deliberate position because cancellation was the failing task in P1. Secondary nav surfaces all four objects.",
    events: [["My Bookings tile", "My Bookings list"], ["Messaged / Favorites / Applications", "That object"], ["Secondary-nav tabs", "Each account page"]] },
  bookings: { top: "account", sub: "bookings", flow: "Flow 1", step: 3, title: "My Bookings — list", clickable: "flow1",
    desc: "Upcoming / Past split surfaces the active booking first — no scrolling, no buried sub-pages. Addresses the P1 finding that 0% of users could locate the booking record itself.",
    events: [["The active booking card / “View details”", "Booking detail"], ["Upcoming ⇄ Past tabs", "Switch list view"], ["Help links (collateral)", "Support"]] },
  "booking-detail": { top: "account", sub: "bookings", flow: "Flow 1", step: 4, title: "Booking detail", clickable: "flow1",
    desc: "Cancel is now a first-class L3 button on the booking record itself — in the original IA it lived inside a help article, the root cause of the 0% completion rate in P1. Policy text sits in the collateral rail, informational not blocking.",
    events: [["Cancel booking", "Confirm-cancellation modal"], ["Message landlord", "Messaged"], ["Contact support", "Support"]] },
  "cancel-modal": { top: "account", sub: "bookings", flow: "Flow 1", step: 5, title: "Confirm cancellation (modal)", clickable: "flow1",
    desc: "A modal previews the exact refund amount before commit. Two clearly differentiated outcomes — Keep booking vs. Yes, cancel — reduce mis-tap risk and address the P1 secondary finding that users abandoned cancellation when refund terms were unclear.",
    events: [["Yes, cancel", "Cancellation success"], ["Keep booking / backdrop", "Return to booking detail"]] },
  "cancel-success": { top: "account", sub: "bookings", flow: "Flow 1", step: 6, title: "Cancellation success", clickable: "flow1",
    desc: "Refund timeline is shown on-page (closes a known support-ticket loop) and a re-entry into Find a Place lives in collateral so the user can resume browsing — connecting two top-level categories to complete the round-trip.",
    events: [["Browse — Find a Place", "Find a Place"], ["Message landlord", "Messaged"], ["Back to My Bookings", "My Bookings"]] },

  // ---- Flow 2 ----
  find: { top: "find", flow: "Flow 2", step: 1, title: "Find a Place — property type", clickable: "flow2",
    desc: "The three housing-format cards are the L2 children of Find a Place. Card sort: Apartments / Houses / Rooms each sorted at 3/4 agreement here. Lifestyle attributes are intentionally absent — they live under Browse by Lifestyle.",
    events: [["Apartments / Houses / Rooms", "Results list"], ["“Browse by Lifestyle” link", "Browse by Lifestyle"]] },
  lifestyle: { top: "lifestyle", flow: "Flow 2", step: "1b", title: "Browse by Lifestyle — landing", clickable: "flow2",
    desc: "The other half of the old Nearby Rentals node. Short-term, Luxury, Pet-friendly and Cheap each landed at 3/4–4/4 under Browse by Lifestyle in the card sort, supporting their use as filters.",
    events: [["Any lifestyle tile", "Results filtered by that lifestyle"]] },
  "find-results": { top: "find", flow: "Flow 2", step: 2, title: "Results list", clickable: "flow2",
    desc: "Lifestyle dimensions (pet-friendly, luxury, cheap, short-term) re-enter as Filters in the collateral rail rather than as separate L1 pages — the P3 cross-listing fix for the T7/T8 boundary confusion.",
    events: [["Any listing card", "Listing detail"], ["♥ on a card", "Saves to Favorites"], ["Filter checkboxes", "Refine results"]] },
  listing: { top: "find", flow: "Flow 2", step: 3, title: "Listing detail", clickable: "flow2",
    desc: "The heart icon writes to Favorites; the primary CTA opens the contact form. Both targets live under the renamed My Renter Account bucket (Favorites = 4/4 card-sort agreement).",
    events: [["Contact Landlord", "Contact form"], ["Save to Favorites", "Adds to Favorites"], ["A similar listing", "That listing"]] },
  contact: { top: "find", flow: "Flow 2", step: 4, title: "Contact form", clickable: "flow2",
    desc: "Listing context is pinned in the collateral column so the user always knows what they're messaging about. Sending writes a thread into Messaged (4/4 card-sort agreement under My Renter Account).",
    events: [["Send message", "Confirmation"]] },
  "contact-sent": { top: "find", flow: "Flow 2", step: 5, title: "Confirmation — message sent", clickable: "flow2",
    desc: "Active nav state shifts to My Renter Account ▸ Messaged, signaling where the thread is filed. Two escape hatches keep the user from getting stuck — closing a Project 1 finding that users lost context after sending a message.",
    events: [["View in Messaged", "Messaged"], ["Back to listing", "Listing detail"], ["Browse similar places", "Results list"]] },

  // ---- Account sub-pages ----
  messaged: { top: "account", sub: "messaged", flow: "Flow 1", title: "Messaged", clickable: "support",
    desc: "Landlord communication hub. Scope clarified in P3: Messaged is for conversations only — not bookings (T1) or applications (T4). The message just sent appears here, filed with its listing context.",
    events: [["A thread", "Open conversation (static)"]] },
  favorites: { top: "account", sub: "favorites", flow: "Flow 2", title: "Favorites", clickable: "support",
    desc: "Saved & shortlisted listings. Save-for-later lives here, not under Messaged — resolving the T2/T3 false-scent split inside My Renter Account.",
    events: [["A saved listing", "Listing detail"], ["♥", "Toggle save"]] },
  applications: { top: "account", sub: "applications", flow: "Flow 1", title: "Applications", clickable: "support",
    desc: "P3 scope correction: application tracking lives here (all in-progress & submitted), NOT under My Bookings. T4 scored 0% because users never looked in My Bookings for application status — this reverses the tree test's own answer key based on the data.",
    events: [["An application", "Application detail (static)"]] },

  // ---- Static ----
  resources: { top: "resources", flow: "Static", title: "Renting Resources", clickable: "static",
    desc: "Topic-based grouping of renter tools. Rent research and Blog / Rental Guides carry scope sublabels to fix the T11/T12 mutual false scent; Blog was promoted from the footer.",
    events: [["Any sub-node card", "Resource page (static)"]] },
  landlords: { top: "landlords", flow: "Static", title: "For Landlords", clickable: "static",
    desc: "Renamed from Property Management. Manage listings & Promote your listing relabeled for clarity; Tenant Screening + Landlord Resources promoted from the footer. Validated by T13/T14.",
    events: [["Any sub-node card", "Landlord tool (static)"]] },
  about: { top: "about", flow: "Static", title: "About Zumper", clickable: "static",
    desc: "The sixth top-level node — every card-sort participant created a company category independently. T15/T16 = 100%, the strongest validation in the study. Promoted out of the footer.",
    events: [["About Us / Careers / Newsroom", "Company page (static)"]] }
};

const FLOW_LABEL = { Global: "Global", "Flow 1": "Flow 1 · Cancel booking", "Flow 2": "Flow 2 · Find & message", Static: "Static section" };
const FLOW_COLOR = { Global: "var(--slate-600)", "Flow 1": "var(--red-600)", "Flow 2": "var(--blue-600)", Static: "var(--slate-500)" };

const SEQ1 = [{ r: "signin" }, { r: "account" }, { r: "bookings" }, { r: "booking-detail" }, { r: "booking-detail", m: true }, { r: "cancel-success" }];
const SEQ2 = [{ r: "find" }, { r: "find-results" }, { r: "listing" }, { r: "contact" }, { r: "contact-sent" }];

const TYPE_LABEL = { apartments: "Apartments for rent", houses: "Houses for rent", rooms: "Rooms for rent" };
const LIFE_LABEL = { short: "Short Term Rentals", luxury: "Luxury Apartments", pet: "Pet-friendly Apartments", cheap: "Cheap Apartments" };

function useViewport() {
  const [w, setW] = useState(typeof window !== "undefined" ? window.innerWidth : 1280);
  useEffect(() => {
    const on = () => setW(window.innerWidth);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  return w;
}

// ===== App ==============================================================
function App() {
  const persisted = (() => {try {return JSON.parse(localStorage.getItem("zumper-proto") || "{}");} catch (e) {return {};}})();
  const urlScreen = (() => {try {return new URLSearchParams(location.search).get("screen");} catch (e) {return null;}})();
  const ACCOUNT_SCREENS = ["account", "bookings", "booking-detail", "cancel-success", "messaged", "favorites", "applications"];
  const initRoute = urlScreen && (META[urlScreen] || urlScreen === "cancel-modal") ? urlScreen === "cancel-modal" ? "booking-detail" : urlScreen : persisted.route || "home";
  const [route, setRoute] = useState(initRoute);
  const [signedIn, setSignedIn] = useState(urlScreen ? ACCOUNT_SCREENS.includes(initRoute) || urlScreen === "cancel-modal" || persisted.signedIn : persisted.signedIn || false);
  const [saved, setSaved] = useState(() => new Set(persisted.saved || ["liberty1", "leslie3", "annex-studio"]));
  const [ctx, setCtx] = useState(persisted.ctx || { typeKey: "apartments", lifestyleKey: null, origin: "find", listing: "bay502" });
  const [modal, setModal] = useState(urlScreen === "cancel-modal");
  const [panelOpen, setPanelOpen] = useState(typeof window !== "undefined" ? window.innerWidth >= 1080 : true);
  const [toast, setToast] = useState(null);
  const scrollRef = useRef(null);
  const toastTimer = useRef(null);
  const vw = useViewport();
  const compact = vw < 1080;

  useEffect(() => {
    localStorage.setItem("zumper-proto", JSON.stringify({ route, signedIn, saved: [...saved], ctx }));
  }, [route, signedIn, saved, ctx]);
  useEffect(() => {if (scrollRef.current) scrollRef.current.scrollTop = 0;}, [route]);
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== "Escape") return;
      if (modal) { setModal(false); return; }
      if (compact && panelOpen) { setPanelOpen(false); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [modal, compact, panelOpen]);

  const go = (r, patch) => {if (patch) setCtx((c) => ({ ...c, ...patch }));setModal(false);setRoute(r);};
  const flash = (msg) => {setToast(msg);clearTimeout(toastTimer.current);toastTimer.current = setTimeout(() => setToast(null), 1900);};
  const toggleSave = (id) => setSaved((prev) => {const n = new Set(prev);if (n.has(id)) {n.delete(id);flash("Removed from Favorites");} else {n.add(id);flash("Saved to Favorites");}return n;});

  // Top-level nav
  const onNav = (key) => {
    if (key === "home") return go("home");
    if (key === "account") return signedIn ? go("account") : go("signin");
    return go(key);
  };

  const m = META[route] || META.home;
  const topActive = route === "find-results" ? ctx.origin === "lifestyle" ? "lifestyle" : "find" : m.top;
  const isAccountArea = ["account", "bookings", "booking-detail", "cancel-success", "messaged", "favorites", "applications"].includes(route);

  // ----- Breadcrumb trail -----
  const trail = (() => {
    const H = { label: "Home", to: () => go("home") };
    switch (route) {
      case "home":return null;
      case "signin":return [H, { label: "Sign in" }];
      case "account":return [H, { label: "My Renter Account" }];
      case "bookings":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "My Bookings" }];
      case "booking-detail":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "My Bookings", to: () => go("bookings") }, { label: "123 Bay St · Apt 502" }];
      case "cancel-success":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "My Bookings", to: () => go("bookings") }, { label: "Cancelled" }];
      case "messaged":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "Messaged" }];
      case "favorites":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "Favorites" }];
      case "applications":return [H, { label: "My Renter Account", to: () => go("account") }, { label: "Applications" }];
      case "find":return [H, { label: "Find a Place" }];
      case "lifestyle":return [H, { label: "Browse by Lifestyle" }];
      case "find-results":return ctx.origin === "lifestyle" ?
        [H, { label: "Browse by Lifestyle", to: () => go("lifestyle") }, { label: LIFE_LABEL[ctx.lifestyleKey] || "Results" }] :
        [H, { label: "Find a Place", to: () => go("find") }, { label: (TYPE_LABEL[ctx.typeKey] || "Results") + " · Toronto" }];
      case "listing":{
          const base = ctx.origin === "lifestyle" ? [H, { label: "Browse by Lifestyle", to: () => go("lifestyle") }, { label: LIFE_LABEL[ctx.lifestyleKey], to: () => go("find-results") }] : [H, { label: "Find a Place", to: () => go("find") }, { label: TYPE_LABEL[ctx.typeKey], to: () => go("find-results") }];
          return [...base, { label: "123 Bay St · Apt 502" }];
        }
      case "contact":return [H, { label: "Find a Place", to: () => go("find") }, { label: "123 Bay St · Apt 502", to: () => go("listing") }, { label: "Message landlord" }];
      case "contact-sent":return [H, { label: "Find a Place", to: () => go("find") }, { label: "123 Bay St · Apt 502", to: () => go("listing") }, { label: "Message sent" }];
      case "resources":return [H, { label: "Renting Resources" }];
      case "landlords":return [H, { label: "For Landlords" }];
      case "about":return [H, { label: "About Zumper" }];
      default:return [H, { label: m.title }];
    }
  })();

  // ----- Screen render -----
  const screen = (() => {
    switch (route) {
      case "home":return <window.ZHomeScreen onNav={onNav} onSearch={() => go("find")} onView={() => go("listing", { listing: "bay502", origin: "find", typeKey: "apartments" })} onLifestyle={(k) => go("find-results", { lifestyleKey: k, origin: "lifestyle" })} />;
      case "signin":return <window.ZSignInScreen onSignIn={() => {setSignedIn(true);go("account");}} onNav={onNav} />;
      case "account":return <window.ZAccountDashboard onObject={(k) => go(k)} onNav={onNav} />;
      case "bookings":return <window.ZMyBookings onView={() => go("booking-detail")} onNav={onNav} />;
      case "booking-detail":return <window.ZBookingDetail onCancel={() => setModal(true)} onMessaged={() => go("messaged")} onNav={onNav} />;
      case "cancel-success":return <window.ZCancelSuccess onBookings={() => go("bookings")} onFind={() => go("find")} onMessaged={() => go("messaged")} />;
      case "messaged":return <window.ZMessagedScreen />;
      case "favorites":return <window.ZFavoritesScreen onOpen={(id) => go("listing", { listing: id })} savedSet={saved} onToggleSave={toggleSave} />;
      case "applications":return <window.ZApplicationsScreen />;
      case "find":return <window.ZFindScreen onType={(k) => go("find-results", { typeKey: k, origin: "find", lifestyleKey: null })} onNav={onNav} />;
      case "lifestyle":return <window.ZLifestyleScreen onLifestyle={(k) => go("find-results", { lifestyleKey: k, origin: "lifestyle" })} />;
      case "find-results":return <window.ZResultsScreen typeKey={ctx.origin === "lifestyle" ? null : ctx.typeKey} lifestyleKey={ctx.origin === "lifestyle" ? ctx.lifestyleKey : null} onOpen={(id) => go("listing", { listing: id })} savedSet={saved} onToggleSave={toggleSave} />;
      case "listing":return <window.ZListingScreen listingId={ctx.listing} onContact={() => go("contact")} saved={saved.has(ctx.listing)} onToggleSave={() => toggleSave(ctx.listing)} onOpen={(id) => go("listing", { listing: id })} />;
      case "contact":return <window.ZContactScreen listingId={ctx.listing} onSend={() => go("contact-sent")} />;
      case "contact-sent":return <window.ZContactSentScreen listingId={ctx.listing} onBackToListing={() => go("listing")} onSimilar={() => go("find-results")} onMessaged={() => {setSignedIn(true);go("messaged");}} />;
      case "resources":return <window.ZResourcesScreen />;
      case "landlords":return <window.ZLandlordsScreen />;
      case "about":return <window.ZAboutScreen />;
      default:return <window.ZHomeScreen onNav={onNav} onSearch={() => go("find")} onView={() => go("listing")} onLifestyle={() => go("lifestyle")} />;
    }
  })();

  const annKey = modal ? "cancel-modal" : route;

  return (
    <div style={{ display: "flex", height: "100vh", width: "100%", overflow: "hidden", background: "var(--surface-page)" }}>
      <a href="#main-content" className="skip-link">Skip to main content</a>
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column" }}>
        <div ref={scrollRef} style={{ flex: 1, overflow: "auto" }}>
          <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
            <window.ZGlobalNav active={topActive} signedIn={signedIn} onNav={onNav} onSignIn={() => go("signin")} onSignOut={() => {setSignedIn(false);go("home");}} />
            {trail && <window.ZBreadcrumb trail={trail} />}
            {isAccountArea && <window.ZAccountSubnav active={m.sub} onNav={(k) => go(k)} />}
            <main id="main-content" tabIndex={-1} style={{ flex: "1 0 auto", outline: "none" }}><div key={route} className="z-route">{screen}</div></main>
            <window.ZFooter onNav={onNav} />
          </div>
        </div>
      </div>
      <AnnotationPanel annKey={annKey} open={panelOpen} setOpen={setPanelOpen} go={go} setModal={setModal} signedIn={signedIn} setSignedIn={setSignedIn} compact={compact} />
      {modal && <window.ZCancelModal onConfirm={() => {setModal(false);go("cancel-success");}} onClose={() => setModal(false)} />}
      {toast &&
      <div style={{ position: "fixed", bottom: 26, left: 0, right: 0, display: "flex", justifyContent: "center", zIndex: 60, pointerEvents: "none" }}>
        <div role="status" aria-live="polite" className="z-toast" style={{ background: "var(--slate-900)", color: "#fff", fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 600, padding: "12px 20px", borderRadius: "var(--radius-full)", boxShadow: "var(--shadow-lg)", display: "flex", alignItems: "center", gap: 8 }}>
          <AppIcon name="heart-filled" size={15} color="#fff" />{toast}
        </div>
      </div>
      }
    </div>);

}

// ===== Annotation panel =================================================
function AnnotationPanel({ annKey, open, setOpen, go, setModal, signedIn, compact }) {
  const m = META[annKey] || META.home;
  const flowSeq = m.flow === "Flow 1" ? SEQ1 : m.flow === "Flow 2" ? SEQ2 : null;
  // find current index in flow sequence
  let idx = -1;
  if (flowSeq) idx = flowSeq.findIndex((s) => annKey === "cancel-modal" ? s.m : s.r === annKey && !s.m);
  const stepNum = m.step;

  const gotoStop = (stop) => {if (stop.m) {go("booking-detail");setTimeout(() => setModal(true), 0);} else {setModal(false);go(stop.r);}};

  if (!open) {
    return (
      <button onClick={() => setOpen(true)} title="Show annotations" style={{ position: "fixed", bottom: 20, right: 20, zIndex: 40, background: "var(--slate-900)", color: "#fff", border: "none", borderRadius: "var(--radius-full)", cursor: "pointer", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 700, boxShadow: "var(--shadow-lg)", display: "inline-flex", padding: "11px 18px", gap: "8px", alignItems: "center", justifyContent: "center" }}>
        <AppIcon name="info" size={15} color="#fff" />Annotations
      </button>);

  }

  const clickableLabel = { global: "Global · always live", flow1: "Flow 1 · fully clickable", flow2: "Flow 2 · fully clickable", static: "Static landing", support: "Account sub-page" }[m.clickable];

  return (
    <React.Fragment>
      {compact && <div className="z-backdrop" onClick={() => setOpen(false)} style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.5)", zIndex: 44 }} />}
      <aside className={compact ? "z-drawer" : undefined} style={compact
        ? { position: "fixed", top: 0, right: 0, width: "min(360px, 90vw)", height: "100vh", background: "#0E1726", color: "#E2E8F0", display: "flex", flexDirection: "column", boxShadow: "-8px 0 30px -16px rgba(0,0,0,0.5)", zIndex: 45 }
        : { width: 360, flex: "none", height: "100vh", background: "#0E1726", color: "#E2E8F0", display: "flex", flexDirection: "column", boxShadow: "-8px 0 30px -16px rgba(0,0,0,0.5)", zIndex: 30 }}>
      {/* header */}
      <div style={{ padding: "18px 20px 14px", borderBottom: "1px solid rgba(255,255,255,0.08)", display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontFamily: "var(--font-display)", fontSize: 15, letterSpacing: "0.5px", color: "#fff", whiteSpace: "nowrap" }}>screen annotations</span>
          <button onClick={() => setOpen(false)} title="Hide" style={{ background: "rgba(255,255,255,0.08)", border: "none", color: "#cbd5e1", cursor: "pointer", borderRadius: 8, width: 28, height: 28, display: "inline-flex", alignItems: "center", justifyContent: "center" }}><AppIcon name="x" size={15} /></button>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <span style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, letterSpacing: "0.05em", textTransform: "uppercase", color: "#fff", background: FLOW_COLOR[m.flow], padding: "4px 9px", borderRadius: 999 }}>{FLOW_LABEL[m.flow]}</span>
          {stepNum != null && <span style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, color: "#cbd5e1", background: "rgba(255,255,255,0.08)", padding: "4px 9px", borderRadius: 999 }}>Step {stepNum}{flowSeq ? " of " + flowSeq.length : ""}</span>}
        </div>
      </div>

      {/* body */}
      <div style={{ flex: 1, overflowY: "auto", padding: "18px 20px" }}>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#64748B", marginBottom: 6 }}>{clickableLabel}</div>
        <h2 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 21, color: "#fff", margin: "0 0 12px", lineHeight: 1.2 }}>{m.title}</h2>
        <p style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, lineHeight: 1.6, color: "#CBD5E1", margin: 0 }}>{m.desc}</p>

        {m.events &&
        <div style={{ marginTop: 22 }}>
            <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "#64748B", marginBottom: 10 }}>Navigation events</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
              {m.events.map(([on, to], i) =>
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "10px 12px" }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, fontWeight: 700, color: "#E2E8F0" }}>{on}</div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "#94A3B8", marginTop: 3, display: "flex", alignItems: "center", gap: 5 }}><AppIcon name="arrow-right" size={12} color="#5B8DEF" /> {to}</div>
                  </div>
                </div>
            )}
            </div>
          </div>
        }
      </div>

      {/* footer controls */}
      <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", padding: "14px 20px", display: "flex", flexDirection: "column", gap: 12 }}>
        {flowSeq &&
        <div style={{ display: "flex", gap: 8 }}>
            <button disabled={idx <= 0} onClick={() => idx > 0 && gotoStop(flowSeq[idx - 1])} style={navBtn(idx <= 0)}><AppIcon name="chevron-left" size={15} />Prev</button>
            <button disabled={idx < 0 || idx >= flowSeq.length - 1} onClick={() => idx >= 0 && idx < flowSeq.length - 1 && gotoStop(flowSeq[idx + 1])} style={navBtn(idx < 0 || idx >= flowSeq.length - 1)}>Next<AppIcon name="chevron-right" size={15} /></button>
          </div>
        }
        <div style={{ display: "flex", gap: 8 }}>
          <select value={annKey === "cancel-modal" ? "booking-detail" : annKey} onChange={(e) => gotoStop({ r: e.target.value })} style={{ flex: 1, background: "rgba(255,255,255,0.06)", color: "#E2E8F0", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 9, padding: "9px 10px", fontFamily: "var(--font-sans)", fontSize: 12.5, cursor: "pointer" }}>
            <optgroup label="Global">
              <option value="home">Home</option>
            </optgroup>
            <optgroup label="Flow 1 · Cancel booking">
              <option value="signin">1 · Sign in</option><option value="account">2 · Account dashboard</option><option value="bookings">3 · My Bookings</option><option value="booking-detail">4 · Booking detail</option><option value="cancel-success">6 · Cancellation success</option>
            </optgroup>
            <optgroup label="Flow 2 · Find & message">
              <option value="find">1 · Find a Place</option><option value="lifestyle">1b · Browse by Lifestyle</option><option value="find-results">2 · Results</option><option value="listing">3 · Listing detail</option><option value="contact">4 · Contact form</option><option value="contact-sent">5 · Message sent</option>
            </optgroup>
            <optgroup label="Account sub-pages">
              <option value="messaged">Messaged</option><option value="favorites">Favorites</option><option value="applications">Applications</option>
            </optgroup>
            <optgroup label="Static sections">
              <option value="resources">Renting Resources</option><option value="landlords">For Landlords</option><option value="about">About Zumper</option>
            </optgroup>
          </select>
        </div>
        <a href="Zumper Storyboard.html" style={{ textDecoration: "none", fontFamily: "var(--font-sans)", fontSize: 12.5, fontWeight: 600, color: "#5B8DEF", display: "inline-flex", alignItems: "center", gap: 6, justifyContent: "center" }}>
          <AppIcon name="external-link" size={14} color="#5B8DEF" />Open the annotated storyboard
        </a>
      </div>
    </aside>
    </React.Fragment>);

}
function navBtn(disabled) {
  return { flex: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 5, background: disabled ? "rgba(255,255,255,0.04)" : "rgba(91,141,239,0.16)", color: disabled ? "#475569" : "#9DBDF7", border: "1px solid " + (disabled ? "rgba(255,255,255,0.06)" : "rgba(91,141,239,0.3)"), borderRadius: 9, padding: "9px 10px", fontFamily: "var(--font-sans)", fontSize: 12.5, fontWeight: 700, cursor: disabled ? "default" : "pointer" };
}

window.__zroot = window.__zroot || ReactDOM.createRoot(document.getElementById("root"));
window.__zroot.render(<App />);