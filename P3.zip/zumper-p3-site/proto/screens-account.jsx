// FLOW 1 — Sign in ▸ My Renter Account ▸ My Bookings ▸ Booking detail ▸
// Cancel modal ▸ Cancellation success. Plus Messaged / Favorites /
// Applications account sub-pages (the P3 scope corrections).
const A_DS = window.ZumperDesignSystem_74a932;
const AIcon = window.ZIcon;
const PAGE_A = { maxWidth: 1280, margin: "0 auto", width: "100%", boxSizing: "border-box", padding: "32px clamp(16px,4vw,40px) 64px" };

// ---------- Sign in ------------------------------------------------------
function SignInScreen({ onSignIn, onNav }) {
  const [show, setShow] = React.useState(false);
  return (
    <div style={{ padding: "52px 40px 72px", display: "flex", justifyContent: "center", background: "var(--surface-page)" }}>
      <div style={{ width: 440, background: "var(--white)", borderRadius: "var(--radius-2xl)", boxShadow: "var(--shadow-lg)", padding: 40 }}>
        <div style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
          <window.ZWordmark size={28} onClick={() => onNav("home")} />
          <window.ZEyebrow style={{ marginTop: 14 }}>My Renter Account</window.ZEyebrow>
          <h2 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 25, color: "var(--slate-900)", margin: "2px 0 0" }}>Sign in to your renter account</h2>
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, color: "var(--slate-500)", margin: "4px 0 0" }}>Manage your bookings, messages and applications</p>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 18, marginTop: 26 }}>
          <A_DS.Input label="Email" defaultValue="alex.doe@mail.utoronto.ca" />
          <A_DS.Input label="Password" type={show ? "text" : "password"} defaultValue="studenthousing"
            rightIcon={<button onClick={() => setShow(!show)} style={{ background: "none", border: "none", cursor: "pointer", pointerEvents: "auto", color: "var(--slate-400)", display: "inline-flex", padding: 0 }}><AIcon name={show ? "eye-off" : "eye"} size={18} /></button>} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <A_DS.Checkbox label="Remember me" defaultChecked />
            <A_DS.Button variant="link" onClick={() => {}}>Forgot password?</A_DS.Button>
          </div>
          <A_DS.Button variant="primary" size="lg" fullWidth onClick={onSignIn}>Sign in</A_DS.Button>
          <div style={{ textAlign: "center", paddingTop: 12, borderTop: "1px solid var(--slate-200)", fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)" }}>New to Zumper? <span style={{ fontWeight: 700, color: "var(--slate-700)" }}>Create an account</span></div>
        </div>
      </div>
    </div>
  );
}

// ---------- Account dashboard -------------------------------------------
function ObjectTile({ o, onClick }) {
  return (
    <button onClick={onClick} className="zhover-card" style={{ textAlign: "left", cursor: "pointer", border: "none", background: "var(--white)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-card)", padding: 24, display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <span style={{ width: 46, height: 46, borderRadius: 12, background: "var(--blue-100)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}><AIcon name={o.icon} size={22} color="var(--blue-600)" /></span>
        {o.badge && <A_DS.Badge variant="success">{o.badge}</A_DS.Badge>}
      </div>
      <div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 18, fontWeight: 700, color: "var(--slate-900)" }}>{o.label}</div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", marginTop: 4 }}>{o.count}</div>
      </div>
      <div style={{ marginTop: "auto", paddingTop: 12, borderTop: "1px solid var(--slate-100)", fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)", display: "flex", alignItems: "center", gap: 6 }}>
        <AIcon name="info" size={13} color="var(--slate-400)" />{o.scope}
      </div>
    </button>
  );
}

function AccountDashboard({ onObject, onNav }) {
  const D = window.ZDATA;
  return (
    <div style={PAGE_A}>
      <window.ZEyebrow>Dashboard</window.ZEyebrow>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "6px 0 4px" }}>Welcome back, Alex</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "0 0 24px" }}>Everything tied to your rentals — bookings, messages, saved places and applications.</p>
      <div className="z-split">
        <div className="z-cards z-cards-2">
          {D.ACCOUNT_OBJECTS.map((o) => <ObjectTile key={o.key} o={o} onClick={() => onObject(o.key)} />)}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <A_DS.Card padding={20}>
            <window.ZEyebrow style={{ marginBottom: 14 }}>Quick links</window.ZEyebrow>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[["Renting Resources", "resources"], ["Renting tips & advice", "resources"], ["Help & support", "resources"]].map(([l, t]) => (
                <button key={l} onClick={() => onNav(t)} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", background: "none", border: "none", cursor: "pointer", padding: 0, fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--blue-600)", fontWeight: 500 }}>{l} <AIcon name="arrow-right" size={15} color="var(--blue-600)" /></button>
              ))}
            </div>
          </A_DS.Card>
        </div>
      </div>
    </div>
  );
}

// ---------- My Bookings list --------------------------------------------
function MyBookings({ onView, onNav }) {
  const D = window.ZDATA, B = D.BOOKING;
  const [tab, setTab] = React.useState("upcoming");
  return (
    <div style={PAGE_A}>
      <window.ZEyebrow>My Bookings</window.ZEyebrow>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "6px 0 4px" }}>Your bookings</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "0 0 20px" }}>Confirmed reservations and their cancellation options.</p>
      <div className="z-split">
        <div>
          <div style={{ display: "inline-flex", gap: 4, background: "var(--slate-100)", padding: 4, borderRadius: "var(--radius-md)", marginBottom: 18 }}>
            {[["upcoming", "Upcoming (1)"], ["past", "Past (3)"]].map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} style={{ border: "none", cursor: "pointer", padding: "8px 16px", borderRadius: 9, fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 600, background: tab === k ? "var(--white)" : "transparent", color: tab === k ? "var(--slate-900)" : "var(--slate-500)", boxShadow: tab === k ? "var(--shadow-xs)" : "none" }}>{l}</button>
            ))}
          </div>
          {tab === "upcoming" ? (
            <div className="zhover-card" role="button" tabIndex={0} aria-label={"View booking details for " + B.listing} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onView(); } }} style={{ background: "var(--white)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-card)", overflow: "hidden", cursor: "pointer", display: "flex" }} onClick={onView}>
              <img src={window.ZRES("imgBay", "assets/apartment-utm.png")} alt="" style={{ width: 200, objectFit: "cover", flex: "none" }} />
              <div style={{ padding: 22, flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 18, fontWeight: 700, color: "var(--slate-900)" }}>{B.listing}</div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", marginTop: 5 }}>Move-in {B.moveIn} · {B.term}</div>
                  </div>
                  <A_DS.Badge variant="success" dot>Confirmed</A_DS.Badge>
                </div>
                <div style={{ display: "flex", gap: 22, marginTop: 16 }}>
                  <window.ZMeta icon="calendar">Lease ends {B.leaseEnd}</window.ZMeta>
                  <window.ZMeta icon="credit-card">${B.deposit.toLocaleString()} deposit</window.ZMeta>
                </div>
                <div style={{ marginTop: 18 }}><A_DS.Button variant="link" onClick={onView}>View details →</A_DS.Button></div>
              </div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {["240 Leslieville Ave · Apt 3", "8 Spadina Rd · Studio", "19 Pacific Ave · Room B"].map((t, i) => (
                <A_DS.Card key={i} padding={18} style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>{t}</div>
                    <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-500)", marginTop: 3 }}>Completed · {2024 + i}</div>
                  </div>
                  <A_DS.Badge variant="neutral">Past</A_DS.Badge>
                </A_DS.Card>
              ))}
            </div>
          )}
        </div>
        <div style={{ position: "sticky", top: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          <A_DS.Card padding={20}>
            <window.ZEyebrow style={{ marginBottom: 10 }}>Need help?</window.ZEyebrow>
            {[["Cancellation policy", "resources"], ["Contact support", "resources"]].map(([l, t]) => (
              <button key={l} onClick={() => onNav(t)} style={{ display: "flex", justifyContent: "space-between", width: "100%", alignItems: "center", background: "none", border: "none", cursor: "pointer", padding: "8px 0", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--blue-600)", fontWeight: 500 }}>{l} <AIcon name="arrow-right" size={15} color="var(--blue-600)" /></button>
            ))}
          </A_DS.Card>
        </div>
      </div>
    </div>);

}

// ---------- Booking detail (cancel affordance lives HERE) ---------------
function BookingDetail({ onCancel, onMessaged, onNav }) {
  const D = window.ZDATA, B = D.BOOKING;
  return (
    <div style={PAGE_A}>
      <div className="z-split">
        <div>
          <div style={{ position: "relative", borderRadius: "var(--radius-xl)", overflow: "hidden", boxShadow: "var(--shadow-card)" }}>
            <img src={window.ZRES("imgBay", "assets/apartment-utm.png")} alt="Interior of 123 Bay St, Apartment 502 — living room with natural light" style={{ width: "100%", height: 280, objectFit: "cover", display: "block" }} />
            <span style={{ position: "absolute", top: 16, left: 16 }}><A_DS.Badge variant="success" dot>Confirmed</A_DS.Badge></span>
          </div>
          <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 26, color: "var(--slate-900)", margin: "22px 0 6px" }}>{B.listing}</h1>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, color: "var(--slate-500)", display: "inline-flex", alignItems: "center", gap: 7 }}><AIcon name="map-pin" size={15} color="var(--slate-400)" />{B.area}</div>
          <A_DS.Card variant="inset" padding={22} style={{ marginTop: 20 }}>
            <window.ZEyebrow style={{ marginBottom: 6 }}>Booking summary</window.ZEyebrow>
            <div className="z-pair" style={{ gap: "0 40px" }}>
              <window.ZDataRow label="Status" value="Confirmed ✓" valueColor="var(--green-600)" />
              <window.ZDataRow label="Booking ID" value={B.id} valueColor="var(--blue-600)" />
              <window.ZDataRow label="Move-in" value={B.moveIn} />
              <window.ZDataRow label="Lease ends" value={B.leaseEnd} />
              <window.ZDataRow label="Monthly rent" value={"$" + B.rent.toLocaleString()} />
              <window.ZDataRow label="Deposit" value={"$" + B.deposit.toLocaleString()} />
            </div>
          </A_DS.Card>
          <div style={{ display: "flex", gap: 12, marginTop: 22 }}>
            <A_DS.Button variant="secondary" size="lg" onClick={onMessaged} leftIcon={<AIcon name="message-square" size={17} />}>Message landlord</A_DS.Button>
            <A_DS.Button variant="danger" size="lg" onClick={onCancel} leftIcon={<AIcon name="x" size={17} />}>Cancel booking</A_DS.Button>
          </div>
        </div>
        <div style={{ position: "sticky", top: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          <A_DS.Card padding={22}>
            <window.ZEyebrow style={{ marginBottom: 10 }}>Cancellation policy</window.ZEyebrow>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <window.ZCheckItem>Free cancellation up to 7 days before move-in</window.ZCheckItem>
              <window.ZCheckItem>Full ${B.deposit.toLocaleString()} deposit refund within this window</window.ZCheckItem>
              <window.ZCheckItem>Partial refund per policy after that</window.ZCheckItem>
            </div>
            <div style={{ marginTop: 16 }}>
              <A_DS.Badge variant="info" dot>47 days until your full-refund window closes</A_DS.Badge>
            </div>
          </A_DS.Card>
          <A_DS.Card padding={20}>
            <window.ZEyebrow style={{ marginBottom: 8 }}>Need help?</window.ZEyebrow>
            <button onClick={() => onNav("resources")} style={{ display: "flex", justifyContent: "space-between", width: "100%", alignItems: "center", background: "none", border: "none", cursor: "pointer", padding: "8px 0", fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--blue-600)", fontWeight: 500 }}>Contact support <AIcon name="arrow-right" size={15} color="var(--blue-600)" /></button>
          </A_DS.Card>
        </div>
      </div>
    </div>
  );
}

// ---------- Cancel confirmation modal -----------------------------------
function CancelModal({ onConfirm, onClose }) {
  const D = window.ZDATA, B = D.BOOKING;
  const dialogRef = React.useRef(null);
  React.useEffect(() => { if (dialogRef.current) dialogRef.current.focus(); }, []);
  return (
    <div className="z-backdrop" style={{ position: "fixed", inset: 0, background: "rgba(15,23,42,0.55)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 24 }} onClick={onClose}>
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="cancel-dialog-title" tabIndex={-1} onClick={(e) => e.stopPropagation()} className="z-modal" style={{ width: 460, maxWidth: "100%", background: "var(--white)", borderRadius: "var(--radius-2xl)", boxShadow: "var(--shadow-lg)", padding: 34, textAlign: "center", outline: "none" }}>
        <div aria-hidden="true" style={{ width: 60, height: 60, borderRadius: "50%", background: "var(--red-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
          <AIcon name="x" size={26} color="var(--red-600)" strokeWidth={2.5} />
        </div>
        <window.ZEyebrow color="var(--red-600)">Cancel this booking?</window.ZEyebrow>
        <h2 id="cancel-dialog-title" style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 23, color: "var(--slate-900)", margin: "6px 0 8px" }}>{B.listing}</h2>
        <p style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, lineHeight: 1.5, color: "var(--slate-500)", margin: "0 0 18px" }}>This action is permanent and cannot be undone. Your full refund will be initiated immediately.</p>
        <A_DS.Card variant="inset" padding={18} style={{ textAlign: "left", marginBottom: 22 }}>
          <window.ZDataRow label="Refund preview" value={"$" + B.deposit.toLocaleString() + " to " + B.card} valueColor="var(--green-600)" />
          <window.ZDataRow label="Timeline" value="5–7 business days" />
          <window.ZDataRow label="Note" value="Final amount confirmed by email" bold={false} />
        </A_DS.Card>
        <div style={{ display: "flex", gap: 12 }}>
          <A_DS.Button variant="secondary" size="lg" fullWidth onClick={onClose}>Keep booking</A_DS.Button>
          <A_DS.Button variant="danger" size="lg" fullWidth onClick={onConfirm}>Yes, cancel</A_DS.Button>
        </div>
      </div>
    </div>
  );
}

// ---------- Cancellation success ----------------------------------------
function CancelSuccess({ onBookings, onFind, onMessaged }) {
  const D = window.ZDATA, B = D.BOOKING;
  return (
    <div style={{ ...PAGE_A, maxWidth: 880 }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 60, height: 60, borderRadius: "50%", background: "var(--green-100)", display: "inline-flex", alignItems: "center", justifyContent: "center" }}><AIcon name="check" size={28} color="var(--green-600)" strokeWidth={3} /></div>
        <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 30, color: "var(--slate-900)", margin: "20px 0 0" }}>Booking cancelled</h1>
        <p style={{ fontFamily: "var(--font-sans)", fontSize: 16, color: "var(--slate-500)", margin: "12px auto 0", maxWidth: 520, lineHeight: 1.55 }}>Your reservation for <strong style={{ color: "var(--slate-700)" }}>{B.listing}</strong> has been cancelled. Your ${B.deposit.toLocaleString()} refund is on its way.</p>
      </div>
      <div className="z-cards z-cards-3" style={{ margin: "28px 0" }}>
        {[["green", "Refund amount", "$" + B.deposit.toLocaleString(), "Full deposit"], ["dark", "Timeline", "5–7 days", "To " + B.card], ["blue", "Confirmation", "ZMP-CANC-4821", "Sent to email"]].map(([tone, label, val, sub]) => {
          const bg = tone === "green" ? "var(--green-100)" : "var(--slate-100)";
          const c = tone === "green" ? "var(--green-600)" : tone === "blue" ? "var(--blue-600)" : "var(--slate-900)";
          return (
            <div key={label} style={{ background: bg, borderRadius: "var(--radius-xl)", padding: 22, textAlign: "center" }}>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: tone === "green" ? "var(--green-700)" : "var(--slate-500)" }}>{label}</div>
              <div style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 22, color: c, margin: "8px 0 4px" }}>{val}</div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-500)" }}>{sub}</div>
            </div>
          );
        })}
      </div>
      <A_DS.Card variant="outline" padding={22} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 16, fontWeight: 700, color: "var(--slate-900)" }}>Looking for somewhere new?</div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", marginTop: 3 }}>Reconsidering? You can message the landlord one more time, or start a fresh search.</div>
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          <A_DS.Button variant="secondary" onClick={onMessaged}>Message landlord</A_DS.Button>
          <A_DS.Button variant="primary" onClick={onFind} leftIcon={<AIcon name="search" size={16} />}>Browse — Find a Place</A_DS.Button>
        </div>
      </A_DS.Card>
      <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 24 }}>
        <A_DS.Button variant="secondary" size="lg" onClick={onBookings}>Back to My Bookings</A_DS.Button>
        <A_DS.Button variant="secondary" size="lg" leftIcon={<AIcon name="download" size={16} />} onClick={() => {}}>Download receipt</A_DS.Button>
      </div>
    </div>
  );
}

// ---------- Messaged ----------------------------------------------------
function MessagedScreen() {
  const D = window.ZDATA;
  return (
    <div style={PAGE_A}>
      <window.ZEyebrow>Messaged</window.ZEyebrow>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "6px 0 4px" }}>Your conversations</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "0 0 20px" }}>Landlord communication hub. Every listing message you send is filed here with its context.</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 760 }}>
        {D.THREADS.map((t) => (
          <A_DS.Card key={t.id} padding={18} style={{ display: "flex", gap: 16, alignItems: "center", boxShadow: t.unread ? "inset 0 0 0 1px var(--blue-200), var(--shadow-xs)" : "var(--shadow-card)" }}>
            <A_DS.Avatar initials={t.landlord.split(" ").map((s) => s[0]).join("")} size={44} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 12 }}>
                <span style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>{t.landlord} · <span style={{ fontWeight: 500, color: "var(--slate-500)" }}>{t.listing}</span></span>
                <span style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-400)", flex: "none" }}>{t.time}</span>
              </div>
              <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: t.unread ? "var(--slate-700)" : "var(--slate-500)", marginTop: 4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.last}</div>
            </div>
            {t.unread && <span style={{ width: 9, height: 9, borderRadius: "50%", background: "var(--blue-600)", flex: "none" }} />}
            {t.you && <A_DS.Badge variant="success">Sent</A_DS.Badge>}
          </A_DS.Card>
        ))}
      </div>
    </div>
  );
}

// ---------- Favorites ---------------------------------------------------
function FavoritesScreen({ onOpen, savedSet, onToggleSave }) {
  const D = window.ZDATA;
  return (
    <div style={PAGE_A}>
      <window.ZEyebrow>Favorites</window.ZEyebrow>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "6px 0 4px" }}>Saved & shortlisted</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "0 0 20px" }}>Listings you've saved to review later, all in one place.</p>
      <div className="z-cards z-cards-3" style={{ maxWidth: 940 }}>
        {D.FAVORITES.map((L) => <window.ZListingCard key={L.id} L={L} onOpen={() => onOpen(L.id)} saved={savedSet.has(L.id)} onToggleSave={() => onToggleSave(L.id)} />)}
      </div>
    </div>
  );
}

// ---------- Applications ------------------------------------------------
function ApplicationsScreen() {
  const D = window.ZDATA;
  return (
    <div style={PAGE_A}>
      <window.ZEyebrow>Applications</window.ZEyebrow>
      <h1 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 28, color: "var(--slate-900)", margin: "6px 0 4px" }}>Your applications</h1>
      <p style={{ fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-500)", margin: "0 0 12px", maxWidth: 640, lineHeight: 1.5 }}>All your in-progress and submitted applications, and whether the landlord has viewed them.</p>
      <div style={{ display: "flex", flexDirection: "column", gap: 12, maxWidth: 760, marginTop: 14 }}>
        {D.APPLICATIONS.map((a) => (
          <A_DS.Card key={a.id} padding={20} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 16 }}>
            <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
              <span style={{ width: 44, height: 44, borderRadius: 11, background: "var(--slate-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}><AIcon name="file-text" size={20} color="var(--slate-600)" /></span>
              <div>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 15, fontWeight: 700, color: "var(--slate-900)" }}>{a.listing}</div>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--slate-500)", marginTop: 3 }}>{a.stage} · {a.date}</div>
              </div>
            </div>
            <A_DS.Badge variant={a.tone} dot>{a.status}</A_DS.Badge>
          </A_DS.Card>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, {
  ZSignInScreen: SignInScreen, ZAccountDashboard: AccountDashboard, ZMyBookings: MyBookings, ZBookingDetail: BookingDetail,
  ZCancelModal: CancelModal, ZCancelSuccess: CancelSuccess, ZMessagedScreen: MessagedScreen, ZFavoritesScreen: FavoritesScreen, ZApplicationsScreen: ApplicationsScreen,
});
