// Static (but real-looking) landing pages for the non-redesigned sections.
// Global nav reaches every one of the six top-level nodes.
const S_DS = window.ZumperDesignSystem_74a932;
const SIcon = window.ZIcon;
const PAGE_S = { maxWidth: 1280, margin: "0 auto", width: "100%", boxSizing: "border-box", padding: "0 clamp(16px,4vw,40px) 64px" };

function SubNodeCard({ n, accent }) {
  return (
    <div className="zhover-card" style={{ background: "var(--white)", borderRadius: "var(--radius-xl)", boxShadow: "var(--shadow-card)", padding: 24, display: "flex", flexDirection: "column", gap: 12, cursor: "pointer" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <span style={{ width: 46, height: 46, borderRadius: 12, background: accent.bg, display: "inline-flex", alignItems: "center", justifyContent: "center" }}><SIcon name={n.icon} size={22} color={accent.fg} /></span>
        {n.tag && <S_DS.Badge variant={n.tagVariant || "neutral"}>{n.tag}</S_DS.Badge>}
      </div>
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 17, fontWeight: 700, color: "var(--slate-900)" }}>{n.label}</div>
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", lineHeight: 1.45 }}>{n.desc}</div>
      {n.scope && <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, color: "var(--slate-400)", marginTop: 2, paddingTop: 10, borderTop: "1px solid var(--slate-100)" }}>{n.scope}</div>}
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, color: accent.fg, display: "inline-flex", alignItems: "center", gap: 5, marginTop: "auto" }}>Open <SIcon name="arrow-right" size={14} color={accent.fg} /></span>
    </div>
  );
}

function StaticLanding({ eyebrow, title, intro, accent, nodes, cols = 3, note, gradient }) {
  return (
    <div style={{ background: "var(--surface-page)" }}>
      <div style={{ background: gradient || "var(--gradient-hero)" }}>
        <div style={{ ...PAGE_S, padding: "44px clamp(16px,4vw,40px) 40px" }}>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 12, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", color: "rgba(255,255,255,0.8)" }}>{eyebrow}</div>
          <h1 style={{ fontFamily: "var(--font-display)", fontWeight: 400, fontSize: "clamp(30px,4vw,40px)", color: "#fff", margin: "12px 0 0", lineHeight: 1.08 }}>{title}</h1>
          <p style={{ fontFamily: "var(--font-sans)", fontSize: 16, color: "rgba(255,255,255,0.88)", margin: "14px 0 0", maxWidth: 620, lineHeight: 1.55 }}>{intro}</p>
        </div>
      </div>
      <div style={{ ...PAGE_S, paddingTop: 32 }}>
        <div className="z-cards z-cards-3">
          {nodes.map((n) => <SubNodeCard key={n.label} n={n} accent={accent} />)}
        </div>
        {note && (
          <div style={{ marginTop: 22 }}>
            <S_DS.Alert variant="neutral" icon={<SIcon name="info" size={18} />} title="IA note">{note}</S_DS.Alert>
          </div>
        )}
      </div>
    </div>
  );
}

function ResourcesScreen() {
  return (
    <StaticLanding
      eyebrow="Renting Resources"
      title="Everything you need to rent with confidence"
      intro="Tools, data and guides for renters — grouped by topic regardless of format."
      accent={{ bg: "var(--green-100)", fg: "var(--green-600)" }}
      gradient="linear-gradient(135deg, #166534 0%, #22C55E 100%)"
      nodes={[
        { label: "Rent calculator", icon: "calculator", desc: "Estimate what you can afford based on income and expenses." },
        { label: "Rent research", icon: "bar-chart", desc: "Neighbourhood rent data, trends and market reports.", scope: "Market data, reports & statistics" },
        { label: "Blog / Rental Guides", icon: "book-open", desc: "How-to articles and neighbourhood renting guides.", scope: "Articles & advice" },
      ]}
    />
  );
}

function LandlordsScreen() {
  return (
    <StaticLanding
      eyebrow="For Landlords"
      title="List, promote and manage your rentals"
      intro="Landlord tools, clearly labelled by task — list, promote, screen tenants and grow your rentals."
      accent={{ bg: "#FFF1E6", fg: "#EA580C" }}
      gradient="linear-gradient(135deg, #9A3412 0%, #F97316 100%)"
      cols={3}
      nodes={[
        { label: "Manage listings", icon: "building-2", desc: "Edit prices, availability and details for your listings." },
        { label: "Promote your listing", icon: "megaphone", desc: "Boost visibility and reach more verified renters." },
        { label: "Advertise with Zumper", icon: "external-link", desc: "Paid placement and campaign options for portfolios." },
        { label: "Tenant Screening", icon: "users", desc: "Run credit and identity checks before selecting a tenant." },
        { label: "Landlord Resources", icon: "file-text", desc: "Guides, templates and legal references for landlords." },
      ]}
    />
  );
}

function AboutScreen() {
  return (
    <StaticLanding
      eyebrow="About Zumper"
      title="Who we are and what we're building"
      intro="Who we are, the team behind Zumper, and the latest company news."
      accent={{ bg: "var(--slate-100)", fg: "var(--slate-700)" }}
      gradient="linear-gradient(135deg, #1E293B 0%, #475569 100%)"
      cols={3}
      nodes={[
        { label: "About Us", icon: "info", desc: "Our mission to make student housing clear and verified." },
        { label: "Careers", icon: "briefcase", desc: "Open roles and life at Zumper." },
        { label: "Newsroom", icon: "newspaper", desc: "Press statements and company announcements." },
      ]}
    />
  );
}

Object.assign(window, { ZResourcesScreen: ResourcesScreen, ZLandlordsScreen: LandlordsScreen, ZAboutScreen: AboutScreen });
