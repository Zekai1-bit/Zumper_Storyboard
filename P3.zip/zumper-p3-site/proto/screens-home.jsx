// HOME — search entry + all six IA destinations, fully interactive.
const H_DS = window.ZumperDesignSystem_74a932;
const HIcon = window.ZIcon;

function HeroFeature({ icon, title, body, divider }) {
  return (
    <div style={{ flex: 1, paddingLeft: divider ? 20 : 0, borderLeft: divider ? "1px solid rgba(255,255,255,0.22)" : "none", display: "flex", flexDirection: "column", gap: 6 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <HIcon name={icon} size={16} color="#fff" />
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 14, fontWeight: 700, color: "#fff" }}>{title}</div>
      </div>
      <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, lineHeight: 1.45, color: "rgba(255,255,255,0.82)" }}>{body}</div>
    </div>
  );
}

function FeaturedCard({ onView }) {
  const L = window.ZDATA.FEATURED;
  return (
    <div style={{ background: "var(--white)", borderRadius: "var(--radius-2xl)", boxShadow: "var(--shadow-card)", overflow: "hidden", display: "flex", flexDirection: "column" }}>
      <div style={{ position: "relative", height: 230 }}>
        <img src="assets/apartment-utm.png" alt="Apartment interior near UTM" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
        <span style={{ position: "absolute", top: 16, left: 16 }}><H_DS.Badge variant="info" dot>UTM Verified</H_DS.Badge></span>
        <span style={{ position: "absolute", bottom: 14, left: 16, background: "rgba(255,255,255,0.92)", color: "var(--slate-900)", fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 700, padding: "7px 13px", borderRadius: "var(--radius-full)", boxShadow: "var(--shadow-sm)", display: "inline-flex", alignItems: "center", gap: 7 }}>
          <window.ZStars value={5} /> 4.9 (128)
        </span>
      </div>
      <div style={{ padding: 24, display: "flex", flexDirection: "column", gap: 14 }}>
        <div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 18, fontWeight: 700, color: "var(--slate-900)" }}>{L.title}</div>
          <div style={{ fontFamily: "var(--font-sans)", fontSize: 13.5, color: "var(--slate-500)", marginTop: 5, display: "inline-flex", alignItems: "center", gap: 6 }}><HIcon name="map-pin" size={14} color="var(--slate-400)" />{L.area} · 6 min to UTM</div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <H_DS.Tag icon={<HIcon name="bed" size={14} />}>{L.beds}</H_DS.Tag>
          <H_DS.Tag icon={<HIcon name="wifi" size={14} />}>Utilities included</H_DS.Tag>
          <H_DS.Tag icon={<HIcon name="heart" size={14} />}>Pet-friendly</H_DS.Tag>
        </div>
        <div style={{ height: 1, background: "var(--slate-200)" }} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div><span style={{ fontFamily: "var(--font-sans)", fontSize: 24, fontWeight: 900, color: "var(--slate-900)" }}>${L.price.toLocaleString()}</span><span style={{ fontFamily: "var(--font-sans)", fontSize: 14, color: "var(--slate-500)" }}>/mo</span></div>
          <H_DS.Button variant="primary" onClick={onView}>View listing</H_DS.Button>
        </div>
      </div>
    </div>
  );
}

function DestCard({ icon, title, sub, accent, onClick }) {
  const [h, setH] = React.useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)} style={{
      textAlign: "left", cursor: "pointer", background: "var(--white)", borderRadius: "var(--radius-xl)", padding: 22, border: "none",
      boxShadow: h ? "inset 0 0 0 1px var(--blue-300), var(--shadow-md)" : "var(--shadow-card)", transition: "box-shadow var(--dur-base) var(--ease-out), transform var(--dur-base) var(--ease-out)",
      transform: h ? "translateY(-2px)" : "none", display: "flex", flexDirection: "column", gap: 12,
    }}>
      <span style={{ width: 44, height: 44, borderRadius: 12, background: accent.bg, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
        <HIcon name={icon} size={21} color={accent.fg} />
      </span>
      <div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 16, fontWeight: 700, color: "var(--slate-900)" }}>{title}</div>
        <div style={{ fontFamily: "var(--font-sans)", fontSize: 13, color: "var(--slate-500)", marginTop: 4, lineHeight: 1.4 }}>{sub}</div>
      </div>
      <span style={{ fontFamily: "var(--font-sans)", fontSize: 13, fontWeight: 600, color: "var(--blue-600)", display: "inline-flex", alignItems: "center", gap: 5, marginTop: "auto" }}>Open <HIcon name="arrow-right" size={14} color="var(--blue-600)" /></span>
    </button>
  );
}

function HomeScreen({ onNav, onSearch, onView, onLifestyle }) {
  const D = window.ZDATA;
  const PAGE = { maxWidth: 1280, margin: "0 auto", width: "100%", boxSizing: "border-box", padding: "0 clamp(16px,4vw,40px)" };
  return (
    <div style={{ background: "var(--surface-page)", paddingBottom: 56 }}>
      {/* Hero */}
      <div style={{ ...PAGE, paddingTop: 36 }}>
        <div className="z-hero">
          <div style={{ position: "relative", overflow: "hidden", borderRadius: "var(--radius-2xl)", background: "var(--gradient-hero)", padding: "clamp(24px,3vw,40px)", display: "flex", flexDirection: "column" }}>
            <div style={{ position: "absolute", width: 220, height: 220, borderRadius: "50%", background: "rgba(255,255,255,0.05)", bottom: -40, left: 20 }} />
            <div style={{ position: "absolute", width: 240, height: 240, borderRadius: "50%", background: "rgba(255,255,255,0.04)", top: -70, right: -30 }} />
            <span style={{ position: "relative", display: "inline-flex", alignItems: "center", gap: 8, alignSelf: "flex-start", background: "rgba(255,255,255,0.16)", color: "#fff", fontFamily: "var(--font-sans)", fontSize: 11.5, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", padding: "7px 13px", borderRadius: "var(--radius-full)" }}>
              <HIcon name="sparkles" size={13} color="#fff" />Verified Student Housing Near UTM
            </span>
            <h1 style={{ position: "relative", fontFamily: "var(--font-display)", fontWeight: 400, fontSize: "clamp(32px,4.4vw,46px)", lineHeight: 1.05, color: "#fff", margin: "22px 0 0" }}>Find your next place. Manage it without confusion.</h1>
            <p style={{ position: "relative", fontFamily: "var(--font-sans)", fontSize: 16, lineHeight: 1.5, color: "rgba(255,255,255,0.88)", margin: "16px 0 0", maxWidth: 480 }}>Browse verified listings, manage your reservation, and get clear refund and support information — all in one place.</p>
            <div style={{ position: "relative", marginTop: 26, background: "var(--white)", borderRadius: "var(--radius-lg)", padding: 8, display: "flex", gap: 8, boxShadow: "var(--shadow-md)" }}>
              <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10, padding: "0 12px" }}>
                <HIcon name="search" size={18} color="var(--slate-400)" />
                <input defaultValue="Toronto, ON" aria-label="Search by city, neighbourhood, or address" placeholder="Enter city, neighbourhood, or address" style={{ flex: 1, border: "none", outline: "none", fontFamily: "var(--font-sans)", fontSize: 15, color: "var(--slate-900)", background: "transparent" }} />
              </div>
              <H_DS.Button variant="primary" size="lg" onClick={onSearch}>Search</H_DS.Button>
            </div>
            <div style={{ position: "relative", display: "flex", gap: 10, marginTop: 14, flexWrap: "wrap" }}>
              <H_DS.Button variant="white" onClick={onSearch} leftIcon={<HIcon name="building-2" size={16} color="var(--blue-600)" />}>Find a Place</H_DS.Button>
              <H_DS.Button variant="ghost" onClick={() => onNav("lifestyle")} leftIcon={<HIcon name="sliders-horizontal" size={16} color="#fff" />}>Browse by Lifestyle</H_DS.Button>
            </div>
            <div style={{ position: "relative", display: "flex", gap: 18, marginTop: 26, paddingTop: 20, borderTop: "1px solid rgba(255,255,255,0.22)" }}>
              <HeroFeature icon="shield-check" title="Verified" body="Every UTM listing is landlord-verified" />
              <HeroFeature icon="zap" title="Clear actions" body="Book, message, or cancel with no confusion" divider />
              <HeroFeature icon="life-buoy" title="Support path" body="Refund & mediation help at every step" divider />
            </div>
          </div>
          <FeaturedCard onView={onView} />
        </div>
      </div>

      {/* Browse by Lifestyle — collateral row */}
      <div style={{ ...PAGE, marginTop: 32 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 14 }}>
          <div>
            <window.ZEyebrow>Browse by Lifestyle</window.ZEyebrow>
            <h2 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 22, color: "var(--slate-900)", margin: "6px 0 0" }}>What should your housing provide?</h2>
          </div>
          <H_DS.Button variant="link" onClick={() => onNav("lifestyle")}>View all lifestyles →</H_DS.Button>
        </div>
        <div className="z-cards z-cards-4">
          {D.LIFESTYLE.map((l) => (
            <button key={l.key} onClick={() => onLifestyle(l.key)} className="zhover-card" style={{ textAlign: "left", cursor: "pointer", background: "var(--white)", borderRadius: "var(--radius-lg)", padding: 18, border: "none", boxShadow: "var(--shadow-card)", display: "flex", alignItems: "center", gap: 14 }}>
              <span style={{ width: 42, height: 42, borderRadius: 11, background: "var(--blue-100)", display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}><HIcon name={l.icon} size={20} color="var(--blue-600)" /></span>
              <div>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 14.5, fontWeight: 700, color: "var(--slate-900)" }}>{l.label}</div>
                <div style={{ fontFamily: "var(--font-sans)", fontSize: 12.5, color: "var(--slate-500)", marginTop: 2 }}>{l.sub}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Explore Zumper — all six top-level IA destinations */}
      <div style={{ ...PAGE, marginTop: 36 }}>
        <window.ZEyebrow>Explore Zumper</window.ZEyebrow>
        <h2 style={{ fontFamily: "var(--font-sans)", fontWeight: 900, fontSize: 22, color: "var(--slate-900)", margin: "6px 0 16px" }}>Six ways to get where you're going</h2>
        <div className="z-cards z-cards-3">
          <DestCard icon="building-2" title="Find a Place" sub="Browse rentals by property type — apartments, houses, rooms." accent={{ bg: "var(--blue-100)", fg: "var(--blue-600)" }} onClick={() => onNav("find")} />
          <DestCard icon="sliders-horizontal" title="Browse by Lifestyle" sub="Filter by what matters — short-term, luxury, pet-friendly, budget." accent={{ bg: "#EDE9FE", fg: "#7C3AED" }} onClick={() => onNav("lifestyle")} />
          <DestCard icon="user" title="My Renter Account" sub="Bookings, messages, favorites and applications in one place." accent={{ bg: "#FFF1E6", fg: "#EA580C" }} onClick={() => onNav("account")} />
          <DestCard icon="book-open" title="Renting Resources" sub="Rent calculator, market research, and rental guides." accent={{ bg: "var(--green-100)", fg: "var(--green-600)" }} onClick={() => onNav("resources")} />
          <DestCard icon="briefcase" title="For Landlords" sub="List, promote, screen tenants, and grow your rentals." accent={{ bg: "#FFF1E6", fg: "#EA580C" }} onClick={() => onNav("landlords")} />
          <DestCard icon="info" title="About Zumper" sub="Who we are, careers, and the latest company news." accent={{ bg: "var(--slate-100)", fg: "var(--slate-700)" }} onClick={() => onNav("about")} />
        </div>
      </div>

      {/* Stats */}
      <div style={{ ...PAGE, marginTop: 36 }}>
        <div className="z-cards z-cards-4" style={{ background: "var(--blue-100)", borderRadius: "var(--radius-xl)", padding: "34px clamp(20px,3vw,40px)" }}>
          <H_DS.StatTile value="1,200+" label="Verified listings" />
          <H_DS.StatTile value="24hr" label="Support response time" />
          <H_DS.StatTile value="100%" label="Refund clarity guaranteed" tone="green" />
          <H_DS.StatTile value="4.9★" label="Average platform rating" />
        </div>
      </div>
    </div>
  );
}

window.ZHomeScreen = HomeScreen;
