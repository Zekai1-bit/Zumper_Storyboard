# Zumper — P3 (UTM concept)

A clickable medium-fidelity prototype and an annotated storyboard for the Zumper
student-housing redesign.

- **index.html** — the annotated storyboard (landing page). Includes a
  "Launch interactive prototype" button.
- **Zumper Prototype.html** — the full clickable prototype.
- **Zumper Storyboard.html** — same as index.html (kept for a clean filename).
- `proto/` — the screen code. `_ds/` — the Zumper design system. `assets/` — listing photos.

## Put it online with GitHub Pages

1. Create a new GitHub repository.
2. Upload **all** of these files and folders, keeping the structure exactly as-is
   (index.html and the two .html files at the top level; `proto/`, `_ds/`, `assets/`
   as folders next to them).
3. In the repo, go to **Settings → Pages**.
4. Under "Build and deployment", set **Source = Deploy from a branch**, pick your
   branch (usually `main`) and folder `/ (root)`, then **Save**.
5. Wait ~1 minute, then open the published URL GitHub shows you
   (`https://<you>.github.io/<repo>/`). The storyboard loads first; click
   "Launch interactive prototype" to open the prototype.

### Important
- Open the **Pages URL** (`*.github.io`), **not** the `github.com/.../blob/...` code
  view or a `raw.githubusercontent.com` link — those don't run the page.
- Keep every file in place. The pages load their code and images through relative
  paths, so the folder structure must stay intact.

## Just want to view it locally?

Double-click **index.html**. (If your browser blocks the local script files, use the
standalone single-file exports instead, which have everything baked in.)
